import { Router } from "express";
import { db } from "./db";
import { sql } from "drizzle-orm";

const router = Router();

function requireAuth(req: any, res: any, next: any) {
  if (!req.user) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  next();
}

interface Permission {
  resource: string;
  action: string;
  granted: boolean;
}

const ROLE_PERMISSIONS: { [role: string]: Permission[] } = {
  OWNER: [
    { resource: '*', action: '*', granted: true }
  ],
  ADMIN: [
    { resource: 'transactions', action: '*', granted: true },
    { resource: 'invoices', action: '*', granted: true },
    { resource: 'customers', action: '*', granted: true },
    { resource: 'categories', action: '*', granted: true },
    { resource: 'bank_accounts', action: '*', granted: true },
    { resource: 'cost_centers', action: '*', granted: true },
    { resource: 'tags', action: '*', granted: true },
    { resource: 'documents', action: '*', granted: true },
    { resource: 'reports', action: 'read', granted: true },
    { resource: 'users', action: 'read', granted: true },
    { resource: 'organization', action: 'read', granted: true }
  ],
  CUSTOMER: [
    { resource: 'transactions', action: 'read', granted: true },
    { resource: 'invoices', action: 'read', granted: true },
    { resource: 'customers', action: 'read', granted: true },
    { resource: 'reports', action: 'read', granted: true },
    { resource: 'documents', action: 'read', granted: true }
  ]
};

export function checkPermission(role: string, resource: string, action: string): boolean {
  const permissions = ROLE_PERMISSIONS[role] || [];
  
  for (const permission of permissions) {
    if (permission.resource === '*' && permission.action === '*') {
      return permission.granted;
    }
    
    if (permission.resource === resource || permission.resource === '*') {
      if (permission.action === action || permission.action === '*') {
        return permission.granted;
      }
    }
  }
  
  return false;
}

export function requirePermission(resource: string, action: string) {
  return (req: any, res: any, next: any) => {
    if (!req.user) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const hasPermission = checkPermission(req.user.role, resource, action);
    
    if (!hasPermission) {
      return res.status(403).json({ 
        message: `Forbidden: ${action} permission required for ${resource}` 
      });
    }
    
    next();
  };
}

router.get("/permissions", requireAuth, (req, res) => {
  const userRole = req.user!.role;
  const permissions = ROLE_PERMISSIONS[userRole] || [];
  
  res.json({
    role: userRole,
    permissions
  });
});

router.get("/permissions/check", requireAuth, (req, res) => {
  const { resource, action } = req.query;
  
  if (!resource || !action) {
    return res.status(400).json({ message: "resource and action are required" });
  }
  
  const hasPermission = checkPermission(
    req.user!.role,
    resource as string,
    action as string
  );
  
  res.json({
    role: req.user!.role,
    resource,
    action,
    granted: hasPermission
  });
});

router.get("/roles", requireAuth, (req, res) => {
  const roles = [
    {
      name: 'OWNER',
      description: 'Acesso total ao sistema',
      permissions: ROLE_PERMISSIONS.OWNER.length
    },
    {
      name: 'ADMIN',
      description: 'Acesso administrativo',
      permissions: ROLE_PERMISSIONS.ADMIN.length
    },
    {
      name: 'CUSTOMER',
      description: 'Acesso somente leitura',
      permissions: ROLE_PERMISSIONS.CUSTOMER.length
    }
  ];
  
  res.json(roles);
});

export default router;
