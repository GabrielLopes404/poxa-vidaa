import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { QrCode, FileText, Plus, DollarSign } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";

export default function EnhancedInvoicesPage() {
  const [pixDialogOpen, setPixDialogOpen] = useState(false);
  const [boletoDialogOpen, setBoletoDialogOpen] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState<any>(null);
  const [partialPayment, setPartialPayment] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: invoices } = useQuery({
    queryKey: ["/api/invoices"],
    queryFn: async () => {
      const res = await fetch("/api/invoices", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch invoices");
      return res.json();
    },
  });

  const generatePixMutation = useMutation({
    mutationFn: async (invoiceId: string) => {
      const res = await fetch(`/api/invoices/${invoiceId}/generate-pix`, {
        method: "POST",
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to generate PIX");
      return res.json();
    },
    onSuccess: (data) => {
      setSelectedInvoice(data);
      setPixDialogOpen(true);
      toast({ title: "PIX gerado com sucesso!" });
    },
  });

  const generateBoletoMutation = useMutation({
    mutationFn: async (invoiceId: string) => {
      const res = await fetch(`/api/invoices/${invoiceId}/generate-boleto`, {
        method: "POST",
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to generate boleto");
      return res.json();
    },
    onSuccess: (data) => {
      setSelectedInvoice(data);
      setBoletoDialogOpen(true);
      toast({ title: "Boleto gerado com sucesso!" });
    },
  });

  const recordPartialPaymentMutation = useMutation({
    mutationFn: async ({ invoiceId, amount }: { invoiceId: string; amount: number }) => {
      const res = await fetch(`/api/invoices/${invoiceId}/partial-payment`, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amount }),
      });
      if (!res.ok) throw new Error("Failed to record payment");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      toast({ title: "Pagamento parcial registrado!" });
      setPartialPayment("");
    },
  });

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold">Faturas Avançadas</h1>
          <Button><Plus className="mr-2 h-4 w-4" />Nova Fatura</Button>
        </div>

        <div className="grid grid-cols-1 gap-4">
          {invoices?.map((invoice: any) => (
            <Card key={invoice.id}>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="text-lg">{invoice.invoiceNumber}</CardTitle>
                  <Badge>{invoice.status}</Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Cliente</p>
                    <p className="font-semibold">{invoice.customerName}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Valor</p>
                    <p className="font-semibold text-lg">R$ {invoice.amount}</p>
                  </div>
                  {invoice.amountPaid > 0 && (
                    <div>
                      <p className="text-sm text-muted-foreground">Pago</p>
                      <p className="font-semibold text-green-600">R$ {invoice.amountPaid}</p>
                    </div>
                  )}
                </div>

                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    onClick={() => generatePixMutation.mutate(invoice.id)}
                  >
                    <QrCode className="mr-2 h-4 w-4" />
                    Gerar PIX
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => generateBoletoMutation.mutate(invoice.id)}
                  >
                    <FileText className="mr-2 h-4 w-4" />
                    Gerar Boleto
                  </Button>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline">
                        <DollarSign className="mr-2 h-4 w-4" />
                        Pagamento Parcial
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Registrar Pagamento Parcial</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <Label>Valor Recebido</Label>
                          <Input
                            type="number"
                            step="0.01"
                            value={partialPayment}
                            onChange={(e) => setPartialPayment(e.target.value)}
                            placeholder="0.00"
                          />
                        </div>
                        <Button
                          onClick={() =>
                            recordPartialPaymentMutation.mutate({
                              invoiceId: invoice.id,
                              amount: parseFloat(partialPayment),
                            })
                          }
                          disabled={!partialPayment}
                          className="w-full"
                        >
                          Registrar
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Dialog open={pixDialogOpen} onOpenChange={setPixDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>PIX Gerado</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              {selectedInvoice?.qrCode && (
                <div className="flex justify-center">
                  <img src={selectedInvoice.qrCode} alt="QR Code PIX" className="w-64 h-64" />
                </div>
              )}
              <div>
                <Label>Código PIX Copia e Cola</Label>
                <Input value={selectedInvoice?.pixCode || ""} readOnly />
              </div>
              <Button
                onClick={() => {
                  navigator.clipboard.writeText(selectedInvoice?.pixCode || "");
                  toast({ title: "Código copiado!" });
                }}
                className="w-full"
              >
                Copiar Código
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        <Dialog open={boletoDialogOpen} onOpenChange={setBoletoDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Boleto Gerado</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Código de Barras</Label>
                <Input value={selectedInvoice?.boletoCode || ""} readOnly />
              </div>
              <div>
                <Label>Linha Digitável</Label>
                <Input value={selectedInvoice?.boletoDigitableLine || ""} readOnly />
              </div>
              <Button
                onClick={() => window.open(selectedInvoice?.boletoUrl, "_blank")}
                className="w-full"
              >
                Baixar Boleto PDF
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </AppLayout>
  );
}
