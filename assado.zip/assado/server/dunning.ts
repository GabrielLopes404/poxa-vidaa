import Stripe from "stripe";
import { storage } from "./storage";
import { sendEmail, generatePaymentFailedEmail } from "./email";

const stripe = process.env.STRIPE_SECRET_KEY
  ? new Stripe(process.env.STRIPE_SECRET_KEY, { apiVersion: "2025-10-29.clover" })
  : null;

interface DunningConfig {
  maxRetries: number;
  retryIntervals: number[];
  emailOnFailure: boolean;
  suspendAfterFailures: number;
}

const DEFAULT_DUNNING_CONFIG: DunningConfig = {
  maxRetries: 3,
  retryIntervals: [3, 7, 14],
  emailOnFailure: true,
  suspendAfterFailures: 3,
};

class DunningService {
  async handlePaymentFailed(
    customerId: string,
    invoiceId: string,
    amount: number,
    attempt: number = 1
  ): Promise<void> {
    if (!stripe) {
      console.error("Stripe not configured");
      return;
    }

    const config = DEFAULT_DUNNING_CONFIG;

    if (attempt > config.maxRetries) {
      await this.suspendSubscription(customerId);
      await this.notifyPaymentFailed(customerId, invoiceId, amount, true);
      return;
    }

    const retryDelay = config.retryIntervals[attempt - 1] || 7;
    const retryDate = new Date();
    retryDate.setDate(retryDate.getDate() + retryDelay);

    await this.scheduleRetry(invoiceId, retryDate, attempt + 1);

    if (config.emailOnFailure) {
      await this.notifyPaymentFailed(customerId, invoiceId, amount, false);
    }

    console.log(
      `Payment retry scheduled for invoice ${invoiceId} on ${retryDate.toISOString()}`
    );
  }

  async retryPayment(invoiceId: string, attempt: number): Promise<boolean> {
    if (!stripe) {
      return false;
    }

    try {
      const stripeInvoice = await stripe.invoices.retrieve(invoiceId);

      if (stripeInvoice.status === "paid") {
        return true;
      }

      const paymentIntent = await stripe.invoices.pay(invoiceId, {
        paid_out_of_band: false,
      });

      if (paymentIntent.status === "paid") {
        await this.notifyPaymentSuccess(stripeInvoice.customer as string, invoiceId);
        return true;
      }

      await this.handlePaymentFailed(
        stripeInvoice.customer as string,
        invoiceId,
        stripeInvoice.amount_due / 100,
        attempt
      );

      return false;
    } catch (error) {
      console.error("Payment retry failed:", error);
      return false;
    }
  }

  private async scheduleRetry(
    invoiceId: string,
    retryDate: Date,
    attempt: number
  ): Promise<void> {
    console.log(`Scheduling retry for ${invoiceId} at ${retryDate}, attempt ${attempt}`);
  }

  private async suspendSubscription(customerId: string): Promise<void> {
    if (!stripe) return;

    try {
      const subscriptions = await stripe.subscriptions.list({
        customer: customerId,
        status: "active",
      });

      for (const subscription of subscriptions.data) {
        await stripe.subscriptions.update(subscription.id, {
          pause_collection: {
            behavior: "mark_uncollectible",
          },
        });
      }

      const org = await storage.getOrganizationByStripeCustomerId(customerId);

      if (org) {
        console.log(`Organization ${org.id} marked for suspension`);
      }

      console.log(`Subscription suspended for customer ${customerId}`);
    } catch (error) {
      console.error("Failed to suspend subscription:", error);
    }
  }

  private async notifyPaymentFailed(
    customerId: string,
    invoiceId: string,
    amount: number,
    isFinal: boolean
  ): Promise<void> {
    const org = await storage.getOrganizationByStripeCustomerId(customerId);

    if (!org) return;

    const users = await storage.getUsersByOrganization(org.id);
    const primaryUser = users.find((u) => u.role === "OWNER") || users[0];

    if (!primaryUser) return;

    const subject = isFinal
      ? "URGENTE: Assinatura Suspensa - Pagamento Falhou"
      : "Pagamento Falhou - Nova Tentativa Agendada";

    const html = generatePaymentFailedEmail(
      primaryUser.name || primaryUser.username,
      amount,
      invoiceId,
      isFinal
    );

    await sendEmail({
      to: primaryUser.email,
      subject,
      html,
      text: `Seu pagamento de R$ ${amount.toFixed(2)} falhou. ${isFinal ? "Sua assinatura foi suspensa." : "Uma nova tentativa foi agendada."}`,
    });
  }

  private async notifyPaymentSuccess(
    customerId: string,
    invoiceId: string
  ): Promise<void> {
    const org = await storage.getOrganizationByStripeCustomerId(customerId);

    if (!org) return;

    const users = await storage.getUsersByOrganization(org.id);
    const primaryUser = users.find((u) => u.role === "OWNER") || users[0];

    if (!primaryUser) return;

    await sendEmail({
      to: primaryUser.email,
      subject: "Pagamento Confirmado - LUCREI",
      html: `
        <h1>Pagamento Confirmado!</h1>
        <p>Olá ${primaryUser.name || primaryUser.username},</p>
        <p>Seu pagamento foi processado com sucesso.</p>
        <p><strong>ID da Fatura:</strong> ${invoiceId}</p>
        <p>Obrigado por continuar conosco!</p>
      `,
      text: `Pagamento confirmado. ID da Fatura: ${invoiceId}`,
    });
  }
}

export const dunningService = new DunningService();
