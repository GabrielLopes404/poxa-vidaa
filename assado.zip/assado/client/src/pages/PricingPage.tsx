import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import PricingSection from "@/components/PricingSection";
import Footer from "@/components/Footer";
import { motion } from "framer-motion";

export default function PricingPage() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="sticky top-0 z-50 bg-background/80 backdrop-blur-sm border-b"
      >
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <Button variant="ghost" onClick={() => setLocation("/")} className="gap-2">
            <ArrowLeft className="h-4 w-4" />
            Voltar
          </Button>
          <div className="text-2xl font-bold bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
            LUCREI
          </div>
          <div className="flex gap-2">
            <Button variant="ghost" onClick={() => setLocation("/login")}>
              Entrar
            </Button>
            <Button onClick={() => setLocation("/register")}>
              Começar Agora
            </Button>
          </div>
        </div>
      </motion.div>

      <main className="flex-1">
        <PricingSection />
      </main>

      <Footer />
    </div>
  );
}
