import { storage } from "./storage";

interface PlanLimits {
  maxInvoicesPerMonth: number;
  maxTransactionsPerMonth: number;
  maxUsers: number;
  maxBankAccounts: number;
  maxCustomers: number;
  features: string[];
}

const PLAN_LIMITS: Record<string, PlanLimits> = {
  free: {
    maxInvoicesPerMonth: 10,
    maxTransactionsPerMonth: 50,
    maxUsers: 1,
    maxBankAccounts: 1,
    maxCustomers: 10,
    features: ["basic_reports", "single_currency"],
  },
  basic: {
    maxInvoicesPerMonth: 50,
    maxTransactionsPerMonth: 200,
    maxUsers: 3,
    maxBankAccounts: 3,
    maxCustomers: 50,
    features: ["basic_reports", "recurring_invoices", "single_currency"],
  },
  pro: {
    maxInvoicesPerMonth: 200,
    maxTransactionsPerMonth: 1000,
    maxUsers: 10,
    maxBankAccounts: 10,
    maxCustomers: 200,
    features: [
      "basic_reports",
      "advanced_reports",
      "recurring_invoices",
      "multi_currency",
      "api_access",
      "custom_templates",
    ],
  },
  enterprise: {
    maxInvoicesPerMonth: -1,
    maxTransactionsPerMonth: -1,
    maxUsers: -1,
    maxBankAccounts: -1,
    maxCustomers: -1,
    features: [
      "basic_reports",
      "advanced_reports",
      "recurring_invoices",
      "multi_currency",
      "api_access",
      "custom_templates",
      "priority_support",
      "white_label",
      "advanced_integrations",
    ],
  },
};

class UsageLimitsService {
  async checkLimit(
    organizationId: string,
    limitType: keyof Omit<PlanLimits, "features">
  ): Promise<{ allowed: boolean; current: number; limit: number }> {
    const organization = await storage.getOrganization(organizationId);
    if (!organization) {
      throw new Error("Organization not found");
    }

    const plan = (organization.planType as string) || "personal";
    const limits = PLAN_LIMITS[plan] || PLAN_LIMITS.free;

    const limitValue = limits[limitType];
    if (limitValue === -1) {
      return { allowed: true, current: 0, limit: -1 };
    }

    let current = 0;

    switch (limitType) {
      case "maxInvoicesPerMonth":
        const startOfMonth = new Date();
        startOfMonth.setDate(1);
        startOfMonth.setHours(0, 0, 0, 0);
        const invoices = await storage.getInvoicesByOrganization(organizationId);
        current = invoices.filter(
          (inv) => new Date(inv.createdAt) >= startOfMonth
        ).length;
        break;

      case "maxTransactionsPerMonth":
        const monthStart = new Date();
        monthStart.setDate(1);
        monthStart.setHours(0, 0, 0, 0);
        const transactions = await storage.getTransactionsByOrganization(organizationId);
        current = transactions.filter(
          (trx) => new Date(trx.createdAt!) >= monthStart
        ).length;
        break;

      case "maxUsers":
        const users = await storage.getUsersByOrganization(organizationId);
        current = users.length;
        break;

      case "maxBankAccounts":
        const accounts = await storage.getBankAccountsByOrganization(organizationId);
        current = accounts.length;
        break;

      case "maxCustomers":
        const customers = await storage.getCustomersByOrganization(organizationId);
        current = customers.length;
        break;
    }

    return {
      allowed: current < limitValue,
      current,
      limit: limitValue,
    };
  }

  async hasFeature(organizationId: string, feature: string): Promise<boolean> {
    const organization = await storage.getOrganization(organizationId);
    if (!organization) {
      return false;
    }

    const plan = (organization.planType as string) || "personal";
    const limits = PLAN_LIMITS[plan] || PLAN_LIMITS.free;

    return limits.features.includes(feature);
  }

  async getUsageStats(organizationId: string) {
    const organization = await storage.getOrganization(organizationId);
    if (!organization) {
      throw new Error("Organization not found");
    }

    const plan = (organization.planType as string) || "personal";
    const limits = PLAN_LIMITS[plan] || PLAN_LIMITS.free;

    const stats = {
      plan,
      limits,
      usage: {
        invoices: await this.checkLimit(organizationId, "maxInvoicesPerMonth"),
        transactions: await this.checkLimit(organizationId, "maxTransactionsPerMonth"),
        users: await this.checkLimit(organizationId, "maxUsers"),
        bankAccounts: await this.checkLimit(organizationId, "maxBankAccounts"),
        customers: await this.checkLimit(organizationId, "maxCustomers"),
      },
    };

    return stats;
  }
}

export const usageLimitsService = new UsageLimitsService();
