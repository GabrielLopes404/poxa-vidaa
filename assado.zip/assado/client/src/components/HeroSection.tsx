import { Button } from "@/components/ui/button";
import { ArrowRight, Play, Sparkles, TrendingUp, Zap, CheckCircle2, Globe, Shield } from "lucide-react";
import { motion, useScroll, useTransform } from "framer-motion";
import { useEffect, useState, useRef } from "react";
import { useLocation } from "wouter";

export default function HeroSection() {
  const [, setLocation] = useLocation();
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const containerRef = useRef<HTMLDivElement>(null);
  
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"]
  });

  const y = useTransform(scrollYProgress, [0, 1], ["0%", "50%"]);
  const opacity = useTransform(scrollYProgress, [0, 1], [1, 0]);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  // Floating particles animation data
  const particles = Array.from({ length: 20 }, (_, i) => ({
    id: i,
    size: Math.random() * 4 + 2,
    x: Math.random() * 100,
    y: Math.random() * 100,
    duration: Math.random() * 20 + 10,
    delay: Math.random() * 5,
  }));

  return (
    <section ref={containerRef} className="relative pt-32 pb-32 px-4 sm:px-6 lg:px-8 overflow-hidden">
      {/* Ultra vibrant gradient background */}
      <div className="absolute inset-0 bg-gradient-to-br from-violet-500/10 via-fuchsia-500/5 via-cyan-500/5 to-indigo-600/10" />
      
      {/* Animated mesh gradient overlay */}
      <motion.div 
        className="absolute inset-0 opacity-30"
        style={{
          background: `radial-gradient(circle at ${mousePosition.x}px ${mousePosition.y}px, rgba(139, 92, 246, 0.15) 0%, transparent 50%)`
        }}
      />

      {/* Floating particles */}
      {particles.map((particle) => (
        <motion.div
          key={particle.id}
          className="absolute rounded-full bg-gradient-to-br from-primary/30 to-violet-500/30 blur-sm"
          style={{
            width: particle.size,
            height: particle.size,
            left: `${particle.x}%`,
            top: `${particle.y}%`,
          }}
          animate={{
            y: [0, -30, 0],
            x: [0, 15, 0],
            opacity: [0.3, 0.6, 0.3],
          }}
          transition={{
            duration: particle.duration,
            repeat: Infinity,
            delay: particle.delay,
            ease: "easeInOut",
          }}
        />
      ))}
      
      {/* Dynamic glowing orbs */}
      <motion.div
        className="absolute top-20 right-20 w-[500px] h-[500px] rounded-full blur-3xl"
        style={{
          background: "radial-gradient(circle, rgba(139, 92, 246, 0.3) 0%, rgba(236, 72, 153, 0.2) 50%, transparent 70%)",
        }}
        animate={{
          x: mousePosition.x * 0.03,
          y: mousePosition.y * 0.03,
          scale: [1, 1.1, 1],
        }}
        transition={{ 
          type: "spring", 
          stiffness: 30, 
          damping: 20,
          scale: { duration: 8, repeat: Infinity, ease: "easeInOut" }
        }}
      />
      <motion.div
        className="absolute bottom-20 left-20 w-[600px] h-[600px] rounded-full blur-3xl"
        style={{
          background: "radial-gradient(circle, rgba(6, 182, 212, 0.3) 0%, rgba(59, 130, 246, 0.2) 50%, transparent 70%)",
        }}
        animate={{
          x: mousePosition.x * -0.02,
          y: mousePosition.y * -0.02,
          scale: [1, 1.2, 1],
        }}
        transition={{ 
          type: "spring", 
          stiffness: 20, 
          damping: 20,
          scale: { duration: 10, repeat: Infinity, ease: "easeInOut" }
        }}
      />

      {/* Rotating gradient ring */}
      <motion.div
        className="absolute top-1/2 left-1/2 w-[800px] h-[800px] -translate-x-1/2 -translate-y-1/2 opacity-20"
        animate={{ rotate: 360 }}
        transition={{ duration: 50, repeat: Infinity, ease: "linear" }}
      >
        <div className="w-full h-full rounded-full border-2 border-transparent bg-gradient-to-r from-violet-500 via-fuchsia-500 to-cyan-500 bg-clip-border blur-xl" />
      </motion.div>

      <motion.div style={{ y, opacity }} className="max-w-[1440px] mx-auto relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div 
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: [0.25, 0.4, 0.25, 1] }}
            className="space-y-10"
          >
            {/* Badge with shimmer effect */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2, duration: 0.6, type: "spring" }}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-gradient-to-r from-violet-500/10 via-fuchsia-500/10 to-cyan-500/10 border border-violet-500/20 backdrop-blur-xl shadow-lg shadow-violet-500/10 relative overflow-hidden group"
            >
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent"
                animate={{ x: ['-200%', '200%'] }}
                transition={{ duration: 2, repeat: Infinity, ease: "linear", repeatDelay: 1 }}
              />
              <Sparkles className="h-4 w-4 text-violet-500" />
              <span className="text-sm font-semibold bg-gradient-to-r from-violet-600 via-fuchsia-600 to-cyan-600 bg-clip-text text-transparent">
                🚀 Novo: Automação com IA + Análise Preditiva
              </span>
            </motion.div>

            {/* Main headline with ultra vibrant gradients */}
            <motion.h1 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 1, ease: [0.25, 0.4, 0.25, 1] }}
              className="text-5xl sm:text-6xl lg:text-7xl font-bold leading-[1.1] tracking-tight"
              data-testid="text-hero-title"
            >
              <span className="bg-gradient-to-r from-foreground to-foreground/90 bg-clip-text text-transparent">
                Gestão financeira{" "}
              </span>
              <span className="relative inline-block">
                <motion.span
                  className="absolute -inset-2 bg-gradient-to-r from-violet-500 via-fuchsia-500 to-cyan-500 blur-2xl opacity-30"
                  animate={{ opacity: [0.3, 0.6, 0.3] }}
                  transition={{ duration: 3, repeat: Infinity }}
                />
                <span className="relative bg-gradient-to-r from-violet-600 via-fuchsia-600 to-cyan-600 bg-clip-text text-transparent">
                  inteligente
                </span>
              </span>
              <br />
              <span className="bg-gradient-to-r from-foreground to-foreground/90 bg-clip-text text-transparent">
                que cresce com você
              </span>
            </motion.h1>

            {/* Enhanced subtitle */}
            <motion.p 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 1 }}
              className="text-xl sm:text-2xl text-muted-foreground max-w-2xl leading-relaxed font-light"
              data-testid="text-hero-subtitle"
            >
              Transforme dados em decisões. Sistema completo de gestão financeira com{" "}
              <span className="font-semibold bg-gradient-to-r from-violet-600 to-fuchsia-600 bg-clip-text text-transparent">
                IA integrada
              </span>
              , análises em tempo real e automação inteligente.
            </motion.p>

            {/* Enhanced CTA buttons */}
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5, duration: 1 }}
              className="flex flex-col sm:flex-row gap-4"
            >
              <motion.div 
                whileHover={{ scale: 1.03, y: -2 }} 
                whileTap={{ scale: 0.98 }}
                transition={{ type: "spring", stiffness: 400, damping: 17 }}
              >
                <Button 
                  size="lg" 
                  className="text-lg px-10 py-7 shadow-2xl shadow-violet-500/30 relative overflow-hidden group bg-gradient-to-r from-violet-600 via-fuchsia-600 to-cyan-600 hover:shadow-violet-500/50 transition-all duration-300" 
                  data-testid="button-hero-cta-primary"
                  onClick={() => setLocation('/register')}
                >
                  <motion.div
                    className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
                    animate={{ x: ['-200%', '200%'] }}
                    transition={{ duration: 2, repeat: Infinity, ease: "linear", repeatDelay: 1 }}
                  />
                  <span className="relative z-10 flex items-center gap-2 font-semibold">
                    Começar gratuitamente
                    <motion.div
                      animate={{ x: [0, 4, 0] }}
                      transition={{ duration: 1.5, repeat: Infinity }}
                    >
                      <ArrowRight className="h-5 w-5" />
                    </motion.div>
                  </span>
                </Button>
              </motion.div>
              
              <motion.div 
                whileHover={{ scale: 1.03, y: -2 }} 
                whileTap={{ scale: 0.98 }}
                transition={{ type: "spring", stiffness: 400, damping: 17 }}
              >
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="text-lg px-10 py-7 backdrop-blur-xl bg-background/30 border-2 border-violet-500/30 hover:border-violet-500/60 hover:bg-violet-500/10 transition-all duration-300 shadow-lg"
                  data-testid="button-hero-cta-secondary"
                >
                  <Play className="mr-2 h-5 w-5" />
                  Ver demonstração
                </Button>
              </motion.div>
            </motion.div>

            {/* Trust indicators with advanced styling */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6, duration: 1 }}
              className="flex flex-wrap items-center gap-6 pt-6"
            >
              {[
                { icon: CheckCircle2, text: 'Sem cartão de crédito', color: 'from-green-500 to-emerald-500' },
                { icon: Shield, text: 'Dados 100% seguros', color: 'from-blue-500 to-cyan-500' },
                { icon: Globe, text: 'Usado em 40+ países', color: 'from-violet-500 to-fuchsia-500' }
              ].map((item, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.7 + i * 0.1 }}
                  whileHover={{ scale: 1.05 }}
                  className="flex items-center gap-2 group cursor-pointer"
                >
                  <div className={`p-1.5 rounded-lg bg-gradient-to-br ${item.color} shadow-lg`}>
                    <item.icon className="h-4 w-4 text-white" />
                  </div>
                  <span className="text-sm font-medium text-muted-foreground group-hover:text-foreground transition-colors">
                    {item.text}
                  </span>
                </motion.div>
              ))}
            </motion.div>

            {/* Animated stats */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.8, duration: 1 }}
              className="grid grid-cols-3 gap-8 pt-8 border-t border-border/50"
            >
              {[
                { icon: TrendingUp, value: '12.5K+', label: 'Empresas confiando', color: 'from-green-500 to-emerald-500' },
                { icon: Zap, value: 'R$ 120M+', label: 'Em transações/mês', color: 'from-violet-600 to-fuchsia-600' },
                { icon: Sparkles, value: '4.95★', label: 'Satisfação média', color: 'from-yellow-500 to-orange-500' }
              ].map((stat, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.9 + i * 0.1 }}
                  whileHover={{ y: -5 }}
                  className="relative group cursor-pointer"
                >
                  <motion.div 
                    className={`absolute -inset-3 bg-gradient-to-r ${stat.color} rounded-xl blur-xl opacity-0 group-hover:opacity-30 transition-opacity duration-500`}
                    animate={{ opacity: [0, 0.2, 0] }}
                    transition={{ duration: 3, repeat: Infinity, delay: i * 0.5 }}
                  />
                  <div className="relative space-y-2">
                    <stat.icon className={`h-5 w-5 bg-gradient-to-r ${stat.color} bg-clip-text text-transparent`} />
                    <div className={`text-3xl font-bold bg-gradient-to-r ${stat.color} bg-clip-text text-transparent font-mono tabular-nums`} data-testid={`text-hero-stat-${i + 1}`}>
                      {stat.value}
                    </div>
                    <div className="text-sm text-muted-foreground font-medium">{stat.label}</div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </motion.div>
          
          {/* Enhanced dashboard preview */}
          <motion.div 
            initial={{ opacity: 0, x: 60 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5, duration: 1, ease: [0.25, 0.4, 0.25, 1] }}
            className="relative"
          >
            <motion.div
              animate={{
                y: [0, -20, 0],
              }}
              transition={{
                duration: 8,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="relative"
            >
              {/* Glowing background effect */}
              <div className="absolute -inset-8 bg-gradient-to-r from-violet-500/40 via-fuchsia-500/30 to-cyan-500/40 rounded-3xl blur-3xl animate-pulse" />
              
              <motion.div 
                whileHover={{ scale: 1.02, rotateX: 2, rotateY: -2 }}
                transition={{ type: "spring", stiffness: 300, damping: 30 }}
                className="relative rounded-2xl overflow-hidden shadow-2xl border border-violet-500/20 backdrop-blur-xl bg-gradient-to-br from-background/80 to-background/40"
                data-testid="img-hero-dashboard"
                style={{ transformStyle: 'preserve-3d', perspective: '1000px' }}
              >
                {/* Multiple gradient overlays */}
                <div className="absolute inset-0 bg-gradient-to-br from-violet-500/30 via-fuchsia-500/20 to-cyan-500/30 mix-blend-overlay" />
                <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/5 to-transparent" />
                
                {/* Glass morphism effect */}
                <div className="relative z-10 backdrop-blur-3xl bg-white/5 p-8 aspect-[16/10]">
                  <div className="flex items-center justify-center h-full">
                    <div className="space-y-6 w-full">
                      <div className="flex items-center justify-between">
                        <div className="h-8 w-32 bg-gradient-to-r from-violet-500/30 to-fuchsia-500/30 rounded-lg animate-pulse" />
                        <div className="h-8 w-8 bg-gradient-to-r from-cyan-500/30 to-blue-500/30 rounded-full animate-pulse" />
                      </div>
                      <div className="grid grid-cols-3 gap-4">
                        {[1, 2, 3].map((i) => (
                          <motion.div
                            key={i}
                            animate={{ opacity: [0.3, 0.7, 0.3] }}
                            transition={{ duration: 2, repeat: Infinity, delay: i * 0.3 }}
                            className="h-24 bg-gradient-to-br from-violet-500/20 to-fuchsia-500/20 rounded-xl backdrop-blur-sm border border-white/10"
                          />
                        ))}
                      </div>
                      <div className="h-48 bg-gradient-to-br from-cyan-500/20 to-blue-500/20 rounded-xl backdrop-blur-sm border border-white/10" />
                    </div>
                  </div>
                </div>

                {/* Animated shimmer effect */}
                <motion.div
                  className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/20 to-transparent"
                  animate={{
                    x: ['-100%', '100%'],
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    ease: "linear",
                    repeatDelay: 3
                  }}
                />
              </motion.div>
            </motion.div>

            {/* Floating stat cards */}
            <motion.div
              initial={{ opacity: 0, scale: 0, rotate: -5 }}
              animate={{ opacity: 1, scale: 1, rotate: 0 }}
              transition={{ delay: 1.2, duration: 0.6, type: "spring" }}
              whileHover={{ scale: 1.05, rotate: 2 }}
              className="absolute -bottom-8 -left-8 bg-gradient-to-br from-green-500/90 to-emerald-600/90 backdrop-blur-xl shadow-2xl shadow-green-500/30 rounded-2xl p-5 border border-white/20"
            >
              <div className="flex items-center gap-4">
                <div className="h-14 w-14 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                  <TrendingUp className="h-7 w-7 text-white" />
                </div>
                <div>
                  <div className="text-xs text-white/80 font-medium">Receita Este Mês</div>
                  <div className="text-2xl font-bold text-white font-mono">+67% 🚀</div>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0, rotate: 5 }}
              animate={{ opacity: 1, scale: 1, rotate: 0 }}
              transition={{ delay: 1.4, duration: 0.6, type: "spring" }}
              whileHover={{ scale: 1.05, rotate: -2 }}
              className="absolute -top-8 -right-8 bg-gradient-to-br from-violet-500/90 to-fuchsia-600/90 backdrop-blur-xl shadow-2xl shadow-violet-500/30 rounded-2xl p-5 border border-white/20"
            >
              <div className="flex items-center gap-4">
                <div className="h-14 w-14 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                  <Zap className="h-7 w-7 text-white" />
                </div>
                <div>
                  <div className="text-xs text-white/80 font-medium">Tempo Economizado</div>
                  <div className="text-2xl font-bold text-white font-mono">120h/mês</div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </motion.div>
    </section>
  );
}
