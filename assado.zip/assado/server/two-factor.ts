import { Router } from "express";
import speakeasy from "speakeasy";
import qrcode from "qrcode";
import { db } from "./db";
import { users } from "@shared/schema";
import { eq } from "drizzle-orm";
import { randomBytes } from "crypto";

const router = Router();

function requireAuth(req: any, res: any, next: any) {
  if (!req.user) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  next();
}

function generateBackupCodes(count: number = 10): string[] {
  const codes: string[] = [];
  for (let i = 0; i < count; i++) {
    const code = randomBytes(4).toString('hex').toUpperCase();
    const formatted = `${code.slice(0, 4)}-${code.slice(4, 8)}`;
    codes.push(formatted);
  }
  return codes;
}

router.post("/2fa/setup/start", requireAuth, async (req, res) => {
  try {
    const userId = req.user!.id;
    const user = await db.query.users.findFirst({
      where: eq(users.id, userId)
    });

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    if (user.twoFactorEnabled) {
      return res.status(400).json({ message: "2FA is already enabled" });
    }

    const secret = speakeasy.generateSecret({
      name: `LUCREI (${user.email})`,
      issuer: "LUCREI",
      length: 32
    });

    await db.update(users)
      .set({ twoFactorSecret: secret.base32 })
      .where(eq(users.id, userId));

    const qrCodeUrl = await qrcode.toDataURL(secret.otpauth_url!);

    res.json({
      secret: secret.base32,
      qrCode: qrCodeUrl,
      otpauthUrl: secret.otpauth_url
    });
  } catch (error) {
    console.error("2FA setup error:", error);
    res.status(500).json({ message: "Failed to setup 2FA" });
  }
});

router.post("/2fa/setup/verify", requireAuth, async (req, res) => {
  try {
    const userId = req.user!.id;
    const { token } = req.body;

    if (!token) {
      return res.status(400).json({ message: "Token is required" });
    }

    const user = await db.query.users.findFirst({
      where: eq(users.id, userId)
    });

    if (!user || !user.twoFactorSecret) {
      return res.status(404).json({ message: "2FA setup not initiated" });
    }

    const verified = speakeasy.totp.verify({
      secret: user.twoFactorSecret,
      encoding: 'base32',
      token: token,
      window: 2
    });

    if (!verified) {
      return res.status(400).json({ message: "Invalid token" });
    }

    const backupCodes = generateBackupCodes();
    
    await db.update(users)
      .set({
        twoFactorEnabled: true,
        twoFactorBackupCodes: JSON.stringify(backupCodes)
      })
      .where(eq(users.id, userId));

    res.json({
      message: "2FA enabled successfully",
      backupCodes
    });
  } catch (error) {
    console.error("2FA verify error:", error);
    res.status(500).json({ message: "Failed to verify 2FA" });
  }
});

router.post("/2fa/verify", requireAuth, async (req, res) => {
  try {
    const userId = req.user!.id;
    const { token } = req.body;

    if (!token) {
      return res.status(400).json({ message: "Token is required" });
    }

    const user = await db.query.users.findFirst({
      where: eq(users.id, userId)
    });

    if (!user || !user.twoFactorEnabled || !user.twoFactorSecret) {
      return res.status(400).json({ message: "2FA is not enabled" });
    }

    const verified = speakeasy.totp.verify({
      secret: user.twoFactorSecret,
      encoding: 'base32',
      token: token,
      window: 2
    });

    if (verified) {
      return res.json({ verified: true });
    }

    if (user.twoFactorBackupCodes) {
      const backupCodes: string[] = JSON.parse(user.twoFactorBackupCodes);
      const codeIndex = backupCodes.indexOf(token);
      
      if (codeIndex !== -1) {
        backupCodes.splice(codeIndex, 1);
        
        await db.update(users)
          .set({ twoFactorBackupCodes: JSON.stringify(backupCodes) })
          .where(eq(users.id, userId));

        return res.json({
          verified: true,
          message: "Backup code used successfully",
          remainingBackupCodes: backupCodes.length
        });
      }
    }

    res.status(400).json({ verified: false, message: "Invalid token or backup code" });
  } catch (error) {
    console.error("2FA verification error:", error);
    res.status(500).json({ message: "Failed to verify 2FA" });
  }
});

router.post("/2fa/disable", requireAuth, async (req, res) => {
  try {
    const userId = req.user!.id;
    const { password } = req.body;

    if (!password) {
      return res.status(400).json({ message: "Password is required" });
    }

    const user = await db.query.users.findFirst({
      where: eq(users.id, userId)
    });

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    const bcrypt = await import("bcryptjs");
    const validPassword = await bcrypt.compare(password, user.password);

    if (!validPassword) {
      return res.status(401).json({ message: "Invalid password" });
    }

    await db.update(users)
      .set({
        twoFactorEnabled: false,
        twoFactorSecret: null,
        twoFactorBackupCodes: null
      })
      .where(eq(users.id, userId));

    res.json({ message: "2FA disabled successfully" });
  } catch (error) {
    console.error("2FA disable error:", error);
    res.status(500).json({ message: "Failed to disable 2FA" });
  }
});

router.post("/2fa/backup-codes/regenerate", requireAuth, async (req, res) => {
  try {
    const userId = req.user!.id;
    const { password } = req.body;

    if (!password) {
      return res.status(400).json({ message: "Password is required" });
    }

    const user = await db.query.users.findFirst({
      where: eq(users.id, userId)
    });

    if (!user || !user.twoFactorEnabled) {
      return res.status(400).json({ message: "2FA is not enabled" });
    }

    const bcrypt = await import("bcryptjs");
    const validPassword = await bcrypt.compare(password, user.password);

    if (!validPassword) {
      return res.status(401).json({ message: "Invalid password" });
    }

    const backupCodes = generateBackupCodes();

    await db.update(users)
      .set({ twoFactorBackupCodes: JSON.stringify(backupCodes) })
      .where(eq(users.id, userId));

    res.json({
      message: "Backup codes regenerated successfully",
      backupCodes
    });
  } catch (error) {
    console.error("Backup codes regeneration error:", error);
    res.status(500).json({ message: "Failed to regenerate backup codes" });
  }
});

router.get("/2fa/status", requireAuth, async (req, res) => {
  try {
    const userId = req.user!.id;
    const user = await db.query.users.findFirst({
      where: eq(users.id, userId),
      columns: {
        twoFactorEnabled: true,
        twoFactorBackupCodes: true
      }
    });

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    const backupCodesCount = user.twoFactorBackupCodes 
      ? JSON.parse(user.twoFactorBackupCodes).length 
      : 0;

    res.json({
      enabled: user.twoFactorEnabled,
      backupCodesRemaining: backupCodesCount
    });
  } catch (error) {
    console.error("2FA status error:", error);
    res.status(500).json({ message: "Failed to get 2FA status" });
  }
});

export default router;
