import { Router } from "express";
import * as openidClient from "openid-client";
import { db } from "./db";
import { users, organizations } from "@shared/schema";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";
import { logAuditTrail } from "./audit-trail";
import { trackLoginAttempt } from "./device-tracking";

const router = Router();

const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID || "";
const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET || "";
const MICROSOFT_CLIENT_ID = process.env.MICROSOFT_CLIENT_ID || "";
const MICROSOFT_CLIENT_SECRET = process.env.MICROSOFT_CLIENT_SECRET || "";
const REDIRECT_URI = process.env.OAUTH_REDIRECT_URI || "http://localhost:5000/api/oauth/callback";

let googleClient: any = null;
let microsoftClient: any = null;

async function initializeGoogleClient() {
  if (!GOOGLE_CLIENT_ID || !GOOGLE_CLIENT_SECRET) {
    console.warn("Google OAuth not configured");
    return null;
  }

  try {
    const googleIssuer = await openidClient.Issuer.discover("https://accounts.google.com");
    googleClient = new googleIssuer.Client({
      client_id: GOOGLE_CLIENT_ID,
      client_secret: GOOGLE_CLIENT_SECRET,
      redirect_uris: [REDIRECT_URI],
      response_types: ["code"],
    });
    return googleClient;
  } catch (error) {
    console.error("Failed to initialize Google OAuth:", error);
    return null;
  }
}

async function initializeMicrosoftClient() {
  if (!MICROSOFT_CLIENT_ID || !MICROSOFT_CLIENT_SECRET) {
    console.warn("Microsoft OAuth not configured");
    return null;
  }

  try {
    const microsoftIssuer = await openidClient.Issuer.discover(
      "https://login.microsoftonline.com/common/v2.0"
    );
    microsoftClient = new microsoftIssuer.Client({
      client_id: MICROSOFT_CLIENT_ID,
      client_secret: MICROSOFT_CLIENT_SECRET,
      redirect_uris: [REDIRECT_URI],
      response_types: ["code"],
    });
    return microsoftClient;
  } catch (error) {
    console.error("Failed to initialize Microsoft OAuth:", error);
    return null;
  }
}

const sessions = new Map<string, { provider: string; codeVerifier: string; state: string }>();

router.get("/oauth/google", async (req, res) => {
  try {
    if (!googleClient) {
      await initializeGoogleClient();
    }

    if (!googleClient) {
      return res.status(500).json({ message: "Google OAuth not configured" });
    }

    const codeVerifier = openidClient.generators.codeVerifier();
    const codeChallenge = openidClient.generators.codeChallenge(codeVerifier);
    const state = openidClient.generators.state();

    sessions.set(state, { provider: "google", codeVerifier, state });

    const authUrl = googleClient.authorizationUrl({
      scope: "openid email profile",
      code_challenge: codeChallenge,
      code_challenge_method: "S256",
      state,
    });

    res.redirect(authUrl);
  } catch (error) {
    console.error("Google OAuth error:", error);
    res.status(500).json({ message: "Failed to initiate Google OAuth" });
  }
});

router.get("/oauth/microsoft", async (req, res) => {
  try {
    if (!microsoftClient) {
      await initializeMicrosoftClient();
    }

    if (!microsoftClient) {
      return res.status(500).json({ message: "Microsoft OAuth not configured" });
    }

    const codeVerifier = openidClient.generators.codeVerifier();
    const codeChallenge = openidClient.generators.codeChallenge(codeVerifier);
    const state = openidClient.generators.state();

    sessions.set(state, { provider: "microsoft", codeVerifier, state });

    const authUrl = microsoftClient.authorizationUrl({
      scope: "openid email profile",
      code_challenge: codeChallenge,
      code_challenge_method: "S256",
      state,
    });

    res.redirect(authUrl);
  } catch (error) {
    console.error("Microsoft OAuth error:", error);
    res.status(500).json({ message: "Failed to initiate Microsoft OAuth" });
  }
});

router.get("/oauth/callback", async (req, res) => {
  try {
    const { code, state } = req.query;

    if (!code || !state || typeof state !== 'string') {
      return res.status(400).json({ message: "Invalid OAuth callback" });
    }

    const session = sessions.get(state);
    if (!session) {
      return res.status(400).json({ message: "Invalid or expired session" });
    }

    sessions.delete(state);

    const { provider, codeVerifier } = session;
    const client = provider === "google" ? googleClient : microsoftClient;

    if (!client) {
      return res.status(500).json({ message: "OAuth client not initialized" });
    }

    const params = client.callbackParams(req.url);
    const tokenSet = await client.callback(REDIRECT_URI, params, {
      code_verifier: codeVerifier,
      state: session.state,
    });

    const userInfo = await client.userinfo(tokenSet);

    const email = userInfo.email as string;
    const name = userInfo.name as string || email.split('@')[0];

    let user = await db.query.users.findFirst({
      where: eq(users.email, email)
    });

    const ipAddress = req.ip || req.socket.remoteAddress || 'unknown';
    const userAgent = req.headers['user-agent'] || 'unknown';

    if (!user) {
      const randomPassword = await bcrypt.hash(Math.random().toString(36), 12);
      
      const newOrg = await db.insert(organizations).values({
        name: `${name}'s Organization`,
        email: email,
      }).returning();

      const newUser = await db.insert(users).values({
        organizationId: newOrg[0].id,
        username: email.split('@')[0] + '_' + Date.now(),
        email: email,
        password: randomPassword,
        name: name,
        emailVerified: true,
        role: "OWNER"
      }).returning();

      user = newUser[0];

      await logAuditTrail({
        organizationId: newOrg[0].id,
        userId: user.id,
        action: 'user_registered_oauth',
        metadata: { provider, email },
        ipAddress,
        userAgent
      });
    }

    await trackLoginAttempt({
      userId: user.id,
      email: user.email,
      ipAddress,
      userAgent,
      success: true,
      twoFactorUsed: false
    });

    const userForLogin = {
      id: user.id,
      username: user.username,
      email: user.email,
      name: user.name || user.username,
      organizationId: user.organizationId,
      role: user.role,
      emailVerified: user.emailVerified
    };

    req.login(userForLogin, (err) => {
      if (err) {
        console.error("Login error:", err);
        return res.status(500).json({ message: "Failed to login" });
      }

      res.redirect("/");
    });
  } catch (error) {
    console.error("OAuth callback error:", error);
    res.status(500).json({ message: "OAuth authentication failed" });
  }
});

router.get("/oauth/status", (req, res) => {
  res.json({
    google: !!GOOGLE_CLIENT_ID && !!GOOGLE_CLIENT_SECRET,
    microsoft: !!MICROSOFT_CLIENT_ID && !!MICROSOFT_CLIENT_SECRET
  });
});

export default router;
