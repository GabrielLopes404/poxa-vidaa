import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Upload, Eye, FileText, Image, Download } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function AdvancedDocumentsPage() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewDoc, setPreviewDoc] = useState<any>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: documents } = useQuery({
    queryKey: ["/api/documents"],
    queryFn: async () => {
      const res = await fetch("/api/documents", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch documents");
      return res.json();
    },
  });

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("file", file);
      const res = await fetch("/api/documents/upload", {
        method: "POST",
        credentials: "include",
        body: formData,
      });
      if (!res.ok) throw new Error("Upload failed");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/documents"] });
      toast({ title: "Documento enviado com sucesso!" });
      setSelectedFile(null);
    },
  });

  const extractTextMutation = useMutation({
    mutationFn: async (documentId: string) => {
      const res = await fetch(`/api/documents/${documentId}/ocr`, {
        method: "POST",
        credentials: "include",
      });
      if (!res.ok) throw new Error("OCR failed");
      return res.json();
    },
    onSuccess: (data) => {
      toast({ title: "Texto extraído!", description: `${data.textLength} caracteres` });
      queryClient.invalidateQueries({ queryKey: ["/api/documents"] });
    },
  });

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0]);
    }
  };

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold">Documentos Avançados</h1>
          <Dialog>
            <DialogTrigger asChild>
              <Button>
                <Upload className="mr-2 h-4 w-4" />
                Enviar Documento
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Upload de Documento</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <Input
                  type="file"
                  onChange={handleFileSelect}
                  accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
                />
                {selectedFile && (
                  <div className="text-sm text-muted-foreground">
                    Selecionado: {selectedFile.name} ({(selectedFile.size / 1024).toFixed(2)} KB)
                  </div>
                )}
                <Button
                  onClick={() => selectedFile && uploadMutation.mutate(selectedFile)}
                  disabled={!selectedFile}
                  className="w-full"
                >
                  Enviar
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {documents?.map((doc: any) => (
            <Card key={doc.id}>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center space-y-3">
                  {doc.mimeType?.startsWith("image/") ? (
                    <Image className="h-16 w-16 text-muted-foreground" />
                  ) : (
                    <FileText className="h-16 w-16 text-muted-foreground" />
                  )}
                  <div>
                    <p className="font-semibold truncate w-full">{doc.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {(doc.fileSize / 1024).toFixed(2)} KB
                    </p>
                  </div>
                  <div className="flex gap-2 w-full">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setPreviewDoc(doc)}
                      className="flex-1"
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => window.open(doc.url, "_blank")}
                      className="flex-1"
                    >
                      <Download className="h-4 w-4" />
                    </Button>
                    {doc.mimeType?.startsWith("image/") && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => extractTextMutation.mutate(doc.id)}
                        className="flex-1"
                        title="Extrair texto (OCR)"
                      >
                        OCR
                      </Button>
                    )}
                  </div>
                  {doc.extractedText && (
                    <div className="text-xs bg-muted p-2 rounded w-full max-h-20 overflow-auto">
                      {doc.extractedText.substring(0, 100)}...
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Dialog open={!!previewDoc} onOpenChange={() => setPreviewDoc(null)}>
          <DialogContent className="max-w-4xl max-h-[80vh]">
            <DialogHeader>
              <DialogTitle>{previewDoc?.name}</DialogTitle>
            </DialogHeader>
            <div className="overflow-auto">
              {previewDoc?.mimeType?.startsWith("image/") ? (
                <img src={previewDoc.url} alt={previewDoc.name} className="w-full" />
              ) : previewDoc?.mimeType === "application/pdf" ? (
                <iframe
                  src={previewDoc.url}
                  className="w-full h-[60vh]"
                  title="PDF Preview"
                />
              ) : (
                <p className="text-center text-muted-foreground py-8">
                  Preview não disponível para este tipo de arquivo
                </p>
              )}
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </AppLayout>
  );
}
