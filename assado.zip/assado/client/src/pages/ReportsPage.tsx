import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FileText, Download, TrendingUp, TrendingDown, DollarSign, BarChart3, Calendar, Filter, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
} from "recharts";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: { type: "spring", stiffness: 100 }
  }
};

export default function ReportsPage() {
  const [startDate, setStartDate] = useState(() => {
    const date = new Date();
    date.setDate(1);
    return date.toISOString().split('T')[0];
  });
  const [endDate, setEndDate] = useState(new Date().toISOString().split('T')[0]);
  
  const { toast } = useToast();

  const { data: dreReport, isLoading: isDreLoading } = useQuery({
    queryKey: ["/api/reports/dre", startDate, endDate],
    queryFn: async () => {
      const params = new URLSearchParams({ startDate, endDate });
      const res = await fetch(`/api/reports/dre?${params}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch DRE report");
      return res.json();
    },
  });

  const { data: cashFlowReport, isLoading: isCashFlowLoading } = useQuery({
    queryKey: ["/api/reports/cash-flow", startDate, endDate],
    queryFn: async () => {
      const params = new URLSearchParams({ startDate, endDate });
      const res = await fetch(`/api/reports/cash-flow?${params}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch cash flow report");
      return res.json();
    },
  });

  const { data: statementReport, isLoading: isStatementLoading } = useQuery({
    queryKey: ["/api/reports/statement", startDate, endDate],
    queryFn: async () => {
      const params = new URLSearchParams({ startDate, endDate });
      const res = await fetch(`/api/reports/statement?${params}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch statement");
      return res.json();
    },
  });

  const handleExportReport = async (reportType: string) => {
    try {
      const params = new URLSearchParams({ startDate, endDate, format: "pdf" });
      const res = await fetch(`/api/reports/${reportType}?${params}`, {
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to export report");
      
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${reportType}_${startDate}_${endDate}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({ title: "Relatório exportado com sucesso!" });
    } catch (error) {
      toast({ 
        title: "Erro ao exportar relatório", 
        description: (error as Error).message,
        variant: "destructive" 
      });
    }
  };

  return (
    <AppLayout>
      <motion.div 
        className="space-y-6"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.div variants={itemVariants} className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              Relatórios
            </h1>
            <p className="text-muted-foreground mt-1">
              Análise completa e insights financeiros
            </p>
          </div>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Filter className="h-5 w-5" />
                Filtros de Relatório
              </CardTitle>
              <CardDescription>Configure os parâmetros para gerar relatórios personalizados</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="startDate">Data inicial</Label>
                  <Input 
                    id="startDate"
                    type="date" 
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="endDate">Data final</Label>
                  <Input 
                    id="endDate"
                    type="date" 
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <Tabs defaultValue="dre" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="dre">DRE</TabsTrigger>
            <TabsTrigger value="cashflow">Fluxo de Caixa</TabsTrigger>
            <TabsTrigger value="statement">Extrato</TabsTrigger>
          </TabsList>

          <TabsContent value="dre" className="space-y-6">
            <motion.div variants={itemVariants}>
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>Demonstração do Resultado do Exercício (DRE)</CardTitle>
                      <CardDescription>Análise de receitas, custos e lucros do período</CardDescription>
                    </div>
                    <Button onClick={() => handleExportReport('dre')} className="gap-2">
                      <Download className="h-4 w-4" />
                      Exportar PDF
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {isDreLoading ? (
                    <div className="flex items-center justify-center py-12">
                      <Loader2 className="h-8 w-8 animate-spin text-primary" />
                    </div>
                  ) : dreReport ? (
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4 p-4 bg-muted/50 rounded-lg">
                        <div>
                          <p className="text-sm text-muted-foreground">Receita Bruta</p>
                          <p className="text-2xl font-bold text-green-600">
                            R$ {parseFloat(dreReport.totalRevenue || "0").toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Despesas Totais</p>
                          <p className="text-2xl font-bold text-red-600">
                            R$ {parseFloat(dreReport.totalExpenses || "0").toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Lucro Líquido</p>
                          <p className="text-2xl font-bold text-blue-600">
                            R$ {parseFloat(dreReport.netProfit || "0").toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Margem Líquida</p>
                          <p className="text-2xl font-bold">
                            {parseFloat(dreReport.profitMargin || "0").toFixed(2)}%
                          </p>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <p className="text-center text-muted-foreground py-12">
                      Nenhum dado disponível para o período selecionado
                    </p>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          <TabsContent value="cashflow" className="space-y-6">
            <motion.div variants={itemVariants}>
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>Fluxo de Caixa</CardTitle>
                      <CardDescription>Movimentações de entrada e saída de caixa</CardDescription>
                    </div>
                    <Button onClick={() => handleExportReport('cash-flow')} className="gap-2">
                      <Download className="h-4 w-4" />
                      Exportar PDF
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {isCashFlowLoading ? (
                    <div className="flex items-center justify-center py-12">
                      <Loader2 className="h-8 w-8 animate-spin text-primary" />
                    </div>
                  ) : cashFlowReport ? (
                    <div className="space-y-6">
                      <div className="grid grid-cols-3 gap-4 p-4 bg-muted/50 rounded-lg">
                        <div>
                          <p className="text-sm text-muted-foreground">Total Entradas</p>
                          <p className="text-2xl font-bold text-green-600">
                            R$ {parseFloat(cashFlowReport.totalInflow || "0").toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Total Saídas</p>
                          <p className="text-2xl font-bold text-red-600">
                            R$ {parseFloat(cashFlowReport.totalOutflow || "0").toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Fluxo Líquido</p>
                          <p className="text-2xl font-bold text-blue-600">
                            R$ {parseFloat(cashFlowReport.netCashFlow || "0").toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                          </p>
                        </div>
                      </div>
                      
                      {cashFlowReport.monthlyData && cashFlowReport.monthlyData.length > 0 && (
                        <ResponsiveContainer width="100%" height={350}>
                          <AreaChart data={cashFlowReport.monthlyData}>
                            <defs>
                              <linearGradient id="colorInflow" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                                <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                              </linearGradient>
                              <linearGradient id="colorOutflow" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3}/>
                                <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                              </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                            <XAxis dataKey="month" />
                            <YAxis />
                            <Tooltip />
                            <Area type="monotone" dataKey="inflow" stroke="#10b981" fillOpacity={1} fill="url(#colorInflow)" />
                            <Area type="monotone" dataKey="outflow" stroke="#ef4444" fillOpacity={1} fill="url(#colorOutflow)" />
                          </AreaChart>
                        </ResponsiveContainer>
                      )}
                    </div>
                  ) : (
                    <p className="text-center text-muted-foreground py-12">
                      Nenhum dado disponível para o período selecionado
                    </p>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          <TabsContent value="statement" className="space-y-6">
            <motion.div variants={itemVariants}>
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>Extrato de Transações</CardTitle>
                      <CardDescription>Histórico detalhado de todas as transações</CardDescription>
                    </div>
                    <Button onClick={() => handleExportReport('statement')} className="gap-2">
                      <Download className="h-4 w-4" />
                      Exportar PDF
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {isStatementLoading ? (
                    <div className="flex items-center justify-center py-12">
                      <Loader2 className="h-8 w-8 animate-spin text-primary" />
                    </div>
                  ) : statementReport && statementReport.transactions && statementReport.transactions.length > 0 ? (
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Data</TableHead>
                            <TableHead>Descrição</TableHead>
                            <TableHead>Tipo</TableHead>
                            <TableHead className="text-right">Valor</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {statementReport.transactions.map((transaction: any) => (
                            <TableRow key={transaction.id}>
                              <TableCell>
                                {new Date(transaction.date).toLocaleDateString("pt-BR")}
                              </TableCell>
                              <TableCell>{transaction.description}</TableCell>
                              <TableCell>
                                <Badge variant={transaction.type === "income" ? "default" : "secondary"}>
                                  {transaction.type === "income" ? "Receita" : "Despesa"}
                                </Badge>
                              </TableCell>
                              <TableCell className="text-right">
                                <span className={`font-semibold ${transaction.type === "income" ? "text-green-600" : "text-red-600"}`}>
                                  {transaction.type === "income" ? "+" : "-"} R$ {parseFloat(transaction.amount).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                                </span>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  ) : (
                    <p className="text-center text-muted-foreground py-12">
                      Nenhuma transação encontrada para o período selecionado
                    </p>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>
        </Tabs>
      </motion.div>
    </AppLayout>
  );
}
