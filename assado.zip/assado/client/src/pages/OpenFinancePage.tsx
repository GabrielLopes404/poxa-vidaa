import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Building2, Link2, RefreshCw, Download } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function OpenFinancePage() {
  const [selectedProvider, setSelectedProvider] = useState<string | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: connections } = useQuery({
    queryKey: ["/api/open-finance/connections"],
    queryFn: async () => {
      const res = await fetch("/api/open-finance/connections", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch connections");
      return res.json();
    },
  });

  const { data: transactions } = useQuery({
    queryKey: ["/api/open-finance/transactions"],
    queryFn: async () => {
      const res = await fetch("/api/open-finance/transactions", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch transactions");
      return res.json();
    },
  });

  const connectBankMutation = useMutation({
    mutationFn: async (provider: string) => {
      const res = await fetch("/api/open-finance/connect", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ provider }),
      });
      if (!res.ok) throw new Error("Failed to connect");
      return res.json();
    },
    onSuccess: (data) => {
      if (data.authUrl) {
        window.open(data.authUrl, "_blank", "width=600,height=700");
      }
      toast({ title: "Conectando ao banco..." });
      queryClient.invalidateQueries({ queryKey: ["/api/open-finance/connections"] });
    },
  });

  const syncTransactionsMutation = useMutation({
    mutationFn: async (connectionId: string) => {
      const res = await fetch(`/api/open-finance/${connectionId}/sync`, {
        method: "POST",
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to sync");
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Transações sincronizadas!" });
      queryClient.invalidateQueries({ queryKey: ["/api/open-finance/transactions"] });
    },
  });

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold">Open Finance</h1>
          <Dialog>
            <DialogTrigger asChild>
              <Button>
                <Link2 className="mr-2 h-4 w-4" />
                Conectar Banco
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Conectar Conta Bancária</DialogTitle>
              </DialogHeader>
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  Selecione o provedor de Open Finance
                </p>
                <div className="grid grid-cols-2 gap-3">
                  <Button
                    variant="outline"
                    className="h-20 flex-col"
                    onClick={() => connectBankMutation.mutate("pluggy")}
                  >
                    <Building2 className="h-8 w-8 mb-2" />
                    Pluggy
                  </Button>
                  <Button
                    variant="outline"
                    className="h-20 flex-col"
                    onClick={() => connectBankMutation.mutate("belvo")}
                  >
                    <Building2 className="h-8 w-8 mb-2" />
                    Belvo
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <Tabs defaultValue="connections">
          <TabsList>
            <TabsTrigger value="connections">Conexões</TabsTrigger>
            <TabsTrigger value="transactions">Transações Sincronizadas</TabsTrigger>
          </TabsList>

          <TabsContent value="connections">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {connections?.map((conn: any) => (
                <Card key={conn.id}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">{conn.bankName}</CardTitle>
                        <CardDescription>{conn.provider}</CardDescription>
                      </div>
                      <Badge variant={conn.status === "active" ? "default" : "secondary"}>
                        {conn.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="text-sm text-muted-foreground">
                      Última sincronização: {conn.lastSync ? new Date(conn.lastSync).toLocaleDateString() : "Nunca"}
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full"
                      onClick={() => syncTransactionsMutation.mutate(conn.id)}
                    >
                      <RefreshCw className="mr-2 h-4 w-4" />
                      Sincronizar Agora
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="transactions">
            <Card>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Data</TableHead>
                    <TableHead>Descrição</TableHead>
                    <TableHead>Banco</TableHead>
                    <TableHead>Valor</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {transactions?.map((txn: any) => (
                    <TableRow key={txn.id}>
                      <TableCell>{new Date(txn.date).toLocaleDateString()}</TableCell>
                      <TableCell>{txn.description}</TableCell>
                      <TableCell>{txn.bankName}</TableCell>
                      <TableCell className={txn.amount > 0 ? "text-green-600" : "text-red-600"}>
                        R$ {Math.abs(txn.amount).toFixed(2)}
                      </TableCell>
                      <TableCell>
                        {txn.imported ? (
                          <Badge variant="default">Importado</Badge>
                        ) : (
                          <Badge variant="secondary">Pendente</Badge>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}
