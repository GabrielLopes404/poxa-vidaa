import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { PageContainer } from "@/components/PageContainer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Shield, Download, Trash2, FileText, Info, Cookie, CheckCircle2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";

export default function PrivacyCenterPage() {
  const { toast } = useToast();
  const [cookieConsent, setCookieConsent] = useState({
    necessary: true,
    analytics: true,
    marketing: false,
  });

  const downloadDataMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/privacy/download-data", {
        method: "POST",
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to download data");
      return response.blob();
    },
    onSuccess: (blob) => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `my-data-${new Date().toISOString()}.json`;
      a.click();
      toast({
        title: "Download iniciado",
        description: "Seus dados estão sendo baixados.",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível baixar seus dados. Tente novamente.",
        variant: "destructive",
      });
    },
  });

  const deleteAccountMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/privacy/delete-account", {
        method: "POST",
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to delete account");
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Conta excluída",
        description: "Sua conta foi marcada para exclusão. Você receberá um email de confirmação.",
      });
      setTimeout(() => {
        window.location.href = "/";
      }, 3000);
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível excluir sua conta. Tente novamente.",
        variant: "destructive",
      });
    },
  });

  const saveCookiePreferences = async () => {
    await fetch("/api/privacy/cookie-consent", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify(cookieConsent),
    });
    toast({
      title: "Preferências salvas",
      description: "Suas preferências de cookies foram atualizadas.",
    });
  };

  return (
    <PageContainer>
      <div className="space-y-6 max-w-4xl">
        <div className="flex items-center gap-3">
          <Shield className="h-8 w-8 text-primary" />
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Central de Privacidade</h1>
            <p className="text-muted-foreground">
              Gerencie seus dados pessoais e privacidade (LGPD/GDPR)
            </p>
          </div>
        </div>

        <Alert>
          <Info className="h-4 w-4" />
          <AlertDescription>
            De acordo com a Lei Geral de Proteção de Dados (LGPD) e o GDPR, você tem direito ao
            acesso, correção, exclusão e portabilidade dos seus dados pessoais.
          </AlertDescription>
        </Alert>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Seus Direitos
            </CardTitle>
            <CardDescription>
              Informações sobre como exercer seus direitos de privacidade
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <h3 className="font-semibold flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-600" />
                Direito ao Acesso
              </h3>
              <p className="text-sm text-muted-foreground">
                Você pode solicitar uma cópia de todos os dados pessoais que processamos sobre você.
              </p>
            </div>

            <Separator />

            <div className="space-y-2">
              <h3 className="font-semibold flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-600" />
                Direito à Correção
              </h3>
              <p className="text-sm text-muted-foreground">
                Você pode atualizar ou corrigir seus dados pessoais através das configurações da sua conta.
              </p>
            </div>

            <Separator />

            <div className="space-y-2">
              <h3 className="font-semibold flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-600" />
                Direito à Exclusão
              </h3>
              <p className="text-sm text-muted-foreground">
                Você pode solicitar a exclusão permanente de todos os seus dados pessoais.
              </p>
            </div>

            <Separator />

            <div className="space-y-2">
              <h3 className="font-semibold flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-600" />
                Direito à Portabilidade
              </h3>
              <p className="text-sm text-muted-foreground">
                Você pode baixar uma cópia estruturada dos seus dados em formato JSON.
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Download className="h-5 w-5" />
              Baixar Meus Dados
            </CardTitle>
            <CardDescription>
              Exportar todos os seus dados pessoais em formato estruturado
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Você receberá um arquivo JSON contendo todos os seus dados pessoais, incluindo:
            </p>
            <ul className="text-sm text-muted-foreground list-disc list-inside space-y-1">
              <li>Informações de perfil e conta</li>
              <li>Transações financeiras</li>
              <li>Clientes e faturas</li>
              <li>Configurações e preferências</li>
              <li>Logs de atividade</li>
            </ul>
            <Button
              onClick={() => downloadDataMutation.mutate()}
              disabled={downloadDataMutation.isPending}
              className="w-full sm:w-auto"
            >
              <Download className="mr-2 h-4 w-4" />
              {downloadDataMutation.isPending ? "Preparando download..." : "Baixar Meus Dados"}
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Cookie className="h-5 w-5" />
              Preferências de Cookies
            </CardTitle>
            <CardDescription>
              Gerencie como usamos cookies e tecnologias semelhantes
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="necessary-cookies" className="text-base">
                  Cookies Necessários
                </Label>
                <p className="text-sm text-muted-foreground">
                  Essenciais para o funcionamento do site. Não podem ser desativados.
                </p>
              </div>
              <Switch id="necessary-cookies" checked={true} disabled />
            </div>

            <Separator />

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="analytics-cookies" className="text-base">
                  Cookies Analíticos
                </Label>
                <p className="text-sm text-muted-foreground">
                  Ajudam a entender como você usa o site para melhorar a experiência.
                </p>
              </div>
              <Switch
                id="analytics-cookies"
                checked={cookieConsent.analytics}
                onCheckedChange={(checked) =>
                  setCookieConsent({ ...cookieConsent, analytics: checked })
                }
              />
            </div>

            <Separator />

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="marketing-cookies" className="text-base">
                  Cookies de Marketing
                </Label>
                <p className="text-sm text-muted-foreground">
                  Usados para exibir anúncios relevantes e medir campanhas.
                </p>
              </div>
              <Switch
                id="marketing-cookies"
                checked={cookieConsent.marketing}
                onCheckedChange={(checked) =>
                  setCookieConsent({ ...cookieConsent, marketing: checked })
                }
              />
            </div>

            <Button onClick={saveCookiePreferences} className="w-full sm:w-auto">
              Salvar Preferências
            </Button>
          </CardContent>
        </Card>

        <Card className="border-destructive">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-destructive">
              <Trash2 className="h-5 w-5" />
              Excluir Minha Conta
            </CardTitle>
            <CardDescription>
              Remover permanentemente todos os seus dados do sistema
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert variant="destructive">
              <Info className="h-4 w-4" />
              <AlertDescription>
                <strong>Atenção:</strong> Esta ação é irreversível. Todos os seus dados,
                incluindo transações, clientes e faturas, serão permanentemente excluídos.
              </AlertDescription>
            </Alert>

            <p className="text-sm text-muted-foreground">
              Ao solicitar a exclusão da sua conta:
            </p>
            <ul className="text-sm text-muted-foreground list-disc list-inside space-y-1">
              <li>Você receberá um email de confirmação</li>
              <li>Terá 30 dias para cancelar a solicitação</li>
              <li>Após 30 dias, todos os dados serão excluídos permanentemente</li>
              <li>Você não poderá mais acessar sua conta</li>
            </ul>

            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" className="w-full sm:w-auto">
                  <Trash2 className="mr-2 h-4 w-4" />
                  Excluir Minha Conta
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Você tem certeza absoluta?</AlertDialogTitle>
                  <AlertDialogDescription>
                    Esta ação não pode ser desfeita. Isso excluirá permanentemente sua conta
                    e removerá todos os seus dados de nossos servidores.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={() => deleteAccountMutation.mutate()}
                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                  >
                    Sim, excluir minha conta
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Mais Informações</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <p className="text-sm text-muted-foreground">
              Para mais informações sobre como processamos seus dados, consulte:
            </p>
            <div className="flex flex-col gap-2">
              <Button variant="link" className="justify-start p-0 h-auto" asChild>
                <a href="/privacidade">Política de Privacidade</a>
              </Button>
              <Button variant="link" className="justify-start p-0 h-auto" asChild>
                <a href="/termos">Termos de Uso</a>
              </Button>
              <Button variant="link" className="justify-start p-0 h-auto" asChild>
                <a href="/lgpd">Informações LGPD</a>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </PageContainer>
  );
}
