import { storage } from "./storage";

interface CategoryPrediction {
  category: string;
  confidence: number;
}

const COMMON_PATTERNS: Record<string, string[]> = {
  salary: ["salário", "salario", "salary", "pagamento", "folha"],
  rent: ["aluguel", "rent", "locação", "locacao"],
  utilities: ["luz", "água", "agua", "gas", "internet", "telefone", "celular"],
  food: ["mercado", "supermercado", "restaurante", "ifood", "uber eats", "padaria"],
  transport: ["uber", "99", "gasolina", "combustível", "combustivel", "transporte"],
  health: ["farmácia", "farmacia", "hospital", "médico", "medico", "plano de saúde", "saude"],
  education: ["escola", "faculdade", "curso", "livro", "educação", "educacao"],
  entertainment: ["cinema", "netflix", "spotify", "streaming", "show", "teatro"],
  shopping: ["loja", "shopping", "mercado livre", "amazon", "compra"],
  tax: ["imposto", "taxa", "tributo", "darf", "iptu", "ipva"],
};

class MLCategorizationService {
  async categorizeTransaction(description: string, amount: number): Promise<CategoryPrediction> {
    const lowerDesc = description.toLowerCase();

    for (const [category, patterns] of Object.entries(COMMON_PATTERNS)) {
      for (const pattern of patterns) {
        if (lowerDesc.includes(pattern)) {
          const confidence = this.calculateConfidence(lowerDesc, pattern);
          return { category, confidence };
        }
      }
    }

    return { category: "other", confidence: 0.3 };
  }

  private calculateConfidence(description: string, pattern: string): number {
    const exactMatch = description === pattern;
    if (exactMatch) return 0.95;

    const startsWith = description.startsWith(pattern);
    if (startsWith) return 0.85;

    const contains = description.includes(pattern);
    if (contains) {
      const ratio = pattern.length / description.length;
      return Math.min(0.7 + ratio * 0.2, 0.9);
    }

    return 0.5;
  }

  async trainFromHistory(organizationId: string): Promise<void> {
    const transactions = await storage.getTransactionsByOrganization(organizationId);

    const categorizedTransactions = transactions.filter(t => t.categoryId);

    console.log(`Training from ${categorizedTransactions.length} categorized transactions`);
  }

  async bulkCategorize(organizationId: string): Promise<{ updated: number; predictions: Array<{ transactionId: string; description: string; category: string; confidence: number }> }> {
    const transactions = await storage.getTransactionsByOrganization(organizationId);
    const uncategorized = transactions.filter(t => !t.categoryId);

    const categories = await storage.getCategoriesByOrganization(organizationId);
    
    const categoryMap = new Map<string, string>();
    for (const cat of categories) {
      categoryMap.set(cat.name.toLowerCase(), cat.id);
    }

    const predictions = [];
    let updated = 0;

    for (const transaction of uncategorized) {
      const prediction = await this.categorizeTransaction(
        transaction.description,
        parseFloat(transaction.amount)
      );

      if (prediction.confidence > 0.7) {
        let categoryId = categoryMap.get(prediction.category.toLowerCase());

        if (!categoryId) {
          const newCategory = await storage.createCategory({
            organizationId,
            name: prediction.category,
            type: "expense",
          });
          categoryId = newCategory.id;
          categoryMap.set(prediction.category.toLowerCase(), categoryId);
        }

        await storage.updateTransaction(transaction.id, {
          categoryId,
        });
        updated++;
      }

      predictions.push({
        transactionId: transaction.id,
        description: transaction.description,
        ...prediction,
      });
    }

    return { updated, predictions };
  }
}

export const mlCategorizationService = new MLCategorizationService();
