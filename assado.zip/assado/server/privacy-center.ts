import { Router } from "express";
import { db } from "./db";
import { users, termsAcceptance, organizations, customers, invoices, transactions, documents, bankAccounts } from "@shared/schema";
import { eq, and } from "drizzle-orm";
import { logAuditTrail } from "./audit-trail";

const router = Router();

function requireAuth(req: any, res: any, next: any) {
  if (!req.user) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  next();
}

router.post("/terms/accept", requireAuth, async (req, res) => {
  try {
    const userId = req.user!.id;
    const { termsType, termsVersion } = req.body;

    if (!termsType || !termsVersion) {
      return res.status(400).json({ message: "termsType and termsVersion are required" });
    }

    const ipAddress = req.ip || req.socket.remoteAddress || 'unknown';
    const userAgent = req.headers['user-agent'] || 'unknown';

    await db.insert(termsAcceptance).values({
      userId,
      termsType,
      termsVersion,
      ipAddress,
      userAgent
    });

    await logAuditTrail({
      organizationId: req.user!.organizationId || undefined,
      userId,
      action: 'terms_accepted',
      metadata: { termsType, termsVersion },
      ipAddress,
      userAgent
    });

    res.json({ message: "Terms accepted successfully" });
  } catch (error) {
    console.error("Failed to accept terms:", error);
    res.status(500).json({ message: "Failed to accept terms" });
  }
});

router.get("/terms/history", requireAuth, async (req, res) => {
  try {
    const userId = req.user!.id;

    const history = await db.query.termsAcceptance.findMany({
      where: eq(termsAcceptance.userId, userId),
      orderBy: (terms, { desc }) => [desc(terms.acceptedAt)]
    });

    res.json(history);
  } catch (error) {
    console.error("Failed to get terms history:", error);
    res.status(500).json({ message: "Failed to get terms history" });
  }
});

router.post("/data/export", requireAuth, async (req, res) => {
  try {
    const userId = req.user!.id;
    const organizationId = req.user!.organizationId;

    const user = await db.query.users.findFirst({
      where: eq(users.id, userId)
    });

    const userOrganization = organizationId ? await db.query.organizations.findFirst({
      where: eq(organizations.id, organizationId)
    }) : null;

    const userCustomers = organizationId ? await db.query.customers.findMany({
      where: eq(customers.organizationId, organizationId)
    }) : [];

    const userInvoices = organizationId ? await db.query.invoices.findMany({
      where: eq(invoices.organizationId, organizationId)
    }) : [];

    const userTransactions = organizationId ? await db.query.transactions.findMany({
      where: eq(transactions.organizationId, organizationId)
    }) : [];

    const userDocuments = organizationId ? await db.query.documents.findMany({
      where: eq(documents.organizationId, organizationId)
    }) : [];

    const userBankAccounts = organizationId ? await db.query.bankAccounts.findMany({
      where: eq(bankAccounts.organizationId, organizationId)
    }) : [];

    const termsHistory = await db.query.termsAcceptance.findMany({
      where: eq(termsAcceptance.userId, userId)
    });

    const exportData = {
      user: {
        ...user,
        password: undefined,
        twoFactorSecret: undefined,
        resetToken: undefined,
        verificationToken: undefined
      },
      organization: userOrganization,
      customers: userCustomers,
      invoices: userInvoices,
      transactions: userTransactions,
      documents: userDocuments,
      bankAccounts: userBankAccounts,
      termsAcceptance: termsHistory,
      exportedAt: new Date().toISOString()
    };

    await logAuditTrail({
      organizationId,
      userId,
      action: 'data_exported',
      ipAddress: req.ip || req.socket.remoteAddress,
      userAgent: req.headers['user-agent']
    });

    res.json(exportData);
  } catch (error) {
    console.error("Failed to export data:", error);
    res.status(500).json({ message: "Failed to export data" });
  }
});

router.post("/account/delete", requireAuth, async (req, res) => {
  try {
    const userId = req.user!.id;
    const { password, confirmation } = req.body;

    if (confirmation !== "DELETE MY ACCOUNT") {
      return res.status(400).json({ message: "Invalid confirmation text" });
    }

    const user = await db.query.users.findFirst({
      where: eq(users.id, userId)
    });

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    const bcrypt = await import("bcryptjs");
    const validPassword = await bcrypt.compare(password, user.password);

    if (!validPassword) {
      return res.status(401).json({ message: "Invalid password" });
    }

    const anonymizedEmail = `deleted_${userId}@anonymized.local`;
    const anonymizedName = `Deleted User ${userId.slice(0, 8)}`;

    await db.update(users)
      .set({
        email: anonymizedEmail,
        name: anonymizedName,
        password: await bcrypt.hash(Math.random().toString(36), 12),
        deletedAt: new Date(),
        anonymizedAt: new Date(),
        twoFactorSecret: null,
        twoFactorEnabled: false,
        twoFactorBackupCodes: null,
        resetToken: null,
        verificationToken: null,
        avatar: null
      })
      .where(eq(users.id, userId));

    await logAuditTrail({
      organizationId: user.organizationId || undefined,
      userId,
      action: 'account_deleted',
      metadata: { reason: 'user_request' },
      ipAddress: req.ip || req.socket.remoteAddress || undefined,
      userAgent: req.headers['user-agent'] || undefined
    });

    req.logout((err) => {
      if (err) {
        console.error("Logout error:", err);
      }
    });

    res.json({ message: "Account deleted and data anonymized successfully" });
  } catch (error) {
    console.error("Failed to delete account:", error);
    res.status(500).json({ message: "Failed to delete account" });
  }
});

export default router;
