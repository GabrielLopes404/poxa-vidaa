import schedule from "node-schedule";
import { storage } from "./storage";
import { sendEmail, generateInvoiceEmail } from "./email";
import { log } from "./vite";
import { wsService } from "./websocket";

export class InvoiceReminderService {
  private isRunning: boolean = false;

  start() {
    if (this.isRunning) {
      log("Invoice reminder service already running");
      return;
    }

    schedule.scheduleJob("0 9 * * *", async () => {
      log("🔔 Running invoice reminder check (9:00 AM)...");
      await this.checkAndSendReminders();
    });

    this.isRunning = true;
    log("✅ Invoice reminder service started (daily at 9:00 AM)");
  }

  async checkAndSendReminders() {
    try {
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const threeDaysFromNow = new Date(today);
      threeDaysFromNow.setDate(threeDaysFromNow.getDate() + 3);

      const sevenDaysFromNow = new Date(today);
      sevenDaysFromNow.setDate(sevenDaysFromNow.getDate() + 7);

      const organizations = await storage.getAllOrganizations();

      for (const org of organizations) {
        const invoices = await storage.getInvoicesByOrganization(org.id);

        for (const invoice of invoices) {
          if (invoice.status === "paid" || invoice.status === "canceled") {
            continue;
          }

          const dueDate = new Date(invoice.dueDate!);
          dueDate.setHours(0, 0, 0, 0);

          const shouldSendReminder = 
            (dueDate.getTime() === threeDaysFromNow.getTime()) ||
            (dueDate.getTime() === today.getTime()) ||
            (dueDate < today && invoice.status !== "overdue");

          if (shouldSendReminder) {
            await this.sendReminderEmail(invoice, org);
            
            if (dueDate < today && invoice.status !== "overdue") {
              await storage.updateInvoice(invoice.id, { status: "overdue" });
              
              await storage.createNotification({
                organizationId: org.id,
                userId: null,
                type: "invoice_due",
                title: "Fatura Vencida",
                message: `Fatura ${invoice.invoiceNumber} venceu e está em atraso`,
                metadata: JSON.stringify({ invoiceId: invoice.id }),
                read: false,
              });

              wsService.notifyOrganization(org.id, "invoice:overdue", {
                invoiceId: invoice.id,
                invoiceNumber: invoice.invoiceNumber,
              });
            }
          }
        }
      }

      log("✅ Invoice reminder check completed");
    } catch (error) {
      log(`❌ Invoice reminder check failed: ${error}`);
    }
  }

  private async sendReminderEmail(invoice: any, organization: any) {
    try {
      const customer = await storage.getCustomer(invoice.customerId);
      if (!customer) return;

      const dueDate = new Date(invoice.dueDate);
      const today = new Date();
      const daysUntilDue = Math.ceil((dueDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

      let subject = "";
      if (daysUntilDue < 0) {
        subject = `⚠️ Fatura ${invoice.invoiceNumber} - VENCIDA`;
      } else if (daysUntilDue === 0) {
        subject = `🔔 Fatura ${invoice.invoiceNumber} vence HOJE`;
      } else {
        subject = `🔔 Fatura ${invoice.invoiceNumber} vence em ${daysUntilDue} dias`;
      }

      const html = generateInvoiceEmail({
        invoiceNumber: invoice.invoiceNumber,
        customerName: customer.name,
        customerEmail: customer.email,
        amount: invoice.amount,
        dueDate: dueDate.toLocaleDateString("pt-BR"),
        description: invoice.description || "N/A",
        issueDate: new Date(invoice.issueDate).toLocaleDateString("pt-BR"),
        organizationName: organization.name,
      });

      await sendEmail({
        to: customer.email,
        subject,
        html,
        text: `Lembrete: Fatura ${invoice.invoiceNumber} no valor de R$ ${invoice.amount} vence em ${dueDate.toLocaleDateString("pt-BR")}`,
      });

      log(`✉️ Reminder sent for invoice ${invoice.invoiceNumber} to ${customer.email}`);
    } catch (error) {
      log(`Failed to send reminder for invoice ${invoice.id}: ${error}`);
    }
  }

  stop() {
    schedule.gracefulShutdown();
    this.isRunning = false;
    log("Invoice reminder service stopped");
  }
}

export const invoiceReminderService = new InvoiceReminderService();
