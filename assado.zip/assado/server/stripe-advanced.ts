import Stripe from "stripe";

const stripe = process.env.STRIPE_SECRET_KEY 
  ? new Stripe(process.env.STRIPE_SECRET_KEY, { apiVersion: "2024-11-20.acacia" })
  : null;

export interface TrialConfig {
  trialDays: number;
  requiresPaymentMethod?: boolean;
}

export interface CouponConfig {
  percentOff?: number;
  amountOff?: number;
  currency?: string;
  duration: "once" | "repeating" | "forever";
  durationInMonths?: number;
  maxRedemptions?: number;
  redeemBy?: Date;
}

export class StripeAdvancedService {
  async createCheckoutSessionWithTrial(
    priceId: string,
    customerId: string,
    successUrl: string,
    cancelUrl: string,
    trialConfig: TrialConfig
  ): Promise<string> {
    if (!stripe) throw new Error("Stripe not configured");

    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      payment_method_types: ["card"],
      line_items: [{ price: priceId, quantity: 1 }],
      mode: "subscription",
      success_url: successUrl,
      cancel_url: cancelUrl,
      subscription_data: {
        trial_period_days: trialConfig.trialDays,
      },
      payment_method_collection: trialConfig.requiresPaymentMethod ? "always" : "if_required",
    });

    return session.url || "";
  }

  async createCoupon(code: string, config: CouponConfig): Promise<Stripe.Coupon> {
    if (!stripe) throw new Error("Stripe not configured");

    const couponParams: Stripe.CouponCreateParams = {
      id: code,
      duration: config.duration,
      currency: config.currency || "brl",
    };

    if (config.percentOff) {
      couponParams.percent_off = config.percentOff;
    } else if (config.amountOff) {
      couponParams.amount_off = config.amountOff;
    }

    if (config.durationInMonths) {
      couponParams.duration_in_months = config.durationInMonths;
    }

    if (config.maxRedemptions) {
      couponParams.max_redemptions = config.maxRedemptions;
    }

    if (config.redeemBy) {
      couponParams.redeem_by = Math.floor(config.redeemBy.getTime() / 1000);
    }

    return await stripe.coupons.create(couponParams);
  }

  async applyCouponToCheckout(sessionId: string, couponId: string): Promise<void> {
    if (!stripe) throw new Error("Stripe not configured");

    await stripe.checkout.sessions.update(sessionId, {
      discounts: [{ coupon: couponId }],
    });
  }

  async previewUpgradeProration(
    subscriptionId: string,
    newPriceId: string
  ): Promise<{
    immediateCharge: number;
    nextBillingAmount: number;
    proratedAmount: number;
    unusedAmount: number;
  }> {
    if (!stripe) throw new Error("Stripe not configured");

    const subscription = await stripe.subscriptions.retrieve(subscriptionId);
    const currentPeriodEnd = subscription.current_period_end;

    const invoice = await stripe.invoices.retrieveUpcoming({
      customer: subscription.customer as string,
      subscription: subscriptionId,
      subscription_items: [{
        id: subscription.items.data[0].id,
        price: newPriceId,
      }],
      subscription_proration_date: Math.floor(Date.now() / 1000),
    });

    const proratedAmount = invoice.lines.data
      .filter(line => line.proration)
      .reduce((sum, line) => sum + (line.amount || 0), 0);

    const unusedAmount = invoice.lines.data
      .filter(line => line.proration && (line.amount || 0) < 0)
      .reduce((sum, line) => sum + Math.abs(line.amount || 0), 0);

    return {
      immediateCharge: invoice.amount_due / 100,
      nextBillingAmount: invoice.total / 100,
      proratedAmount: proratedAmount / 100,
      unusedAmount: unusedAmount / 100,
    };
  }

  async updateSubscriptionWithProration(
    subscriptionId: string,
    newPriceId: string
  ): Promise<Stripe.Subscription> {
    if (!stripe) throw new Error("Stripe not configured");

    const subscription = await stripe.subscriptions.retrieve(subscriptionId);

    return await stripe.subscriptions.update(subscriptionId, {
      items: [{
        id: subscription.items.data[0].id,
        price: newPriceId,
      }],
      proration_behavior: "always_invoice",
    });
  }

  async enforceUsageLimits(
    organizationId: string,
    planType: "personal" | "business" | "enterprise"
  ): Promise<{ allowed: boolean; limit: number; current: number }> {
    const limits = {
      personal: { transactions: 100, users: 1, bankAccounts: 2 },
      business: { transactions: 1000, users: 5, bankAccounts: 10 },
      enterprise: { transactions: -1, users: -1, bankAccounts: -1 },
    };

    const planLimits = limits[planType];
    
    return {
      allowed: true,
      limit: planLimits.transactions,
      current: 0,
    };
  }

  async setupDunningManagement(customerId: string): Promise<void> {
    if (!stripe) throw new Error("Stripe not configured");

    await stripe.customers.update(customerId, {
      invoice_settings: {
        default_payment_method: undefined,
      },
    });
  }

  async retryFailedPayment(invoiceId: string): Promise<Stripe.Invoice> {
    if (!stripe) throw new Error("Stripe not configured");

    return await stripe.invoices.pay(invoiceId, {
      forgive: false,
    });
  }
}

export const stripeAdvancedService = new StripeAdvancedService();
