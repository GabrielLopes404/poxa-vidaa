import express, { type Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import session from "express-session";
import connectPgSimple from "connect-pg-simple";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import rateLimit from "express-rate-limit";
import helmet from "helmet";
import cors from "cors";
import crypto from "crypto";
import { db } from "./db";
import { storage } from "./storage";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";
import bcrypt from "bcryptjs";
import XLSX from "xlsx";
import { Parser } from "json2csv";
import { getCsrfToken, csrfProtection } from "./csrf";
import { getPaginationParams, createPaginatedResponse } from "./pagination";
import { healthCheck, liveness, readiness } from "./health";
import { register as metricsRegister } from "./metrics";
import {
  insertUserSchema,
  insertOrganizationSchema,
  createCustomerSchema,
  createInvoiceSchema,
  createCategorySchema,
  createBankAccountSchema,
  createCostCenterSchema,
  createTagSchema,
  createTransactionSchema,
  createDocumentSchema,
  createReconciliationSchema,
  type User,
} from "@shared/schema";

// Extend Express session to include user
declare global {
  namespace Express {
    interface User {
      id: string;
      username: string;
      email: string;
      name: string;
      organizationId: string | null;
      role: "OWNER" | "ADMIN" | "CUSTOMER";
      emailVerified: boolean;
    }
  }
}

// Middleware to check if user is authenticated
function isAuthenticated(req: Request, res: Response, next: NextFunction) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
}

// Middleware to check if user is admin or owner
function isAdminOrOwner(req: Request, res: Response, next: NextFunction) {
  if (req.isAuthenticated() && (req.user!.role === "ADMIN" || req.user!.role === "OWNER")) {
    return next();
  }
  res.status(403).json({ message: "Forbidden: Admin or Owner access required" });
}

// Validation middleware
function validateBody(schema: z.ZodSchema) {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      schema.parse(req.body);
      next();
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: fromZodError(error).message });
      } else {
        res.status(400).json({ message: "Invalid request body" });
      }
    }
  };
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Security middleware
  app.use(helmet({
    contentSecurityPolicy: false, // Vite handles CSP in dev
  }));
  
  // CORS configuration - STRICT PRODUCTION CONFIG
  const allowedOrigins = process.env.NODE_ENV === "production"
    ? (process.env.ALLOWED_ORIGINS?.split(',').map(o => o.trim()) || [])
    : true;

  app.use(cors({
    origin: (origin, callback) => {
      if (process.env.NODE_ENV !== "production") {
        return callback(null, true);
      }
      
      if (!origin) {
        return callback(null, true);
      }
      
      if (Array.isArray(allowedOrigins) && allowedOrigins.includes(origin)) {
        callback(null, true);
      } else {
        callback(new Error('Not allowed by CORS'));
      }
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-CSRF-Token'],
  }));

  // Rate limiting
  const limiter = rateLimit({
    windowMs: 1 * 60 * 1000, // 1 minute
    max: 100, // 100 requests per minute
    message: "Muitas requisições, tente novamente em breve.",
    standardHeaders: true,
    legacyHeaders: false,
  });

  const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 5, // 5 login attempts
    message: "Muitas tentativas de login, tente novamente em 15 minutos.",
    skipSuccessfulRequests: true,
  });

  const passwordResetLimiter = rateLimit({
    windowMs: 60 * 60 * 1000, // 1 hour
    max: 3, // 3 password reset attempts per hour
    message: "Muitas tentativas de redefinição de senha. Tente novamente em 1 hora.",
    standardHeaders: true,
    legacyHeaders: false,
  });

  app.use("/api/", limiter);

  // Session configuration with PostgreSQL store
  const PgSession = connectPgSimple(session);
  
  if (!process.env.SESSION_SECRET) {
    throw new Error("SESSION_SECRET environment variable is required");
  }

  app.use(
    session({
      store: new PgSession({
        conObject: {
          connectionString: process.env.DATABASE_URL,
        },
        tableName: 'session',
        createTableIfMissing: true,
      }),
      secret: process.env.SESSION_SECRET,
      resave: false,
      saveUninitialized: false,
      cookie: {
        secure: process.env.NODE_ENV === "production",
        httpOnly: true,
        maxAge: 1000 * 60 * 60 * 24 * 7, // 7 days
        sameSite: process.env.NODE_ENV === "production" ? "strict" : "lax",
      },
    })
  );

  // Passport configuration
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(
      { usernameField: "email" },
      async (email, password, done) => {
        try {
          const user = await storage.getUserByEmail(email);
          if (!user) {
            return done(null, false, { message: "Invalid credentials" });
          }

          const isValid = await bcrypt.compare(password, user.password);
          if (!isValid) {
            return done(null, false, { message: "Invalid credentials" });
          }

          return done(null, {
            id: user.id,
            username: user.username,
            email: user.email,
            name: user.name || user.username,
            organizationId: user.organizationId,
            role: user.role as "OWNER" | "ADMIN" | "CUSTOMER",
            emailVerified: user.emailVerified || false,
          });
        } catch (error) {
          return done(error);
        }
      }
    )
  );

  passport.serializeUser((user: any, done) => {
    console.log("[Passport] Serializing user:", user.id);
    done(null, user.id);
  });

  passport.deserializeUser(async (id: string, done) => {
    try {
      console.log("[Passport] Deserializing user ID:", id);
      const user = await storage.getUser(id);
      if (!user) {
        console.log("[Passport] User not found:", id);
        return done(null, false);
      }
      const sessionUser = {
        id: user.id,
        username: user.username,
        email: user.email,
        name: user.name || user.username,
        organizationId: user.organizationId,
        role: user.role as "OWNER" | "ADMIN" | "CUSTOMER",
        emailVerified: user.emailVerified || false,
      };
      console.log("[Passport] User deserialized successfully:", sessionUser.email);
      done(null, sessionUser);
    } catch (error) {
      console.error("[Passport] Error deserializing:", error);
      done(error);
    }
  });

  // TEMPORARY: Create admin user (remove in production)
  app.post("/api/create-admin-temp", async (req: Request, res: Response) => {
    try {
      const hashedPassword = await bcrypt.hash("Admin123!", 10);
      
      // Check if admin already exists
      const existingAdmin = await storage.getUserByEmail("admin@lucrei.com");
      if (existingAdmin) {
        return res.json({ message: "Admin já existe. Use: admin@lucrei.com / Admin123!" });
      }
      
      // Create organization
      const orgId = crypto.randomUUID();
      const organization = await storage.createOrganization({
        id: orgId,
        name: "LUCREI Empresa",
        slug: "lucrei-" + crypto.randomBytes(4).toString("hex"),
        createdAt: new Date(),
      });
      
      // Create admin user
      const userId = crypto.randomUUID();
      await storage.createUser({
        id: userId,
        email: "admin@lucrei.com",
        username: "admin",
        password: hashedPassword,
        name: "Admin LUCREI",
        organizationId: organization.id,
        role: "OWNER",
        emailVerified: true,
        createdAt: new Date(),
      });
      
      res.json({ 
        message: "✅ Admin criado com sucesso!",
        email: "admin@lucrei.com",
        password: "Admin123!",
        note: "Faça login agora!"
      });
    } catch (error) {
      console.error("Error creating admin:", error);
      res.status(500).json({ message: "Erro ao criar admin", error: String(error) });
    }
  });

  // CSRF TOKEN ROUTE (must be before CSRF protection middleware)
  app.get("/api/csrf-token", getCsrfToken);

  // Apply CSRF protection to all state-changing routes (POST, PUT, DELETE, PATCH)
  app.use("/api/", (req: Request, res: Response, next: NextFunction) => {
    // Skip CSRF check for GET, HEAD, OPTIONS (safe methods)
    if (req.method === 'GET' || req.method === 'HEAD' || req.method === 'OPTIONS') {
      return next();
    }
    // Apply CSRF protection to ALL state-changing requests
    return csrfProtection(req, res, next);
  });

  // AUTH ROUTES
  // Register
  app.post("/api/auth/register", authLimiter, async (req: Request, res: Response) => {
    try {
      let { email, password, username, name, organizationName } = req.body;

      // Normalize inputs on server-side to prevent bypass
      email = email?.toLowerCase().trim();
      username = username?.toLowerCase().trim();
      name = name?.trim();
      organizationName = organizationName?.trim();

      // Validate inputs
      if (!email || !password || !username || !name) {
        return res.status(400).json({ message: "Todos os campos são obrigatórios" });
      }

      // Validate username format (only lowercase letters, numbers, underscore)
      if (!/^[a-z0-9_]{3,}$/.test(username)) {
        return res.status(400).json({ message: "Nome de usuário inválido. Use apenas letras minúsculas, números e underscore (mínimo 3 caracteres)" });
      }

      // Validate email format
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        return res.status(400).json({ message: "Email inválido" });
      }

      // Check if user with email already exists
      const existingUserByEmail = await storage.getUserByEmail(email);
      if (existingUserByEmail) {
        return res.status(400).json({ message: "Este email já está em uso" });
      }

      // Check if user with username already exists (case-insensitive)
      const existingUserByUsername = await storage.getUserByUsername(username);
      if (existingUserByUsername) {
        return res.status(400).json({ message: "Este nome de usuário já está em uso" });
      }

      // Hash password with 12 rounds for security
      const hashedPassword = await bcrypt.hash(password, 12);

      // Create organization first
      const organization = await storage.createOrganization({
        name: organizationName || `${name}'s Organization`,
        email,
      });

      // Create user
      const user = await storage.createUser({
        username,
        email,
        password: hashedPassword,
        name,
        organizationId: organization.id,
        role: "OWNER",
        emailVerified: false,
      });

      // Log activity
      await storage.createActivity({
        organizationId: organization.id,
        userId: user.id,
        action: "user_registered",
        entityType: "user",
        entityId: user.id,
        details: JSON.stringify({ email }),
      });

      // Auto login after registration with session regeneration for security
      req.login(
        {
          id: user.id,
          username: user.username,
          email: user.email,
          name: user.name || user.username,
          organizationId: user.organizationId,
          role: user.role as "OWNER" | "ADMIN" | "CUSTOMER",
          emailVerified: user.emailVerified || false,
        },
        (err) => {
          if (err) {
            return res.status(500).json({ message: "Registration successful but login failed" });
          }
          
          // Regenerate session to prevent session fixation attacks
          req.session.regenerate((regenerateErr) => {
            if (regenerateErr) {
              console.error("Session regeneration error:", regenerateErr);
            }
            
            res.json({
              user: {
                id: user.id,
                username: user.username,
                email: user.email,
                name: user.name,
                organizationId: user.organizationId,
                role: user.role,
                emailVerified: user.emailVerified,
              },
            });
          });
        }
      );
    } catch (error) {
      console.error("Registration error:", error);
      res.status(500).json({ message: "Registration failed" });
    }
  });

  // Login
  app.post("/api/auth/login", authLimiter, (req: Request, res: Response, next: NextFunction) => {
    passport.authenticate("local", (err: any, user: any, info: any) => {
      if (err) {
        return res.status(500).json({ message: "Login failed" });
      }
      if (!user) {
        return res.status(401).json({ message: info?.message || "Invalid credentials" });
      }
      req.login(user, (err) => {
        if (err) {
          return res.status(500).json({ message: "Login failed" });
        }
        
        // Regenerate session to prevent session fixation attacks
        req.session.regenerate((regenerateErr) => {
          if (regenerateErr) {
            console.error("Session regeneration error:", regenerateErr);
          }
          
          res.json({ user });
        });
      });
    })(req, res, next);
  });

  // Logout
  app.post("/api/auth/logout", (req: Request, res: Response) => {
    req.logout(() => {
      res.json({ message: "Logged out successfully" });
    });
  });

  // Get current user
  app.get("/api/auth/me", isAuthenticated, (req: Request, res: Response) => {
    res.json({ user: req.user });
  });

  // Email Verification Routes
  app.post("/api/auth/send-verification-email", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { sendVerificationEmail } = await import("./email-verification");
      const baseUrl = `${req.protocol}://${req.get("host")}`;
      const sent = await sendVerificationEmail(
        req.user!.id,
        req.user!.email,
        req.user!.name || req.user!.username,
        baseUrl
      );
      
      if (sent) {
        res.json({ message: "Email de verificação enviado com sucesso" });
      } else {
        res.status(500).json({ message: "Falha ao enviar email de verificação" });
      }
    } catch (error) {
      res.status(500).json({ message: "Erro ao enviar email de verificação" });
    }
  });

  app.get("/api/auth/verify-email", async (req: Request, res: Response) => {
    try {
      const { token } = req.query;
      if (!token || typeof token !== "string") {
        return res.status(400).json({ message: "Token inválido" });
      }

      const { verifyEmailToken } = await import("./email-verification");
      const result = await verifyEmailToken(token);

      if (result.success) {
        res.json({ message: result.message, userId: result.userId });
      } else {
        res.status(400).json({ message: result.message });
      }
    } catch (error) {
      res.status(500).json({ message: "Erro ao verificar email" });
    }
  });

  // Session Management Routes
  app.post("/api/auth/logout-all", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { sessionManagementService } = await import("./session-management");
      const count = await sessionManagementService.logoutAllSessions(req.user!.id);
      res.json({ message: `${count} sessões encerradas com sucesso` });
    } catch (error) {
      res.status(500).json({ message: "Erro ao encerrar sessões" });
    }
  });

  app.post("/api/auth/logout-all-sessions", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { sessionManagementService } = await import("./session-management");
      const count = await sessionManagementService.logoutAllSessions(req.user!.id);
      req.logout(() => {
        res.json({ message: `${count} sessões encerradas com sucesso` });
      });
    } catch (error) {
      res.status(500).json({ message: "Erro ao encerrar sessões" });
    }
  });

  app.get("/api/sessions", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { sessionManagementService } = await import("./session-management");
      const count = await sessionManagementService.getActiveSessions(req.user!.id);
      res.json({ count });
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar sessões ativas" });
    }
  });

  app.get("/api/auth/active-sessions", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { sessionManagementService } = await import("./session-management");
      const count = await sessionManagementService.getActiveSessions(req.user!.id);
      res.json({ count });
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar sessões ativas" });
    }
  });

  // Password Reset with Rate Limiting
  app.post("/api/auth/forgot-password", passwordResetLimiter, async (req: Request, res: Response) => {
    try {
      const { email } = req.body;
      if (!email) {
        return res.status(400).json({ message: "Email é obrigatório" });
      }

      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.json({ message: "Se o email existir, um link de redefinição será enviado" });
      }

      const resetToken = crypto.randomBytes(32).toString("hex");
      const resetTokenExpiry = new Date(Date.now() + 60 * 60 * 1000);

      await storage.updateUser(user.id, {
        resetToken,
        resetTokenExpiry,
      });

      const { sendEmail, generatePasswordResetEmail } = await import("./email");
      const resetLink = `${req.protocol}://${req.get("host")}/reset-password?token=${resetToken}`;
      const html = generatePasswordResetEmail(resetLink, user.name || user.username);

      await sendEmail({
        to: email,
        subject: "Redefinir Senha - LUCREI",
        html,
        text: `Clique no link para redefinir sua senha: ${resetLink}`,
      });

      res.json({ message: "Se o email existir, um link de redefinição será enviado" });
    } catch (error) {
      res.status(500).json({ message: "Erro ao processar solicitação" });
    }
  });

  // DASHBOARD ENHANCED ROUTES
  app.get("/api/dashboard/enhanced", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { startDate, endDate } = req.query;
      const data = {
        totalRevenue: "15000.00",
        totalExpenses: "8500.00",
        profit: "6500.00",
        monthlyData: [
          { month: "Jan", receitas: 12000, despesas: 7000 },
          { month: "Fev", receitas: 15000, despesas: 8500 },
          { month: "Mar", receitas: 18000, despesas: 10000 },
        ],
        categoryData: [
          { name: "Alimentação", value: 3500 },
          { name: "Transporte", value: 2000 },
          { name: "Saúde", value: 1500 },
        ],
      };
      res.json(data);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard data" });
    }
  });

  app.get("/api/dashboard/comparison", isAuthenticated, async (req: Request, res: Response) => {
    try {
      res.json({
        revenueGrowth: 15.5,
        expenseGrowth: 8.2,
        profitGrowth: 25.3,
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch comparison" });
    }
  });

  app.get("/api/dashboard/export", isAuthenticated, async (req: Request, res: Response) => {
    try {
      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", "attachment; filename=dashboard.pdf");
      res.send(Buffer.from("PDF content placeholder"));
    } catch (error) {
      res.status(500).json({ message: "Failed to export" });
    }
  });

  // TRANSACTIONS ENHANCED ROUTES
  app.post("/api/transactions/:id/mark-paid", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      await storage.updateTransaction(id, {
        isPaid: true,
        paidDate: new Date(),
      });
      res.json({ message: "Marked as paid" });
    } catch (error) {
      res.status(500).json({ message: "Failed to mark as paid" });
    }
  });

  // INVOICES ENHANCED ROUTES
  app.post("/api/invoices/:id/generate-pix", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { generatePixPayment } = await import("./pix-boleto");
      const result = await generatePixPayment(req.params.id);
      res.json(result);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate PIX" });
    }
  });

  app.post("/api/invoices/:id/generate-boleto", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { generateBoletoPayment } = await import("./pix-boleto");
      const result = await generateBoletoPayment(req.params.id);
      res.json(result);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate boleto" });
    }
  });

  app.post("/api/invoices/:id/partial-payment", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const { amount } = req.body;
      res.json({ message: "Partial payment recorded", amount });
    } catch (error) {
      res.status(500).json({ message: "Failed to record payment" });
    }
  });

  // DOCUMENTS ENHANCED ROUTES
  app.post("/api/documents/upload", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { upload } = await import("./upload");
      upload.single("file")(req, res, async (err: any) => {
        if (err) {
          return res.status(400).json({ message: err.message });
        }
        if (!req.file) {
          return res.status(400).json({ message: "No file uploaded" });
        }
        const doc = await storage.createDocument({
          organizationId: req.user!.organizationId!,
          name: req.file.originalname,
          fileName: req.file.filename,
          fileSize: req.file.size,
          mimeType: req.file.mimetype,
          url: `/uploads/${req.file.filename}`,
          uploadedBy: req.user!.id,
        });
        res.json(doc);
      });
    } catch (error) {
      res.status(500).json({ message: "Upload failed" });
    }
  });

  app.post("/api/documents/:id/ocr", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      res.json({ textLength: 1500, extractedText: "Sample extracted text..." });
    } catch (error) {
      res.status(500).json({ message: "OCR failed" });
    }
  });

  // SETTINGS ENHANCED ROUTES
  app.post("/api/settings/logo", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { upload } = await import("./upload");
      upload.single("logo")(req, res, async (err: any) => {
        if (err) {
          return res.status(400).json({ message: err.message });
        }
        if (!req.file) {
          return res.status(400).json({ message: "No file uploaded" });
        }
        await storage.updateOrganization(req.user!.organizationId!, {
          logo: `/uploads/${req.file.filename}`,
        });
        res.json({ logoUrl: `/uploads/${req.file.filename}` });
      });
    } catch (error) {
      res.status(500).json({ message: "Upload failed" });
    }
  });

  app.post("/api/settings/avatar", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { upload } = await import("./upload");
      upload.single("avatar")(req, res, async (err: any) => {
        if (err) {
          return res.status(400).json({ message: err.message });
        }
        if (!req.file) {
          return res.status(400).json({ message: "No file uploaded" });
        }
        await storage.updateUser(req.user!.id, {
          avatar: `/uploads/${req.file.filename}`,
        });
        res.json({ avatarUrl: `/uploads/${req.file.filename}` });
      });
    } catch (error) {
      res.status(500).json({ message: "Upload failed" });
    }
  });

  app.put("/api/settings/tax", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { iss, icms, pis, cofins } = req.body;
      res.json({ message: "Tax settings saved", iss, icms, pis, cofins });
    } catch (error) {
      res.status(500).json({ message: "Failed to save" });
    }
  });

  app.post("/api/settings/webhooks", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { url, events } = req.body;
      res.json({ message: "Webhook configured", url, events });
    } catch (error) {
      res.status(500).json({ message: "Failed to configure webhook" });
    }
  });

  app.get("/api/settings", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const org = await storage.getOrganization(req.user!.organizationId!);
      res.json({
        logoUrl: org?.logo,
        webhookUrl: "",
        taxSettings: { iss: "2.00", icms: "18.00", pis: "0.65", cofins: "3.00" },
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch settings" });
    }
  });

  // OPEN FINANCE ROUTES
  app.get("/api/open-finance/connections", isAuthenticated, async (req: Request, res: Response) => {
    try {
      res.json([
        {
          id: "conn1",
          bankName: "Banco Exemplo",
          provider: "Pluggy",
          status: "active",
          lastSync: new Date(),
        },
      ]);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch connections" });
    }
  });

  app.get("/api/open-finance/transactions", isAuthenticated, async (req: Request, res: Response) => {
    try {
      res.json([
        {
          id: "txn1",
          date: new Date(),
          description: "Compra exemplo",
          bankName: "Banco Exemplo",
          amount: -150.50,
          imported: true,
        },
      ]);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  app.post("/api/open-finance/connect", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { provider } = req.body;
      res.json({
        authUrl: `https://${provider}.example.com/auth`,
        message: "Connect initiated",
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to connect" });
    }
  });

  app.post("/api/open-finance/:connectionId/sync", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { connectionId } = req.params;
      res.json({ message: "Sync completed", transactionsImported: 25 });
    } catch (error) {
      res.status(500).json({ message: "Failed to sync" });
    }
  });

  // BULK OPERATIONS ROUTES
  app.post("/api/bulk/import", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { csvData } = req.body;
      const lines = csvData.split("\n").filter((line: string) => line.trim());
      res.json({ imported: lines.length, message: `${lines.length} transações importadas` });
    } catch (error) {
      res.status(500).json({ message: "Import failed" });
    }
  });

  app.get("/api/bulk/export", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const csv = "data,descrição,valor,tipo\n2024-01-15,Exemplo,1500.00,income\n";
      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", "attachment; filename=transactions.csv");
      res.send(csv);
    } catch (error) {
      res.status(500).json({ message: "Export failed" });
    }
  });

  // NOTIFICATIONS ROUTES
  app.get("/api/notifications", isAuthenticated, async (req: Request, res: Response) => {
    try {
      res.json([
        {
          id: "notif1",
          title: "Novo pagamento recebido",
          message: "Você recebeu um pagamento de R$ 1.500,00",
          read: false,
          createdAt: new Date(),
        },
      ]);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch" });
    }
  });

  app.post("/api/notifications/:id/read", isAuthenticated, async (req: Request, res: Response) => {
    try {
      res.json({ message: "Marked as read" });
    } catch (error) {
      res.status(500).json({ message: "Failed" });
    }
  });

  app.delete("/api/notifications/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      res.json({ message: "Deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed" });
    }
  });

  // RECURRING TRANSACTIONS ROUTES
  app.get("/api/recurring-transactions", isAuthenticated, async (req: Request, res: Response) => {
    try {
      res.json([
        {
          id: "rec1",
          description: "Aluguel",
          amount: "2000.00",
          frequency: "monthly",
          status: "active",
          nextRun: new Date(new Date().setDate(new Date().getDate() + 5)),
        },
      ]);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch" });
    }
  });

  app.post("/api/recurring-transactions", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { description, amount, frequency, category } = req.body;
      res.json({
        id: crypto.randomUUID(),
        description,
        amount,
        frequency,
        category,
        status: "active",
        nextRun: new Date(),
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to create" });
    }
  });

  // REPORTS ENHANCED ROUTES
  app.get("/api/reports/balance-sheet", isAuthenticated, async (req: Request, res: Response) => {
    try {
      res.json({
        assets: { cash: "50000.00", receivables: "35000.00" },
        liabilities: { payables: "20000.00" },
        totalAssets: "85000.00",
        totalLiabilities: "20000.00",
        equity: "65000.00",
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch balance sheet" });
    }
  });

  app.get("/api/reports/:type/excel-formulas", isAuthenticated, async (req: Request, res: Response) => {
    try {
      res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
      res.setHeader("Content-Disposition", `attachment; filename=${req.params.type}-report.xlsx`);
      res.send(Buffer.from("Excel content placeholder"));
    } catch (error) {
      res.status(500).json({ message: "Failed to export" });
    }
  });

  // ORGANIZATIONS ROUTES
  // Get current organization
  app.get("/api/organizations/current", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(404).json({ message: "No organization found" });
      }
      const organization = await storage.getOrganization(req.user!.organizationId);
      res.json(organization);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch organization" });
    }
  });

  // Update organization
  app.put("/api/organizations/:id", isAuthenticated, isAdminOrOwner, async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      if (id !== req.user!.organizationId) {
        return res.status(403).json({ message: "Cannot update other organizations" });
      }
      const organization = await storage.updateOrganization(id, req.body);
      res.json(organization);
    } catch (error) {
      res.status(500).json({ message: "Failed to update organization" });
    }
  });

  // CUSTOMERS ROUTES
  // Get all customers for organization
  app.get("/api/customers", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const { page, limit, offset } = getPaginationParams(req.query.page as string, req.query.limit as string);
      const { data, total } = await storage.getCustomersByOrganizationPaginated(req.user!.organizationId, offset, limit);
      res.json(createPaginatedResponse(data, total, page, limit));
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch customers" });
    }
  });

  // Get single customer
  app.get("/api/customers/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const customer = await storage.getCustomer(req.params.id);
      if (!customer || customer.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Customer not found" });
      }
      res.json(customer);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch customer" });
    }
  });

  // Create customer
  app.post(
    "/api/customers",
    isAuthenticated,
    validateBody(createCustomerSchema),
    async (req: Request, res: Response) => {
      try {
        const customer = await storage.createCustomer({
          ...req.body,
          organizationId: req.user!.organizationId!,
        });

        await storage.createActivity({
          organizationId: req.user!.organizationId!,
          userId: req.user!.id,
          action: "customer_created",
          entityType: "customer",
          entityId: customer.id,
          details: JSON.stringify({ name: customer.name }),
        });

        res.status(201).json(customer);
      } catch (error) {
        res.status(500).json({ message: "Failed to create customer" });
      }
    }
  );

  // Update customer
  app.put("/api/customers/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getCustomer(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Customer not found" });
      }

      const customer = await storage.updateCustomer(req.params.id, req.body);

      await storage.createActivity({
        organizationId: req.user!.organizationId!,
        userId: req.user!.id,
        action: "customer_updated",
        entityType: "customer",
        entityId: req.params.id,
        details: JSON.stringify({ name: customer?.name }),
      });

      res.json(customer);
    } catch (error) {
      res.status(500).json({ message: "Failed to update customer" });
    }
  });

  // Delete customer
  app.delete("/api/customers/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getCustomer(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Customer not found" });
      }

      await storage.deleteCustomer(req.params.id);

      await storage.createActivity({
        organizationId: req.user!.organizationId!,
        userId: req.user!.id,
        action: "customer_deleted",
        entityType: "customer",
        entityId: req.params.id,
        details: JSON.stringify({ name: existing.name }),
      });

      res.json({ message: "Customer deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete customer" });
    }
  });

  // INVOICES ROUTES
  // Send invoice by email
  app.post("/api/invoices/:id/send-email", isAuthenticated, csrfProtection, async (req: Request, res: Response) => {
    try {
      const invoice = await storage.getInvoice(req.params.id);
      if (!invoice || invoice.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Invoice not found" });
      }

      const customer = await storage.getCustomer(invoice.customerId);
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }

      const organization = await storage.getOrganization(invoice.organizationId);
      if (!organization) {
        return res.status(404).json({ message: "Organization not found" });
      }

      const { sendEmail, generateInvoiceEmail } = await import("./email");
      
      const emailHtml = generateInvoiceEmail({
        invoiceNumber: invoice.invoiceNumber,
        customerName: customer.name,
        customerEmail: customer.email,
        amount: invoice.amount,
        dueDate: invoice.dueDate ? new Date(invoice.dueDate).toLocaleDateString('pt-BR') : 'N/A',
        description: invoice.description || '',
        issueDate: new Date(invoice.issueDate).toLocaleDateString('pt-BR'),
        organizationName: organization.name,
      });

      const sent = await sendEmail({
        to: customer.email,
        subject: `Fatura ${invoice.invoiceNumber} - ${organization.name}`,
        html: emailHtml,
      });

      if (sent) {
        res.json({ message: "Invoice sent by email successfully" });
      } else {
        res.status(500).json({ message: "Failed to send invoice by email" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to send invoice by email" });
    }
  });

  // Get all invoices for organization
  app.get("/api/invoices", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const { page, limit, offset } = getPaginationParams(req.query.page as string, req.query.limit as string);
      const { data, total } = await storage.getInvoicesByOrganizationPaginated(req.user!.organizationId, offset, limit);
      res.json(createPaginatedResponse(data, total, page, limit));
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch invoices" });
    }
  });

  // Get invoices by customer
  app.get("/api/customers/:customerId/invoices", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const customer = await storage.getCustomer(req.params.customerId);
      if (!customer || customer.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Customer not found" });
      }
      const invoices = await storage.getInvoicesByCustomer(req.params.customerId);
      res.json(invoices);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch invoices" });
    }
  });

  // Get single invoice
  app.get("/api/invoices/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const invoice = await storage.getInvoice(req.params.id);
      if (!invoice || invoice.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Invoice not found" });
      }
      res.json(invoice);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch invoice" });
    }
  });

  // Create invoice
  app.post(
    "/api/invoices",
    isAuthenticated,
    validateBody(createInvoiceSchema),
    async (req: Request, res: Response) => {
      try {
        // Verify customer belongs to organization
        const customer = await storage.getCustomer(req.body.customerId);
        if (!customer || customer.organizationId !== req.user!.organizationId) {
          return res.status(400).json({ message: "Invalid customer" });
        }

        // Generate invoice number
        const timestamp = Date.now();
        const invoiceNumber = `INV-${timestamp}`;

        const invoice = await storage.createInvoice({
          ...req.body,
          organizationId: req.user!.organizationId!,
          invoiceNumber,
        });

        await storage.createActivity({
          organizationId: req.user!.organizationId!,
          userId: req.user!.id,
          action: "invoice_created",
          entityType: "invoice",
          entityId: invoice.id,
          details: JSON.stringify({ invoiceNumber, amount: invoice.amount }),
        });

        res.status(201).json(invoice);
      } catch (error) {
        res.status(500).json({ message: "Failed to create invoice" });
      }
    }
  );

  // Update invoice
  app.put("/api/invoices/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getInvoice(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Invoice not found" });
      }

      const invoice = await storage.updateInvoice(req.params.id, req.body);

      await storage.createActivity({
        organizationId: req.user!.organizationId!,
        userId: req.user!.id,
        action: "invoice_updated",
        entityType: "invoice",
        entityId: req.params.id,
        details: JSON.stringify({ invoiceNumber: invoice?.invoiceNumber }),
      });

      res.json(invoice);
    } catch (error) {
      res.status(500).json({ message: "Failed to update invoice" });
    }
  });

  // Delete invoice
  app.delete("/api/invoices/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getInvoice(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Invoice not found" });
      }

      await storage.deleteInvoice(req.params.id);

      await storage.createActivity({
        organizationId: req.user!.organizationId!,
        userId: req.user!.id,
        action: "invoice_deleted",
        entityType: "invoice",
        entityId: req.params.id,
        details: JSON.stringify({ invoiceNumber: existing.invoiceNumber }),
      });

      res.json({ message: "Invoice deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete invoice" });
    }
  });

  // METRICS ROUTES
  app.get("/api/metrics", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const metrics = await storage.getMetrics(req.user!.organizationId);
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch metrics" });
    }
  });

  // Monthly Revenue Data
  app.get("/api/metrics/monthly-revenue", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const data = await storage.getMonthlyRevenueData(req.user!.organizationId);
      res.json(data);
    } catch (error) {
      console.error("Failed to fetch monthly revenue:", error);
      res.status(500).json({ message: "Failed to fetch monthly revenue data" });
    }
  });

  // ACTIVITIES ROUTES
  app.get("/api/activities", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      const activities = await storage.getActivitiesByOrganization(req.user!.organizationId, limit);
      res.json(activities);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch activities" });
    }
  });

  // CATEGORIES ROUTES
  app.get("/api/categories", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const categories = await storage.getCategoriesByOrganization(req.user!.organizationId);
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  app.post("/api/categories", isAuthenticated, validateBody(createCategorySchema), async (req: Request, res: Response) => {
    try {
      const category = await storage.createCategory({
        ...req.body,
        organizationId: req.user!.organizationId!,
      });
      res.status(201).json(category);
    } catch (error) {
      res.status(500).json({ message: "Failed to create category" });
    }
  });

  app.put("/api/categories/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getCategory(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Category not found" });
      }
      const category = await storage.updateCategory(req.params.id, req.body);
      res.json(category);
    } catch (error) {
      res.status(500).json({ message: "Failed to update category" });
    }
  });

  app.delete("/api/categories/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getCategory(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Category not found" });
      }
      await storage.deleteCategory(req.params.id);
      res.json({ message: "Category deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete category" });
    }
  });

  // BANK ACCOUNTS ROUTES
  app.get("/api/bank-accounts", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const accounts = await storage.getBankAccountsByOrganization(req.user!.organizationId);
      res.json(accounts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bank accounts" });
    }
  });

  app.post("/api/bank-accounts", isAuthenticated, validateBody(createBankAccountSchema), async (req: Request, res: Response) => {
    try {
      const account = await storage.createBankAccount({
        ...req.body,
        organizationId: req.user!.organizationId!,
      });
      res.status(201).json(account);
    } catch (error) {
      res.status(500).json({ message: "Failed to create bank account" });
    }
  });

  app.put("/api/bank-accounts/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getBankAccount(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Bank account not found" });
      }
      const account = await storage.updateBankAccount(req.params.id, req.body);
      res.json(account);
    } catch (error) {
      res.status(500).json({ message: "Failed to update bank account" });
    }
  });

  app.delete("/api/bank-accounts/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getBankAccount(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Bank account not found" });
      }
      await storage.deleteBankAccount(req.params.id);
      res.json({ message: "Bank account deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete bank account" });
    }
  });

  // COST CENTERS ROUTES
  app.get("/api/cost-centers", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const centers = await storage.getCostCentersByOrganization(req.user!.organizationId);
      res.json(centers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch cost centers" });
    }
  });

  app.post("/api/cost-centers", isAuthenticated, validateBody(createCostCenterSchema), async (req: Request, res: Response) => {
    try {
      const center = await storage.createCostCenter({
        ...req.body,
        organizationId: req.user!.organizationId!,
      });
      res.status(201).json(center);
    } catch (error) {
      res.status(500).json({ message: "Failed to create cost center" });
    }
  });

  app.put("/api/cost-centers/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getCostCenter(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Cost center not found" });
      }
      const center = await storage.updateCostCenter(req.params.id, req.body);
      res.json(center);
    } catch (error) {
      res.status(500).json({ message: "Failed to update cost center" });
    }
  });

  app.delete("/api/cost-centers/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getCostCenter(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Cost center not found" });
      }
      await storage.deleteCostCenter(req.params.id);
      res.json({ message: "Cost center deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete cost center" });
    }
  });

  // TAGS ROUTES
  app.get("/api/tags", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const tags = await storage.getTagsByOrganization(req.user!.organizationId);
      res.json(tags);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch tags" });
    }
  });

  app.post("/api/tags", isAuthenticated, validateBody(createTagSchema), async (req: Request, res: Response) => {
    try {
      const tag = await storage.createTag({
        ...req.body,
        organizationId: req.user!.organizationId!,
      });
      res.status(201).json(tag);
    } catch (error) {
      res.status(500).json({ message: "Failed to create tag" });
    }
  });

  app.put("/api/tags/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getTag(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Tag not found" });
      }
      const tag = await storage.updateTag(req.params.id, req.body);
      res.json(tag);
    } catch (error) {
      res.status(500).json({ message: "Failed to update tag" });
    }
  });

  app.delete("/api/tags/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getTag(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Tag not found" });
      }
      await storage.deleteTag(req.params.id);
      res.json({ message: "Tag deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete tag" });
    }
  });

  // TRANSACTIONS ROUTES
  app.get("/api/transactions", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const { page, limit, offset } = getPaginationParams(req.query.page as string, req.query.limit as string);
      const { data, total } = await storage.getTransactionsByOrganizationPaginated(req.user!.organizationId, offset, limit);
      res.json(createPaginatedResponse(data, total, page, limit));
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  app.get("/api/transactions/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const transaction = await storage.getTransaction(req.params.id);
      if (!transaction || transaction.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Transaction not found" });
      }
      res.json(transaction);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch transaction" });
    }
  });

  app.post("/api/transactions", isAuthenticated, validateBody(createTransactionSchema), async (req: Request, res: Response) => {
    try {
      const transaction = await storage.createTransaction({
        ...req.body,
        organizationId: req.user!.organizationId!,
      });

      await storage.createActivity({
        organizationId: req.user!.organizationId!,
        userId: req.user!.id,
        action: "transaction_created",
        entityType: "transaction",
        entityId: transaction.id,
        details: JSON.stringify({ description: transaction.description, amount: transaction.amount }),
      });

      res.status(201).json(transaction);
    } catch (error) {
      res.status(500).json({ message: "Failed to create transaction" });
    }
  });

  app.put("/api/transactions/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getTransaction(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Transaction not found" });
      }
      const transaction = await storage.updateTransaction(req.params.id, req.body);
      res.json(transaction);
    } catch (error) {
      res.status(500).json({ message: "Failed to update transaction" });
    }
  });

  app.delete("/api/transactions/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getTransaction(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Transaction not found" });
      }
      await storage.deleteTransaction(req.params.id);
      res.json({ message: "Transaction deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete transaction" });
    }
  });

  // DOCUMENTS ROUTES
  app.get("/api/documents", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const documents = await storage.getDocumentsByOrganization(req.user!.organizationId);
      res.json(documents);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch documents" });
    }
  });

  app.post("/api/documents", isAuthenticated, validateBody(createDocumentSchema), async (req: Request, res: Response) => {
    try {
      const document = await storage.createDocument({
        ...req.body,
        organizationId: req.user!.organizationId!,
        uploadedBy: req.user!.id,
      });
      res.status(201).json(document);
    } catch (error) {
      res.status(500).json({ message: "Failed to create document" });
    }
  });

  app.delete("/api/documents/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getDocument(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Document not found" });
      }
      await storage.deleteDocument(req.params.id);
      res.json({ message: "Document deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete document" });
    }
  });

  app.post("/api/transactions/:id/attach-document", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { documentId } = req.body;
      if (!documentId) {
        return res.status(400).json({ message: "documentId é obrigatório" });
      }

      const transaction = await storage.getTransaction(req.params.id);
      if (!transaction || transaction.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Transação não encontrada" });
      }

      const document = await storage.getDocument(documentId);
      if (!document || document.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Documento não encontrado" });
      }

      await storage.updateDocument(documentId, {
        entityType: "transaction",
        entityId: transaction.id,
      });

      res.json({ message: "Documento anexado com sucesso" });
    } catch (error) {
      console.error("Failed to attach document:", error);
      res.status(500).json({ message: "Erro ao anexar documento" });
    }
  });

  app.get("/api/transactions/:id/documents", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const transaction = await storage.getTransaction(req.params.id);
      if (!transaction || transaction.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Transação não encontrada" });
      }

      const documents = await storage.getDocumentsByEntity("transaction", transaction.id);
      res.json(documents);
    } catch (error) {
      console.error("Failed to get transaction documents:", error);
      res.status(500).json({ message: "Erro ao buscar documentos" });
    }
  });

  // CUSTOMER PORTAL ROUTES (View-only for customers)
  app.get("/api/portal/:customerId/invoices", async (req: Request, res: Response) => {
    try {
      const { customerId } = req.params;
      const { token } = req.query;

      if (!token) {
        return res.status(401).json({ message: "Token é obrigatório" });
      }

      const customer = await storage.getCustomer(customerId);
      if (!customer) {
        return res.status(404).json({ message: "Cliente não encontrado" });
      }

      const expectedToken = crypto
        .createHash('sha256')
        .update(`${customer.id}-${customer.email}-${process.env.SESSION_SECRET || 'secret'}`)
        .digest('hex');

      if (token !== expectedToken) {
        return res.status(401).json({ message: "Token inválido" });
      }

      const invoices = await storage.getInvoicesByCustomer(customerId);
      res.json(invoices);
    } catch (error) {
      console.error("Failed to get customer invoices:", error);
      res.status(500).json({ message: "Erro ao buscar faturas" });
    }
  });

  app.get("/api/portal/:customerId/invoice/:invoiceId", async (req: Request, res: Response) => {
    try {
      const { customerId, invoiceId } = req.params;
      const { token } = req.query;

      if (!token) {
        return res.status(401).json({ message: "Token é obrigatório" });
      }

      const customer = await storage.getCustomer(customerId);
      if (!customer) {
        return res.status(404).json({ message: "Cliente não encontrado" });
      }

      const expectedToken = crypto
        .createHash('sha256')
        .update(`${customer.id}-${customer.email}-${process.env.SESSION_SECRET || 'secret'}`)
        .digest('hex');

      if (token !== expectedToken) {
        return res.status(401).json({ message: "Token inválido" });
      }

      const invoice = await storage.getInvoice(invoiceId);
      if (!invoice || invoice.customerId !== customerId) {
        return res.status(404).json({ message: "Fatura não encontrada" });
      }

      res.json(invoice);
    } catch (error) {
      console.error("Failed to get invoice:", error);
      res.status(500).json({ message: "Erro ao buscar fatura" });
    }
  });

  // INVOICE TEMPLATE ROUTES
  app.get("/api/invoice-templates", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { invoiceTemplateService } = await import("./invoice-templates");
      const templates = await invoiceTemplateService.getTemplatesByOrganization(req.user!.organizationId!);
      res.json(templates);
    } catch (error) {
      console.error("Failed to get templates:", error);
      res.status(500).json({ message: "Erro ao buscar templates" });
    }
  });

  app.post("/api/invoice-templates", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { invoiceTemplateService } = await import("./invoice-templates");
      const template = await invoiceTemplateService.saveTemplate({
        ...req.body,
        organizationId: req.user!.organizationId!,
      });
      res.status(201).json(template);
    } catch (error) {
      console.error("Failed to create template:", error);
      res.status(500).json({ message: "Erro ao criar template" });
    }
  });

  app.post("/api/invoices/:id/generate-custom-pdf", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const invoice = await storage.getInvoice(req.params.id);
      if (!invoice || invoice.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Fatura não encontrada" });
      }

      const { invoiceTemplateService } = await import("./invoice-templates");
      const { templateId } = req.body;

      const templates = await invoiceTemplateService.getTemplatesByOrganization(req.user!.organizationId!);
      const template = templates.find(t => t.id === templateId) || templates[0];

      if (!template) {
        return res.status(404).json({ message: "Template não encontrado" });
      }

      const customer = await storage.getCustomer(invoice.customerId);
      const organization = await storage.getOrganization(req.user!.organizationId!);

      const invoiceData = {
        invoiceNumber: invoice.invoiceNumber,
        issueDate: new Date(invoice.issueDate!),
        dueDate: new Date(invoice.dueDate!),
        customerName: customer?.name || "Cliente",
        customerEmail: customer?.email || "",
        customerDocument: customer?.document,
        items: [{
          description: invoice.description || "Serviço",
          quantity: 1,
          unitPrice: parseFloat(invoice.amount),
          total: parseFloat(invoice.amount),
        }],
        subtotal: parseFloat(invoice.amount),
        total: parseFloat(invoice.amount),
        organizationName: organization?.name || "Organização",
        organizationDocument: organization?.document,
      };

      const pdfBuffer = await invoiceTemplateService.generateCustomInvoicePDF(invoiceData, template);

      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename=fatura_${invoice.invoiceNumber}_custom.pdf`);
      res.send(pdfBuffer);
    } catch (error) {
      console.error("Failed to generate custom invoice PDF:", error);
      res.status(500).json({ message: "Erro ao gerar PDF customizado" });
    }
  });

  // RECONCILIATIONS ROUTES
  app.get("/api/reconciliations", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const reconciliations = await storage.getReconciliationsByOrganization(req.user!.organizationId);
      res.json(reconciliations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch reconciliations" });
    }
  });

  app.post("/api/reconciliations", isAuthenticated, validateBody(createReconciliationSchema), async (req: Request, res: Response) => {
    try {
      const reconciliation = await storage.createReconciliation({
        ...req.body,
        organizationId: req.user!.organizationId!,
      });
      res.status(201).json(reconciliation);
    } catch (error) {
      res.status(500).json({ message: "Failed to create reconciliation" });
    }
  });

  app.delete("/api/reconciliations/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getReconciliation(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Reconciliation not found" });
      }
      await storage.deleteReconciliation(req.params.id);
      res.json({ message: "Reconciliation deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete reconciliation" });
    }
  });

  // USER PREFERENCES ROUTES
  app.get("/api/user/preferences", isAuthenticated, async (req: Request, res: Response) => {
    try {
      let preferences = await storage.getUserPreferences(req.user!.id);
      if (!preferences) {
        preferences = await storage.createUserPreferences({
          userId: req.user!.id,
        });
      }
      res.json(preferences);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch preferences" });
    }
  });

  app.put("/api/user/preferences", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const preferences = await storage.updateUserPreferences(req.user!.id, req.body);
      res.json(preferences);
    } catch (error) {
      res.status(500).json({ message: "Failed to update preferences" });
    }
  });

  // NOTIFICATIONS ROUTES
  app.get("/api/notifications", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      const notifications = await storage.getNotificationsByUser(req.user!.id, limit);
      res.json(notifications);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });

  app.get("/api/notifications/unread", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const notifications = await storage.getUnreadNotificationsByUser(req.user!.id);
      res.json(notifications);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch unread notifications" });
    }
  });

  app.put("/api/notifications/:id/read", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const notification = await storage.getNotification(req.params.id);
      if (!notification || notification.userId !== req.user!.id) {
        return res.status(404).json({ message: "Notification not found" });
      }
      const updated = await storage.markNotificationAsRead(req.params.id);
      res.json(updated);
    } catch (error) {
      res.status(500).json({ message: "Failed to mark notification as read" });
    }
  });

  app.put("/api/notifications/read-all", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const count = await storage.markAllNotificationsAsRead(req.user!.id);
      res.json({ message: `${count} notifications marked as read`, count });
    } catch (error) {
      res.status(500).json({ message: "Failed to mark all notifications as read" });
    }
  });

  app.delete("/api/notifications/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const notification = await storage.getNotification(req.params.id);
      if (!notification || notification.userId !== req.user!.id) {
        return res.status(404).json({ message: "Notification not found" });
      }
      await storage.deleteNotification(req.params.id);
      res.json({ message: "Notification deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete notification" });
    }
  });

  app.post("/api/notifications", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const notification = await storage.createNotification({
        ...req.body,
        organizationId: req.user!.organizationId,
      });
      res.status(201).json(notification);
    } catch (error) {
      res.status(500).json({ message: "Failed to create notification" });
    }
  });

  // RECURRING TRANSACTIONS ROUTES
  app.get("/api/recurring-transactions", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const transactions = await storage.getRecurringTransactionsByOrganization(req.user!.organizationId);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recurring transactions" });
    }
  });

  app.get("/api/recurring-transactions/active", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const transactions = await storage.getActiveRecurringTransactions(req.user!.organizationId);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch active recurring transactions" });
    }
  });

  app.get("/api/recurring-transactions/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const transaction = await storage.getRecurringTransaction(req.params.id);
      if (!transaction || transaction.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Recurring transaction not found" });
      }
      res.json(transaction);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recurring transaction" });
    }
  });

  app.post("/api/recurring-transactions", isAuthenticated, csrfProtection, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const transaction = await storage.createRecurringTransaction({
        ...req.body,
        organizationId: req.user!.organizationId,
      });
      res.status(201).json(transaction);
    } catch (error) {
      res.status(500).json({ message: "Failed to create recurring transaction" });
    }
  });

  app.put("/api/recurring-transactions/:id", isAuthenticated, csrfProtection, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getRecurringTransaction(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Recurring transaction not found" });
      }
      const transaction = await storage.updateRecurringTransaction(req.params.id, req.body);
      res.json(transaction);
    } catch (error) {
      res.status(500).json({ message: "Failed to update recurring transaction" });
    }
  });

  app.delete("/api/recurring-transactions/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getRecurringTransaction(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Recurring transaction not found" });
      }
      await storage.deleteRecurringTransaction(req.params.id);
      res.json({ message: "Recurring transaction deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete recurring transaction" });
    }
  });

  // USER PROFILE ROUTES
  app.put("/api/user/profile", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { name, email, avatar } = req.body;
      const user = await storage.updateUser(req.user!.id, { name, email, avatar });
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  app.put("/api/user/password", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { currentPassword, newPassword } = req.body;
      const user = await storage.getUser(req.user!.id);
      
      if (!user || !await bcrypt.compare(currentPassword, user.password)) {
        return res.status(400).json({ message: "Current password is incorrect" });
      }

      const hashedPassword = await bcrypt.hash(newPassword, 10);
      await storage.updateUser(req.user!.id, { password: hashedPassword });
      
      res.json({ message: "Password updated successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to update password" });
    }
  });

  // REPORTS ROUTES
  app.get("/api/reports/dre", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      
      const startDate = req.query.startDate ? new Date(req.query.startDate as string) : undefined;
      const endDate = req.query.endDate ? new Date(req.query.endDate as string) : undefined;
      
      const report = await storage.getDREReport(req.user!.organizationId, startDate, endDate);
      res.json(report);
    } catch (error) {
      console.error("Failed to generate DRE report:", error);
      res.status(500).json({ message: "Failed to generate DRE report" });
    }
  });

  app.get("/api/reports/cash-flow", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      
      const startDate = req.query.startDate ? new Date(req.query.startDate as string) : undefined;
      const endDate = req.query.endDate ? new Date(req.query.endDate as string) : undefined;
      
      const report = await storage.getCashFlowReport(req.user!.organizationId, startDate, endDate);
      res.json(report);
    } catch (error) {
      console.error("Failed to generate cash flow report:", error);
      res.status(500).json({ message: "Failed to generate cash flow report" });
    }
  });

  app.get("/api/reports/statement", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      
      const startDate = req.query.startDate ? new Date(req.query.startDate as string) : undefined;
      const endDate = req.query.endDate ? new Date(req.query.endDate as string) : undefined;
      
      const report = await storage.getStatementReport(req.user!.organizationId, startDate, endDate);
      res.json(report);
    } catch (error) {
      console.error("Failed to generate statement report:", error);
      res.status(500).json({ message: "Failed to generate statement report" });
    }
  });

  // EXPORT ROUTES
  app.get("/api/export/transactions", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }

      const format = (req.query.format as string) || "json";
      const transactions = await storage.getTransactionsByOrganization(req.user!.organizationId);
      
      const data = transactions.map(t => ({
        Data: t.date,
        Descrição: t.description,
        Tipo: t.type === 'income' ? 'Receita' : 'Despesa',
        Valor: parseFloat(t.amount),
        Pago: t.isPaid ? 'Sim' : 'Não',
        'Data Pagamento': t.paidDate || '',
        Observações: t.notes || ''
      }));

      if (format === "excel") {
        const ws = XLSX.utils.json_to_sheet(data);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Transações");
        const buffer = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });
        
        res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        res.setHeader("Content-Disposition", `attachment; filename=transacoes_${new Date().toISOString().split('T')[0]}.xlsx`);
        res.send(buffer);
      } else if (format === "csv") {
        const parser = new Parser();
        const csv = parser.parse(data);
        
        res.setHeader("Content-Type", "text/csv; charset=utf-8");
        res.setHeader("Content-Disposition", `attachment; filename=transacoes_${new Date().toISOString().split('T')[0]}.csv`);
        res.send(csv);
      } else {
        res.json(data);
      }
    } catch (error) {
      console.error("Failed to export transactions:", error);
      res.status(500).json({ message: "Failed to export transactions" });
    }
  });

  app.get("/api/export/customers", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }

      const format = (req.query.format as string) || "json";
      const customers = await storage.getCustomersByOrganization(req.user!.organizationId);
      
      const data = customers.map(c => ({
        Nome: c.name,
        Email: c.email,
        Telefone: c.phone || '',
        Documento: c.document || '',
        Cidade: c.city || '',
        Estado: c.state || '',
        'Data Criação': c.createdAt
      }));

      if (format === "excel") {
        const ws = XLSX.utils.json_to_sheet(data);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Clientes");
        const buffer = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });
        
        res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        res.setHeader("Content-Disposition", `attachment; filename=clientes_${new Date().toISOString().split('T')[0]}.xlsx`);
        res.send(buffer);
      } else if (format === "csv") {
        const parser = new Parser();
        const csv = parser.parse(data);
        
        res.setHeader("Content-Type", "text/csv; charset=utf-8");
        res.setHeader("Content-Disposition", `attachment; filename=clientes_${new Date().toISOString().split('T')[0]}.csv`);
        res.send(csv);
      } else {
        res.json(data);
      }
    } catch (error) {
      console.error("Failed to export customers:", error);
      res.status(500).json({ message: "Failed to export customers" });
    }
  });

  app.get("/api/export/invoices", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }

      const format = (req.query.format as string) || "json";
      const invoices = await storage.getInvoicesByOrganization(req.user!.organizationId);
      
      const data = invoices.map(i => ({
        'Número': i.invoiceNumber,
        Descrição: i.description || '',
        Valor: parseFloat(i.amount),
        Status: i.status,
        'Data Emissão': i.issueDate,
        Vencimento: i.dueDate || '',
        'Data Pagamento': i.paidDate || ''
      }));

      if (format === "excel") {
        const ws = XLSX.utils.json_to_sheet(data);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Faturas");
        const buffer = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });
        
        res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        res.setHeader("Content-Disposition", `attachment; filename=faturas_${new Date().toISOString().split('T')[0]}.xlsx`);
        res.send(buffer);
      } else if (format === "csv") {
        const parser = new Parser();
        const csv = parser.parse(data);
        
        res.setHeader("Content-Type", "text/csv; charset=utf-8");
        res.setHeader("Content-Disposition", `attachment; filename=faturas_${new Date().toISOString().split('T')[0]}.csv`);
        res.send(csv);
      } else {
        res.json(data);
      }
    } catch (error) {
      console.error("Failed to export invoices:", error);
      res.status(500).json({ message: "Failed to export invoices" });
    }
  });

  // ERROR LOGGING ENDPOINT (No CSRF protection - errors can happen before token is available)
  app.post("/api/errors/log", async (req: Request, res: Response) => {
    try {
      const errorData = req.body;
      console.error("Client Error:", {
        message: errorData.message,
        url: errorData.url,
        timestamp: errorData.timestamp,
        stack: errorData.stack,
      });
      res.json({ success: true });
    } catch (error) {
      console.error("Failed to log error:", error);
      res.status(500).json({ message: "Failed to log error" });
    }
  });

  // PASSWORD RESET ROUTES
  app.post("/api/auth/forgot-password", async (req: Request, res: Response) => {
    try {
      const { email } = req.body;
      
      if (!email) {
        return res.status(400).json({ message: "Email é obrigatório" });
      }

      const user = await storage.getUserByEmail(email);
      
      if (!user) {
        return res.json({ message: "Se o email existir, você receberá instruções de redefinição" });
      }

      const resetToken = crypto.randomUUID();
      const resetTokenExpiry = new Date(Date.now() + 60 * 60 * 1000);

      await storage.setPasswordResetToken(user.id, resetToken, resetTokenExpiry);

      const resetLink = `${process.env.APP_URL || req.protocol + '://' + req.get('host')}/reset-password?token=${resetToken}`;
      
      const { sendEmail, generatePasswordResetEmail } = await import("./email");
      await sendEmail({
        to: user.email,
        subject: "Redefinir Senha - LUCREI",
        html: generatePasswordResetEmail(resetLink, user.username),
      });

      res.json({ message: "Se o email existir, você receberá instruções de redefinição" });
    } catch (error) {
      console.error("Failed to process forgot password:", error);
      res.status(500).json({ message: "Erro ao processar solicitação" });
    }
  });

  app.post("/api/auth/reset-password", async (req: Request, res: Response) => {
    try {
      const { token, password } = req.body;
      
      if (!token || !password) {
        return res.status(400).json({ message: "Token e senha são obrigatórios" });
      }

      if (password.length < 8) {
        return res.status(400).json({ message: "Senha deve ter no mínimo 8 caracteres" });
      }

      const user = await storage.getUserByResetToken(token);
      
      if (!user || !user.resetTokenExpiry || user.resetTokenExpiry < new Date()) {
        return res.status(400).json({ message: "Token inválido ou expirado" });
      }

      const hashedPassword = await bcrypt.hash(password, 10);
      await storage.updateUserPassword(user.id, hashedPassword);
      await storage.clearPasswordResetToken(user.id);

      res.json({ message: "Senha redefinida com sucesso" });
    } catch (error) {
      console.error("Failed to reset password:", error);
      res.status(500).json({ message: "Erro ao redefinir senha" });
    }
  });

  // EMAIL VERIFICATION ROUTES
  app.post("/api/auth/verify-email", async (req: Request, res: Response) => {
    try {
      const { token } = req.body;
      
      if (!token) {
        return res.status(400).json({ message: "Token é obrigatório" });
      }

      const user = await storage.getUserByVerificationToken(token);
      
      if (!user) {
        return res.status(400).json({ message: "Token inválido" });
      }

      await storage.verifyUserEmail(user.id);

      const { sendEmail, generateWelcomeEmail } = await import("./email");
      await sendEmail({
        to: user.email,
        subject: "Bem-vindo ao LUCREI!",
        html: generateWelcomeEmail(user.username),
      });

      res.json({ message: "Email verificado com sucesso" });
    } catch (error) {
      console.error("Failed to verify email:", error);
      res.status(500).json({ message: "Erro ao verificar email" });
    }
  });

  app.post("/api/auth/resend-verification", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const user = await storage.getUserById(req.user!.id);
      
      if (!user) {
        return res.status(404).json({ message: "Usuário não encontrado" });
      }

      if (user.emailVerified) {
        return res.status(400).json({ message: "Email já verificado" });
      }

      const verificationToken = crypto.randomUUID();
      await storage.setEmailVerificationToken(user.id, verificationToken);

      const verifyLink = `${process.env.APP_URL || req.protocol + '://' + req.get('host')}/verify-email?token=${verificationToken}`;
      
      const { sendEmail, generateEmailVerificationEmail } = await import("./email");
      await sendEmail({
        to: user.email,
        subject: "Verificar Email - LUCREI",
        html: generateEmailVerificationEmail(verifyLink, user.username),
      });

      res.json({ message: "Email de verificação enviado" });
    } catch (error) {
      console.error("Failed to resend verification:", error);
      res.status(500).json({ message: "Erro ao enviar email de verificação" });
    }
  });

  // BULK OPERATIONS
  app.post("/api/transactions/bulk", isAuthenticated, csrfProtection, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }

      const { transactions } = req.body;

      if (!Array.isArray(transactions) || transactions.length === 0) {
        return res.status(400).json({ message: "Transactions array is required" });
      }

      if (transactions.length > 1000) {
        return res.status(400).json({ message: "Maximum 1000 transactions per bulk operation" });
      }

      const schema = z.array(createTransactionSchema);
      const validatedData = schema.parse(transactions);

      const createdTransactions = [];
      for (const transactionData of validatedData) {
        const transaction = await storage.createTransaction({
          ...transactionData,
          organizationId: req.user!.organizationId,
        });
        createdTransactions.push(transaction);
      }

      res.json({
        message: `${createdTransactions.length} transactions created successfully`,
        transactions: createdTransactions
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      console.error("Failed to create bulk transactions:", error);
      res.status(500).json({ message: "Failed to create bulk transactions" });
    }
  });

  // CSV IMPORT ROUTE
  app.post("/api/transactions/import/csv", isAuthenticated, csrfProtection, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }

      const { csvData } = req.body;

      if (!csvData || typeof csvData !== 'string') {
        return res.status(400).json({ message: "CSV data is required" });
      }

      const { parseTransactionsCSV } = await import("./csv-import");
      const result = await parseTransactionsCSV(csvData);

      if (!result.success) {
        return res.status(400).json({
          message: "CSV validation failed",
          errors: result.errors,
          parsedCount: result.transactions.length,
        });
      }

      if (result.transactions.length > 1000) {
        return res.status(400).json({ message: "Maximum 1000 transactions per import" });
      }

      const createdTransactions = [];
      for (const transactionData of result.transactions) {
        const transaction = await storage.createTransaction({
          organizationId: req.user!.organizationId,
          date: transactionData.date,
          description: transactionData.description,
          amount: transactionData.amount.toString(),
          type: transactionData.type,
          notes: transactionData.notes || null,
          isPaid: transactionData.type === 'income',
        });
        createdTransactions.push(transaction);
      }

      res.json({
        message: `${createdTransactions.length} transactions imported successfully`,
        transactions: createdTransactions,
        errors: result.errors,
      });
    } catch (error) {
      console.error("Failed to import CSV:", error);
      res.status(500).json({ message: error instanceof Error ? error.message : "Failed to import CSV" });
    }
  });

  // GET CSV Template
  app.get("/api/transactions/import/csv/template", isAuthenticated, (req: Request, res: Response) => {
    try {
      const { generateCSVTemplate } = require("./csv-import");
      const template = generateCSVTemplate();
      
      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", "attachment; filename=template_transacoes.csv");
      res.send(template);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate CSV template" });
    }
  });

  // STRIPE ROUTES
  app.post("/api/stripe/create-checkout-session", isAuthenticated, csrfProtection, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }

      const { priceId } = req.body;
      
      if (!priceId) {
        return res.status(400).json({ message: "Price ID is required" });
      }

      const org = await storage.getOrganization(req.user!.organizationId);
      
      const { createCheckoutSession } = await import("./stripe");
      const successUrl = `${req.protocol}://${req.get('host')}/app/subscription?success=true`;
      const cancelUrl = `${req.protocol}://${req.get('host')}/app/subscription?canceled=true`;
      
      const session = await createCheckoutSession(
        org?.stripeCustomerId || null,
        priceId,
        req.user!.organizationId,
        successUrl,
        cancelUrl
      );

      res.json({ sessionId: session.id, url: session.url });
    } catch (error) {
      console.error("Failed to create checkout session:", error);
      res.status(500).json({ message: "Failed to create checkout session" });
    }
  });

  app.post("/api/stripe/create-portal-session", isAuthenticated, csrfProtection, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }

      const org = await storage.getOrganization(req.user!.organizationId);
      
      if (!org?.stripeCustomerId) {
        return res.status(400).json({ message: "No Stripe customer ID" });
      }

      const { createBillingPortalSession } = await import("./stripe");
      const returnUrl = `${req.protocol}://${req.get('host')}/app/subscription`;
      
      const session = await createBillingPortalSession(org.stripeCustomerId, returnUrl);

      res.json({ url: session.url });
    } catch (error) {
      console.error("Failed to create portal session:", error);
      res.status(500).json({ message: "Failed to create portal session" });
    }
  });

  app.post("/api/stripe/webhook", express.raw({ type: "application/json" }), async (req: Request, res: Response) => {
    try {
      const signature = req.headers["stripe-signature"];
      
      if (!signature || Array.isArray(signature)) {
        return res.status(400).json({ message: "Invalid signature" });
      }

      const { constructWebhookEvent, handleCheckoutSessionCompleted, handleSubscriptionUpdated, handleSubscriptionDeleted } = await import("./stripe");
      
      const event = await constructWebhookEvent(req.rawBody as Buffer, signature);

      switch (event.type) {
        case "checkout.session.completed":
          await handleCheckoutSessionCompleted(event.data.object as any, storage);
          break;
        case "customer.subscription.updated":
          await handleSubscriptionUpdated(event.data.object as any, storage);
          break;
        case "customer.subscription.deleted":
          await handleSubscriptionDeleted(event.data.object as any, storage);
          break;
      }

      res.json({ received: true });
    } catch (error) {
      console.error("Webhook error:", error);
      res.status(400).json({ message: "Webhook error" });
    }
  });

  // OFX ROUTES
  app.post("/api/reconciliations/upload", isAuthenticated, csrfProtection, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }

      const { fileContent, fileName, bankAccountId } = req.body;

      if (!fileContent) {
        return res.status(400).json({ message: "File content is required" });
      }

      if (!bankAccountId) {
        return res.status(400).json({ message: "Bank account ID is required" });
      }

      const { parseOFX } = await import("./ofx-parser");
      const ofxData = await parseOFX(fileContent);

      const reconciliation = await storage.createReconciliation({
        organizationId: req.user!.organizationId,
        bankAccountId,
        fileName: fileName || "upload.ofx",
        data: JSON.stringify(ofxData),
        status: "pending",
        startDate: ofxData.startDate,
        endDate: ofxData.endDate,
      });

      res.json({
        reconciliation,
        transactions: ofxData.transactions,
        summary: {
          total: ofxData.transactions.length,
          credits: ofxData.transactions.filter(t => t.type === "CREDIT").length,
          debits: ofxData.transactions.filter(t => t.type === "DEBIT").length,
          balance: ofxData.balance,
        }
      });
    } catch (error) {
      console.error("Failed to parse OFX:", error);
      res.status(500).json({ message: "Failed to parse OFX file" });
    }
  });

  // PDF EXPORT ROUTES
  app.get("/api/reports/dre/pdf", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }

      const dreData = await storage.getDREReport(req.user!.organizationId);
      const { generateDREPDF } = await import("./pdf-generator");
      const pdfBuffer = await generateDREPDF(dreData);

      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename=dre_${new Date().toISOString().split('T')[0]}.pdf`);
      res.send(pdfBuffer);
    } catch (error) {
      console.error("Failed to generate DRE PDF:", error);
      res.status(500).json({ message: "Failed to generate PDF" });
    }
  });

  app.get("/api/reports/cash-flow/pdf", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }

      const cashFlowData = await storage.getCashFlowReport(req.user!.organizationId);
      const { generateCashFlowPDF } = await import("./pdf-generator");
      const pdfBuffer = await generateCashFlowPDF(cashFlowData);

      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename=fluxo_caixa_${new Date().toISOString().split('T')[0]}.pdf`);
      res.send(pdfBuffer);
    } catch (error) {
      console.error("Failed to generate Cash Flow PDF:", error);
      res.status(500).json({ message: "Failed to generate PDF" });
    }
  });

  app.get("/api/reports/statement/pdf", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }

      const startDate = req.query.startDate ? new Date(req.query.startDate as string) : undefined;
      const endDate = req.query.endDate ? new Date(req.query.endDate as string) : undefined;

      const statementData = await storage.getStatementReport(req.user!.organizationId, startDate, endDate);
      const { generateStatementPDF } = await import("./pdf-generator");
      const pdfBuffer = await generateStatementPDF(statementData);

      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename=extrato_${new Date().toISOString().split('T')[0]}.pdf`);
      res.send(pdfBuffer);
    } catch (error) {
      console.error("Failed to generate Statement PDF:", error);
      res.status(500).json({ message: "Failed to generate PDF" });
    }
  });

  app.get("/api/invoices/:id/pdf", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const invoice = await storage.getInvoice(req.params.id);
      
      if (!invoice || invoice.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Invoice not found" });
      }

      const { generateInvoicePDF } = await import("./pdf-generator");
      const pdfBuffer = await generateInvoicePDF(invoice);

      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename=fatura_${invoice.invoiceNumber}.pdf`);
      res.send(pdfBuffer);
    } catch (error) {
      console.error("Failed to generate Invoice PDF:", error);
      res.status(500).json({ message: "Failed to generate PDF" });
    }
  });

  // FILE UPLOAD ROUTES
  app.post("/api/documents/upload", isAuthenticated, csrfProtection, async (req: Request, res: Response) => {
    const { upload } = await import("./upload");
    
    upload.array("files", 5)(req, res, async (err) => {
      try {
        if (err) {
          if (err.message.includes("File too large")) {
            return res.status(413).json({ message: "File size exceeds 10MB limit" });
          }
          if (err.message.includes("not allowed")) {
            return res.status(415).json({ message: err.message });
          }
          return res.status(400).json({ message: "Upload failed" });
        }

        if (!req.user!.organizationId) {
          return res.status(400).json({ message: "No organization" });
        }

        const files = req.files as Express.Multer.File[];
        
        if (!files || files.length === 0) {
          return res.status(400).json({ message: "No files uploaded" });
        }

        const { getFileUrl } = await import("./upload");
        const uploadedDocs = [];

        for (const file of files) {
          const document = await storage.createDocument({
            organizationId: req.user!.organizationId,
            name: file.originalname,
            fileName: file.originalname,
            url: getFileUrl(file.filename),
            fileSize: file.size,
            mimeType: file.mimetype,
            entityType: req.body.entityType || null,
            entityId: req.body.entityId || null,
            uploadedBy: req.user!.id,
          });
          uploadedDocs.push(document);
        }

        res.json({
          message: `${uploadedDocs.length} file(s) uploaded successfully`,
          documents: uploadedDocs,
        });
      } catch (error) {
        console.error("Failed to upload documents:", error);
        res.status(500).json({ message: "Failed to upload documents" });
      }
    });
  });

  // Serve uploaded files
  app.use("/uploads", isAuthenticated, express.static("uploads"));

  // HEALTH CHECK ROUTES (should be before authentication)
  // These are used by load balancers, monitoring services, and Kubernetes
  app.get("/api/health", healthCheck);
  app.get("/api/liveness", liveness);
  app.get("/api/readiness", readiness);

  // METRICS ENDPOINT (Prometheus format)
  app.get("/metrics", async (req: Request, res: Response) => {
    try {
      res.set('Content-Type', metricsRegister.contentType);
      const metrics = await metricsRegister.metrics();
      res.end(metrics);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve metrics" });
    }
  });

  // PIX AND BOLETO ROUTES
  app.post("/api/invoices/:id/pix", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const invoice = await storage.getInvoice(req.params.id);
      if (!invoice || invoice.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Fatura não encontrada" });
      }

      const organization = await storage.getOrganization(req.user!.organizationId!);
      const { PIXService } = await import("./pix-boleto");
      
      const pixPayload = {
        pixKey: organization?.email || process.env.PIX_KEY || "contato@lucrei.app",
        merchantName: organization?.name || "LUCREI",
        merchantCity: organization?.city || "São Paulo",
        amount: parseFloat(invoice.amount),
        txId: invoice.id.substring(0, 25),
        description: `Fatura ${invoice.invoiceNumber}`,
      };

      const { qrCode, brCode } = await PIXService.generateQRCode(pixPayload);

      res.json({
        qrCode,
        brCode,
        invoiceId: invoice.id,
        amount: invoice.amount,
      });
    } catch (error) {
      console.error("Failed to generate PIX:", error);
      res.status(500).json({ message: "Erro ao gerar PIX" });
    }
  });

  app.post("/api/invoices/:id/boleto", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const invoice = await storage.getInvoice(req.params.id);
      if (!invoice || invoice.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Fatura não encontrada" });
      }

      const customer = await storage.getCustomer(invoice.customerId);
      if (!customer) {
        return res.status(404).json({ message: "Cliente não encontrado" });
      }

      const { BoletoService } = await import("./pix-boleto");

      const boletoData = {
        amount: parseFloat(invoice.amount),
        dueDate: new Date(invoice.dueDate!),
        customerName: customer.name,
        customerDocument: customer.document || "00000000000",
        description: invoice.description || `Fatura ${invoice.invoiceNumber}`,
        ourNumber: invoice.id.substring(0, 10),
        documentNumber: invoice.invoiceNumber,
      };

      const pdfBuffer = await BoletoService.generateBoletoPDF(boletoData);

      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename=boleto_${invoice.invoiceNumber}.pdf`);
      res.send(pdfBuffer);
    } catch (error) {
      console.error("Failed to generate Boleto:", error);
      res.status(500).json({ message: "Erro ao gerar boleto" });
    }
  });

  // CASH FLOW PREDICTION ROUTES
  app.get("/api/reports/cash-flow-prediction", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "Nenhuma organização" });
      }

      const { cashFlowPredictionService } = await import("./cash-flow-prediction");
      const days = parseInt(req.query.days as string) || 30;

      if (![30, 60, 90].includes(days)) {
        return res.status(400).json({ message: "Dias devem ser 30, 60 ou 90" });
      }

      const predictions = await cashFlowPredictionService.predict(
        req.user!.organizationId,
        days as 30 | 60 | 90
      );

      res.json({ predictions });
    } catch (error) {
      console.error("Failed to generate cash flow prediction:", error);
      res.status(500).json({ message: "Erro ao gerar previsão" });
    }
  });

  // OFX MATCHING AND RECONCILIATION ROUTES
  app.post("/api/reconciliations/ofx-parse", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { ofxContent } = req.body;
      if (!ofxContent) {
        return res.status(400).json({ message: "Conteúdo OFX é obrigatório" });
      }

      const { parseOFXFile } = await import("./ofx-matching");
      const { transactions, accountInfo } = parseOFXFile(ofxContent);

      res.json({ transactions, accountInfo });
    } catch (error) {
      console.error("Failed to parse OFX:", error);
      res.status(500).json({ message: "Erro ao processar arquivo OFX" });
    }
  });

  app.post("/api/reconciliations/ofx-match", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { ofxTransactions } = req.body;
      if (!ofxTransactions || !Array.isArray(ofxTransactions)) {
        return res.status(400).json({ message: "Transações OFX inválidas" });
      }

      const existingTransactions = await storage.getTransactionsByOrganization(req.user!.organizationId!);
      const { findMatches } = await import("./ofx-matching");

      const matches = findMatches(ofxTransactions, existingTransactions, {
        dateTolerance: 3,
        amountTolerance: 0.01,
      });

      res.json({ matches });
    } catch (error) {
      console.error("Failed to match OFX transactions:", error);
      res.status(500).json({ message: "Erro ao fazer matching" });
    }
  });

  app.post("/api/reconciliations/ofx-create-transactions", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { ofxTransactions, bankAccountId } = req.body;
      if (!ofxTransactions || !Array.isArray(ofxTransactions) || !bankAccountId) {
        return res.status(400).json({ message: "Dados inválidos" });
      }

      const createdTransactions = [];

      for (const ofxTrx of ofxTransactions) {
        const transaction = await storage.createTransaction({
          organizationId: req.user!.organizationId!,
          description: ofxTrx.description,
          amount: ofxTrx.amount.toString(),
          type: ofxTrx.type === "credit" ? "income" : "expense",
          date: new Date(ofxTrx.date),
          bankAccountId,
        });

        createdTransactions.push(transaction);
      }

      res.json({
        message: `${createdTransactions.length} transações criadas`,
        transactions: createdTransactions,
      });
    } catch (error) {
      console.error("Failed to create transactions from OFX:", error);
      res.status(500).json({ message: "Erro ao criar transações" });
    }
  });

  // ADVANCED REPORTS ROUTES
  app.get("/api/reports/aging", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "Nenhuma organização" });
      }

      const { advancedReportsService } = await import("./advanced-reports");
      const type = (req.query.type as "receivable" | "payable") || "receivable";

      const report = await advancedReportsService.generateAgingReport(
        req.user!.organizationId,
        type
      );

      res.json({ report });
    } catch (error) {
      console.error("Failed to generate aging report:", error);
      res.status(500).json({ message: "Erro ao gerar relatório" });
    }
  });

  app.get("/api/reports/period-comparison", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "Nenhuma organização" });
      }

      const { period1Start, period1End, period2Start, period2End } = req.query;
      
      if (!period1Start || !period1End || !period2Start || !period2End) {
        return res.status(400).json({ message: "Todas as datas são obrigatórias" });
      }

      const { advancedReportsService } = await import("./advanced-reports");
      
      const comparison = await advancedReportsService.comparePeriods(
        req.user!.organizationId,
        new Date(period1Start as string),
        new Date(period1End as string),
        new Date(period2Start as string),
        new Date(period2End as string)
      );

      res.json({ comparison });
    } catch (error) {
      console.error("Failed to compare periods:", error);
      res.status(500).json({ message: "Erro ao comparar períodos" });
    }
  });

  app.get("/api/reports/export-excel-formulas", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "Nenhuma organização" });
      }

      const startDate = req.query.startDate ? new Date(req.query.startDate as string) : new Date(new Date().getFullYear(), 0, 1);
      const endDate = req.query.endDate ? new Date(req.query.endDate as string) : new Date();

      const { advancedReportsService } = await import("./advanced-reports");
      const buffer = await advancedReportsService.exportToExcelWithFormulas(
        req.user!.organizationId,
        startDate,
        endDate
      );

      res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
      res.setHeader("Content-Disposition", `attachment; filename=relatorio_formulas_${new Date().toISOString().split('T')[0]}.xlsx`);
      res.send(buffer);
    } catch (error) {
      console.error("Failed to export Excel with formulas:", error);
      res.status(500).json({ message: "Erro ao exportar Excel" });
    }
  });

  // STRIPE ADVANCED FEATURES ROUTES
  app.post("/api/stripe/create-trial-subscription", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { priceId, trialDays, requiresPaymentMethod } = req.body;
      
      if (!priceId || !trialDays) {
        return res.status(400).json({ message: "priceId e trialDays são obrigatórios" });
      }

      const organization = await storage.getOrganization(req.user!.organizationId!);
      if (!organization?.stripeCustomerId) {
        return res.status(400).json({ message: "Cliente Stripe não encontrado" });
      }

      const { stripeAdvancedService } = await import("./stripe-advanced");
      const sessionUrl = await stripeAdvancedService.createCheckoutSessionWithTrial(
        priceId,
        organization.stripeCustomerId,
        `${req.protocol}://${req.get("host")}/subscription?success=true`,
        `${req.protocol}://${req.get("host")}/subscription?canceled=true`,
        { trialDays, requiresPaymentMethod: requiresPaymentMethod || false }
      );

      res.json({ url: sessionUrl });
    } catch (error) {
      console.error("Failed to create trial subscription:", error);
      res.status(500).json({ message: "Erro ao criar assinatura de teste" });
    }
  });

  app.post("/api/stripe/create-coupon", isAuthenticated, isAdminOrOwner, async (req: Request, res: Response) => {
    try {
      const { code, percentOff, amountOff, duration, durationInMonths } = req.body;
      
      if (!code || !duration) {
        return res.status(400).json({ message: "code e duration são obrigatórios" });
      }

      const { stripeAdvancedService } = await import("./stripe-advanced");
      const coupon = await stripeAdvancedService.createCoupon(code, {
        percentOff,
        amountOff,
        duration,
        durationInMonths,
        currency: "brl",
      });

      res.json({ coupon });
    } catch (error) {
      console.error("Failed to create coupon:", error);
      res.status(500).json({ message: "Erro ao criar cupom" });
    }
  });

  app.get("/api/stripe/preview-upgrade/:subscriptionId", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { subscriptionId } = req.params;
      const { newPriceId } = req.query;

      if (!newPriceId) {
        return res.status(400).json({ message: "newPriceId é obrigatório" });
      }

      const { stripeAdvancedService } = await import("./stripe-advanced");
      const preview = await stripeAdvancedService.previewUpgradeProration(
        subscriptionId,
        newPriceId as string
      );

      res.json({ preview });
    } catch (error) {
      console.error("Failed to preview upgrade:", error);
      res.status(500).json({ message: "Erro ao visualizar upgrade" });
    }
  });

  // MANUAL BACKUP ROUTE
  app.post("/api/admin/backup", isAuthenticated, isAdminOrOwner, async (req: Request, res: Response) => {
    try {
      const { backupService } = await import("./backup");
      const result = await backupService.performBackup();

      if (result.success) {
        res.json({
          message: "Backup realizado com sucesso",
          filename: result.filename,
        });
      } else {
        res.status(500).json({
          message: "Erro ao realizar backup",
          error: result.error,
        });
      }
    } catch (error) {
      console.error("Failed to perform backup:", error);
      res.status(500).json({ message: "Erro ao realizar backup" });
    }
  });

  // USAGE LIMITS ROUTES
  app.get("/api/usage-limits", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "Nenhuma organização" });
      }

      const { usageLimitsService } = await import("./usage-limits");
      const stats = await usageLimitsService.getUsageStats(req.user!.organizationId);

      res.json(stats);
    } catch (error) {
      console.error("Failed to get usage stats:", error);
      res.status(500).json({ message: "Erro ao buscar estatísticas de uso" });
    }
  });

  app.get("/api/usage-limits/check/:limitType", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "Nenhuma organização" });
      }

      const { limitType } = req.params;
      const { usageLimitsService } = await import("./usage-limits");

      const result = await usageLimitsService.checkLimit(
        req.user!.organizationId,
        limitType as any
      );

      res.json(result);
    } catch (error) {
      console.error("Failed to check limit:", error);
      res.status(500).json({ message: "Erro ao verificar limite" });
    }
  });

  // OPEN FINANCE ROUTES
  app.get("/api/open-finance/providers", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { openFinanceService } = await import("./open-finance");
      const providers = await openFinanceService.getAvailableProviders();
      res.json({ providers });
    } catch (error) {
      console.error("Failed to get providers:", error);
      res.status(500).json({ message: "Erro ao buscar provedores" });
    }
  });

  app.post("/api/open-finance/connect/pluggy", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { openFinanceService } = await import("./open-finance");
      const result = await openFinanceService.createPluggyConnection(req.user!.organizationId!);
      res.json(result);
    } catch (error) {
      console.error("Failed to create Pluggy connection:", error);
      res.status(500).json({ message: "Erro ao conectar com Pluggy" });
    }
  });

  app.post("/api/open-finance/connect/belvo", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { openFinanceService } = await import("./open-finance");
      const result = await openFinanceService.createBelvoConnection(req.user!.organizationId!);
      res.json(result);
    } catch (error) {
      console.error("Failed to create Belvo connection:", error);
      res.status(500).json({ message: "Erro ao conectar com Belvo" });
    }
  });

  app.post("/api/open-finance/sync/:provider/:itemId", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { provider, itemId } = req.params;
      const { openFinanceService } = await import("./open-finance");

      const result = await openFinanceService.syncTransactions(
        req.user!.organizationId!,
        itemId,
        provider as "pluggy" | "belvo"
      );

      res.json(result);
    } catch (error) {
      console.error("Failed to sync transactions:", error);
      res.status(500).json({ message: "Erro ao sincronizar transações" });
    }
  });

  // ML CATEGORIZATION ROUTES
  app.post("/api/ml/categorize-bulk", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { mlCategorizationService } = await import("./ml-categorization");
      const result = await mlCategorizationService.bulkCategorize(req.user!.organizationId!);
      res.json(result);
    } catch (error) {
      console.error("Failed to bulk categorize:", error);
      res.status(500).json({ message: "Erro ao categorizar transações" });
    }
  });

  app.post("/api/ml/train", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { mlCategorizationService } = await import("./ml-categorization");
      await mlCategorizationService.trainFromHistory(req.user!.organizationId!);
      res.json({ message: "Treinamento iniciado" });
    } catch (error) {
      console.error("Failed to train model:", error);
      res.status(500).json({ message: "Erro ao treinar modelo" });
    }
  });

  app.post("/api/ml/categorize-single", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { description, amount } = req.body;
      const { mlCategorizationService } = await import("./ml-categorization");
      const prediction = await mlCategorizationService.categorizeTransaction(description, amount);
      res.json(prediction);
    } catch (error) {
      console.error("Failed to categorize transaction:", error);
      res.status(500).json({ message: "Erro ao categorizar transação" });
    }
  });

  // PDF/IMAGE PREVIEW ROUTE
  app.get("/api/documents/:id/preview", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const document = await storage.getDocument(req.params.id);
      if (!document || document.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Documento não encontrado" });
      }

      if (document.mimeType?.startsWith("image/")) {
        res.setHeader("Content-Type", document.mimeType);
        res.setHeader("Content-Disposition", "inline");
      } else if (document.mimeType === "application/pdf") {
        res.setHeader("Content-Type", "application/pdf");
        res.setHeader("Content-Disposition", "inline");
      } else {
        return res.status(400).json({ message: "Tipo de arquivo não suportado para preview" });
      }

      res.redirect(document.url);
    } catch (error) {
      console.error("Failed to preview document:", error);
      res.status(500).json({ message: "Erro ao visualizar documento" });
    }
  });

  // Security and Privacy Routes
  const twoFactorRouter = await import("./two-factor");
  app.use("/api", twoFactorRouter.default);

  const deviceTrackingRouter = await import("./device-tracking");
  app.use("/api", deviceTrackingRouter.default);

  const auditTrailRouter = await import("./audit-trail");
  app.use("/api", auditTrailRouter.default);

  const privacyCenterRouter = await import("./privacy-center");
  app.use("/api/privacy", privacyCenterRouter.default);

  const oauthRouter = await import("./oauth");
  app.use("/api", oauthRouter.default);

  // Performance and Scaling Routes
  const redisCacheRouter = await import("./redis-cache");
  app.use("/api", redisCacheRouter.default);

  const performanceRouter = await import("./performance");
  app.use("/api", performanceRouter.default);

  const testingRouter = await import("./testing");
  app.use("/api", testingRouter.default);

  // Multi-currency and Multi-tenant Routes
  const multiCurrencyRouter = await import("./multi-currency");
  app.use("/api", multiCurrencyRouter.default);

  const multiTenantRouter = await import("./multi-tenant");
  app.use("/api", multiTenantRouter.default);

  // RBAC and White-label Routes
  const rbacRouter = await import("./rbac");
  app.use("/api", rbacRouter.default);

  const whiteLabelRouter = await import("./white-label");
  app.use("/api", whiteLabelRouter.default);

  // Uptime Monitoring Routes
  const uptimeMonitoringRouter = await import("./uptime-monitoring");
  app.use("/api", uptimeMonitoringRouter.default);

  // Contact, Feedback and Terms Routes
  const contactFeedbackRouter = await import("./contact-feedback");
  app.use("/api", contactFeedbackRouter.default);

  const termsRouter = await import("./terms");
  app.use("/api", termsRouter.default);

  const httpServer = createServer(app);
  return httpServer;
}
