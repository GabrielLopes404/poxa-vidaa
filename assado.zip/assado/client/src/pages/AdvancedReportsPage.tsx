import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Download, TrendingUp, DollarSign, FileSpreadsheet } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
} from "recharts";

export default function AdvancedReportsPage() {
  const [selectedReport, setSelectedReport] = useState("aging");

  const { data: agingReport } = useQuery({
    queryKey: ["/api/reports/aging"],
    queryFn: async () => {
      const res = await fetch("/api/reports/aging", { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    enabled: selectedReport === "aging",
  });

  const { data: cashFlowPrediction } = useQuery({
    queryKey: ["/api/reports/cash-flow-prediction"],
    queryFn: async () => {
      const res = await fetch("/api/reports/cash-flow-prediction", { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    enabled: selectedReport === "cashflow",
  });

  const { data: balanceSheet } = useQuery({
    queryKey: ["/api/reports/balance-sheet"],
    queryFn: async () => {
      const res = await fetch("/api/reports/balance-sheet", { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    enabled: selectedReport === "balance",
  });

  const exportExcelWithFormulas = async (reportType: string) => {
    const res = await fetch(`/api/reports/${reportType}/excel-formulas`, {
      credentials: "include",
    });
    const blob = await res.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${reportType}-report.xlsx`;
    a.click();
  };

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold">Relatórios Avançados</h1>
          <Button onClick={() => exportExcelWithFormulas(selectedReport)}>
            <FileSpreadsheet className="mr-2 h-4 w-4" />
            Exportar Excel com Fórmulas
          </Button>
        </div>

        <Tabs value={selectedReport} onValueChange={setSelectedReport}>
          <TabsList>
            <TabsTrigger value="aging">Aging Report</TabsTrigger>
            <TabsTrigger value="cashflow">Previsão Fluxo de Caixa</TabsTrigger>
            <TabsTrigger value="balance">Balanço Patrimonial</TabsTrigger>
          </TabsList>

          <TabsContent value="aging">
            <Card>
              <CardHeader>
                <CardTitle>Relatório de Aging - Contas a Receber</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Cliente</TableHead>
                      <TableHead>0-30 dias</TableHead>
                      <TableHead>31-60 dias</TableHead>
                      <TableHead>61-90 dias</TableHead>
                      <TableHead>90+ dias</TableHead>
                      <TableHead>Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {agingReport?.map((item: any) => (
                      <TableRow key={item.customerId}>
                        <TableCell>{item.customerName}</TableCell>
                        <TableCell>R$ {item.range_0_30}</TableCell>
                        <TableCell>R$ {item.range_31_60}</TableCell>
                        <TableCell>R$ {item.range_61_90}</TableCell>
                        <TableCell className="text-red-600">R$ {item.range_90_plus}</TableCell>
                        <TableCell className="font-bold">R$ {item.total}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="cashflow">
            <Card>
              <CardHeader>
                <CardTitle>Previsão de Fluxo de Caixa (30/60/90 dias)</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <AreaChart data={cashFlowPrediction?.predictions || []}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Area
                      type="monotone"
                      dataKey="predicted"
                      stroke="#10b981"
                      fill="#10b981"
                      fillOpacity={0.3}
                      name="Previsto"
                    />
                    <Area
                      type="monotone"
                      dataKey="actual"
                      stroke="#3b82f6"
                      fill="#3b82f6"
                      fillOpacity={0.3}
                      name="Real"
                    />
                  </AreaChart>
                </ResponsiveContainer>

                <div className="grid grid-cols-3 gap-4 mt-6">
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-sm text-muted-foreground">30 dias</div>
                      <div className="text-2xl font-bold text-green-600">
                        R$ {cashFlowPrediction?.predictions30Days || "0,00"}
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-sm text-muted-foreground">60 dias</div>
                      <div className="text-2xl font-bold text-blue-600">
                        R$ {cashFlowPrediction?.predictions60Days || "0,00"}
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-sm text-muted-foreground">90 dias</div>
                      <div className="text-2xl font-bold text-purple-600">
                        R$ {cashFlowPrediction?.predictions90Days || "0,00"}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="balance">
            <Card>
              <CardHeader>
                <CardTitle>Balanço Patrimonial</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-8">
                  <div>
                    <h3 className="text-lg font-bold mb-4">Ativo</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between p-2 bg-muted rounded">
                        <span>Caixa e Bancos</span>
                        <span className="font-bold">R$ {balanceSheet?.assets?.cash || "0,00"}</span>
                      </div>
                      <div className="flex justify-between p-2 bg-muted rounded">
                        <span>Contas a Receber</span>
                        <span className="font-bold">R$ {balanceSheet?.assets?.receivables || "0,00"}</span>
                      </div>
                      <div className="flex justify-between p-3 bg-primary/10 rounded font-bold">
                        <span>Total Ativo</span>
                        <span>R$ {balanceSheet?.totalAssets || "0,00"}</span>
                      </div>
                    </div>
                  </div>
                  <div>
                    <h3 className="text-lg font-bold mb-4">Passivo</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between p-2 bg-muted rounded">
                        <span>Contas a Pagar</span>
                        <span className="font-bold">R$ {balanceSheet?.liabilities?.payables || "0,00"}</span>
                      </div>
                      <div className="flex justify-between p-3 bg-primary/10 rounded font-bold">
                        <span>Total Passivo</span>
                        <span>R$ {balanceSheet?.totalLiabilities || "0,00"}</span>
                      </div>
                    </div>
                    <div className="mt-6">
                      <h3 className="text-lg font-bold mb-4">Patrimônio Líquido</h3>
                      <div className="flex justify-between p-3 bg-green-100 rounded font-bold">
                        <span>Patrimônio Líquido</span>
                        <span className="text-green-700">R$ {balanceSheet?.equity || "0,00"}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}
