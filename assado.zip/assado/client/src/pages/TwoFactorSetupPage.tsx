import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Shield, Copy, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";

export default function TwoFactorSetupPage() {
  const [verificationCode, setVerificationCode] = useState("");
  const [backupCodes, setBackupCodes] = useState<string[]>([]);
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: setupData, refetch: startSetup } = useQuery({
    queryKey: ["/api/2fa/setup/start"],
    queryFn: async () => {
      const res = await fetch("/api/2fa/setup/start", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
      });
      if (!res.ok) throw new Error("Failed to start 2FA setup");
      return res.json();
    },
    enabled: false,
  });

  const verifyMutation = useMutation({
    mutationFn: async (token: string) => {
      const res = await fetch("/api/2fa/setup/verify", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token }),
      });
      if (!res.ok) throw new Error("Invalid verification code");
      return res.json();
    },
    onSuccess: (data) => {
      setBackupCodes(data.backupCodes);
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      toast({ title: "2FA ativado com sucesso!" });
    },
    onError: () => {
      toast({ title: "Código inválido", variant: "destructive" });
    },
  });

  const copyBackupCodes = () => {
    navigator.clipboard.writeText(backupCodes.join("\n"));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast({ title: "Códigos de backup copiados!" });
  };

  return (
    <AppLayout>
      <motion.div 
        className="max-w-2xl mx-auto space-y-6"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-3xl font-bold">Autenticação de Dois Fatores</h1>
        
        {!setupData && !backupCodes.length && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-6 w-6" />
                Configurar 2FA
              </CardTitle>
              <CardDescription>
                Adicione uma camada extra de segurança à sua conta
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={() => startSetup()}>
                Iniciar Configuração
              </Button>
            </CardContent>
          </Card>
        )}

        {setupData && !backupCodes.length && (
          <Card>
            <CardHeader>
              <CardTitle>Escaneie o QR Code</CardTitle>
              <CardDescription>
                Use um app autenticador como Google Authenticator ou Authy
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex justify-center">
                <img src={setupData.qrCode} alt="QR Code" className="border rounded-lg p-4" />
              </div>

              <div>
                <Label>Ou insira este código manualmente:</Label>
                <code className="block mt-2 p-3 bg-muted rounded text-sm break-all">
                  {setupData.secret}
                </code>
              </div>

              <div className="space-y-2">
                <Label htmlFor="code">Digite o código de verificação</Label>
                <Input
                  id="code"
                  placeholder="000000"
                  value={verificationCode}
                  onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, ""))}
                  maxLength={6}
                />
              </div>

              <Button
                onClick={() => verifyMutation.mutate(verificationCode)}
                disabled={verificationCode.length !== 6}
                className="w-full"
              >
                Verificar e Ativar
              </Button>
            </CardContent>
          </Card>
        )}

        {backupCodes.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-green-600">2FA Ativado!</CardTitle>
              <CardDescription>
                Salve estes códigos de backup em um local seguro
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert>
                <AlertDescription>
                  Você pode usar estes códigos para acessar sua conta caso perca o acesso ao autenticador.
                  Cada código só pode ser usado uma vez.
                </AlertDescription>
              </Alert>

              <div className="bg-muted p-4 rounded-lg space-y-2">
                {backupCodes.map((code, i) => (
                  <div key={i} className="font-mono text-sm">
                    {code}
                  </div>
                ))}
              </div>

              <Button onClick={copyBackupCodes} className="w-full">
                {copied ? (
                  <>
                    <Check className="mr-2 h-4 w-4" />
                    Copiado!
                  </>
                ) : (
                  <>
                    <Copy className="mr-2 h-4 w-4" />
                    Copiar Códigos
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        )}
      </motion.div>
    </AppLayout>
  );
}
