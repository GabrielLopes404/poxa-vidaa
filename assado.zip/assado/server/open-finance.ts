import { storage } from "./storage";

interface BankConnection {
  id: string;
  organizationId: string;
  provider: "pluggy" | "belvo";
  itemId: string;
  status: "active" | "inactive" | "error";
  lastSync: Date;
  createdAt: Date;
}

interface OpenFinanceTransaction {
  id: string;
  accountId: string;
  date: Date;
  description: string;
  amount: number;
  type: "debit" | "credit";
  category?: string;
  merchant?: string;
}

class OpenFinanceService {
  private pluggyClientId = process.env.PLUGGY_CLIENT_ID;
  private pluggyClientSecret = process.env.PLUGGY_CLIENT_SECRET;
  private belvoSecretId = process.env.BELVO_SECRET_ID;
  private belvoSecretPassword = process.env.BELVO_SECRET_PASSWORD;

  async createPluggyConnection(organizationId: string): Promise<{ connectUrl: string }> {
    if (!this.pluggyClientId || !this.pluggyClientSecret) {
      throw new Error("Pluggy credentials not configured");
    }

    const response = await fetch("https://api.pluggy.ai/connect_token", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-API-KEY": this.pluggyClientId,
      },
      body: JSON.stringify({
        clientUserId: organizationId,
      }),
    });

    if (!response.ok) {
      throw new Error("Failed to create Pluggy connection");
    }

    const data = await response.json() as any;

    return {
      connectUrl: `https://connect.pluggy.ai?connectToken=${data.accessToken}`,
    };
  }

  async createBelvoConnection(organizationId: string): Promise<{ widgetToken: string }> {
    if (!this.belvoSecretId || !this.belvoSecretPassword) {
      throw new Error("Belvo credentials not configured");
    }

    const auth = Buffer.from(`${this.belvoSecretId}:${this.belvoSecretPassword}`).toString("base64");

    const response = await fetch("https://sandbox.belvo.com/api/token/", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Basic ${auth}`,
      },
      body: JSON.stringify({
        scopes: "read_accounts,read_transactions",
        widget: {
          branding: {
            company_name: "LUCREI",
          },
        },
      }),
    });

    if (!response.ok) {
      throw new Error("Failed to create Belvo connection");
    }

    const data = await response.json() as any;

    return {
      widgetToken: data.access,
    };
  }

  async syncTransactions(
    organizationId: string,
    itemId: string,
    provider: "pluggy" | "belvo"
  ): Promise<{ synced: number }> {
    if (provider === "pluggy") {
      return await this.syncPluggyTransactions(organizationId, itemId);
    } else {
      return await this.syncBelvoTransactions(organizationId, itemId);
    }
  }

  private async syncPluggyTransactions(
    organizationId: string,
    itemId: string
  ): Promise<{ synced: number }> {
    if (!this.pluggyClientId) {
      throw new Error("Pluggy not configured");
    }

    const response = await fetch(`https://api.pluggy.ai/transactions?itemId=${itemId}`, {
      headers: {
        "X-API-KEY": this.pluggyClientId,
      },
    });

    if (!response.ok) {
      throw new Error("Failed to fetch Pluggy transactions");
    }

    const data = await response.json() as any;
    let synced = 0;

    for (const trx of data.results || []) {
      const existing = await storage.getTransactionByExternalId(trx.id);

      if (!existing) {
        await storage.createTransaction({
          organizationId,
          description: trx.description,
          amount: Math.abs(trx.amount).toString(),
          type: trx.amount < 0 ? "expense" : "income",
          date: new Date(trx.date),
        });
        synced++;
      }
    }

    return { synced };
  }

  private async syncBelvoTransactions(
    organizationId: string,
    linkId: string
  ): Promise<{ synced: number }> {
    if (!this.belvoSecretId || !this.belvoSecretPassword) {
      throw new Error("Belvo not configured");
    }

    const auth = Buffer.from(`${this.belvoSecretId}:${this.belvoSecretPassword}`).toString("base64");

    const response = await fetch("https://sandbox.belvo.com/api/transactions/", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Basic ${auth}`,
      },
      body: JSON.stringify({
        link: linkId,
        date_from: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
        date_to: new Date().toISOString().split("T")[0],
      }),
    });

    if (!response.ok) {
      throw new Error("Failed to fetch Belvo transactions");
    }

    const data = await response.json() as any;
    let synced = 0;

    for (const trx of data || []) {
      const existing = await storage.getTransactionByExternalId(trx.id);

      if (!existing) {
        await storage.createTransaction({
          organizationId,
          description: trx.description,
          amount: Math.abs(trx.amount).toString(),
          type: trx.type === "OUTFLOW" ? "expense" : "income",
          date: new Date(trx.value_date),
        });
        synced++;
      }
    }

    return { synced };
  }

  async getAvailableProviders(): Promise<Array<{ id: string; name: string; logo: string }>> {
    return [
      {
        id: "pluggy",
        name: "Pluggy",
        logo: "https://pluggy.ai/logo.png",
      },
      {
        id: "belvo",
        name: "Belvo",
        logo: "https://belvo.com/logo.png",
      },
    ];
  }
}

export const openFinanceService = new OpenFinanceService();
