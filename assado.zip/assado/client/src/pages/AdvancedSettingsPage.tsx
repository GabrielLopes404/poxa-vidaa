import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Upload, Webhook, DollarSign } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";

export default function AdvancedSettingsPage() {
  const [logo, setLogo] = useState<File | null>(null);
  const [avatar, setAvatar] = useState<File | null>(null);
  const [csrfToken, setCsrfToken] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  useEffect(() => {
    fetch("/api/csrf-token", { credentials: "include" })
      .then((res) => res.json())
      .then((data) => setCsrfToken(data.csrfToken))
      .catch(console.error);
  }, []);

  const { data: settings } = useQuery({
    queryKey: ["/api/settings"],
    queryFn: async () => {
      const res = await fetch("/api/settings", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch settings");
      return res.json();
    },
  });

  const uploadLogoMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("logo", file);
      const res = await fetch("/api/settings/logo", {
        method: "POST",
        credentials: "include",
        headers: { "X-CSRF-Token": csrfToken },
        body: formData,
      });
      if (!res.ok) throw new Error("Upload failed");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({ title: "Logo atualizada!" });
      setLogo(null);
    },
  });

  const uploadAvatarMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("avatar", file);
      const res = await fetch("/api/settings/avatar", {
        method: "POST",
        credentials: "include",
        headers: { "X-CSRF-Token": csrfToken },
        body: formData,
      });
      if (!res.ok) throw new Error("Upload failed");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      toast({ title: "Avatar atualizado!" });
      setAvatar(null);
    },
  });

  const saveTaxSettingsMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await fetch("/api/settings/tax", {
        method: "PUT",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": csrfToken,
        },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to save");
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Configurações fiscais salvas!" });
    },
  });

  const saveWebhookMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await fetch("/api/settings/webhooks", {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": csrfToken,
        },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to save");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({ title: "Webhook configurado!" });
    },
  });

  return (
    <AppLayout>
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Configurações Avançadas</h1>

        <Tabs defaultValue="branding">
          <TabsList>
            <TabsTrigger value="branding">Marca</TabsTrigger>
            <TabsTrigger value="tax">Impostos</TabsTrigger>
            <TabsTrigger value="webhooks">Webhooks</TabsTrigger>
          </TabsList>

          <TabsContent value="branding">
            <div className="grid gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Logo da Organização</CardTitle>
                  <CardDescription>Upload do logotipo da sua empresa</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {settings?.logoUrl && (
                    <img src={settings.logoUrl} alt="Logo" className="h-20 w-auto" />
                  )}
                  <Input type="file" accept="image/*" onChange={(e) => e.target.files && setLogo(e.target.files[0])} />
                  <Button
                    onClick={() => logo && uploadLogoMutation.mutate(logo)}
                    disabled={!logo}
                  >
                    <Upload className="mr-2 h-4 w-4" />
                    Upload Logo
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Avatar do Usuário</CardTitle>
                  <CardDescription>Foto de perfil</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Input type="file" accept="image/*" onChange={(e) => e.target.files && setAvatar(e.target.files[0])} />
                  <Button
                    onClick={() => avatar && uploadAvatarMutation.mutate(avatar)}
                    disabled={!avatar}
                  >
                    <Upload className="mr-2 h-4 w-4" />
                    Upload Avatar
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="tax">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5" />
                  Configurações Fiscais
                </CardTitle>
                <CardDescription>Configure alíquotas de impostos</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="iss">ISS (%)</Label>
                    <Input
                      id="iss"
                      type="number"
                      step="0.01"
                      defaultValue={settings?.taxSettings?.iss || "2.00"}
                      placeholder="2.00"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="icms">ICMS (%)</Label>
                    <Input
                      id="icms"
                      type="number"
                      step="0.01"
                      defaultValue={settings?.taxSettings?.icms || "18.00"}
                      placeholder="18.00"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="pis">PIS (%)</Label>
                    <Input
                      id="pis"
                      type="number"
                      step="0.01"
                      defaultValue={settings?.taxSettings?.pis || "0.65"}
                      placeholder="0.65"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="cofins">COFINS (%)</Label>
                    <Input
                      id="cofins"
                      type="number"
                      step="0.01"
                      defaultValue={settings?.taxSettings?.cofins || "3.00"}
                      placeholder="3.00"
                    />
                  </div>
                </div>
                <Button
                  onClick={() => {
                    const iss = (document.getElementById("iss") as HTMLInputElement).value;
                    const icms = (document.getElementById("icms") as HTMLInputElement).value;
                    const pis = (document.getElementById("pis") as HTMLInputElement).value;
                    const cofins = (document.getElementById("cofins") as HTMLInputElement).value;
                    saveTaxSettingsMutation.mutate({ iss, icms, pis, cofins });
                  }}
                >
                  Salvar Configurações Fiscais
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="webhooks">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Webhook className="h-5 w-5" />
                  Configuração de Webhooks
                </CardTitle>
                <CardDescription>Configure notificações webhook para eventos</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="webhook-url">URL do Webhook</Label>
                  <Input
                    id="webhook-url"
                    type="url"
                    placeholder="https://seu-servidor.com/webhook"
                    defaultValue={settings?.webhookUrl || ""}
                  />
                </div>
                <div className="space-y-3">
                  <Label>Eventos</Label>
                  {["invoice.created", "invoice.paid", "customer.created", "payment.received"].map((event) => (
                    <div key={event} className="flex items-center space-x-2">
                      <Switch id={event} defaultChecked />
                      <Label htmlFor={event} className="cursor-pointer">
                        {event}
                      </Label>
                    </div>
                  ))}
                </div>
                <Button
                  onClick={() => {
                    const url = (document.getElementById("webhook-url") as HTMLInputElement).value;
                    saveWebhookMutation.mutate({ url, events: ["invoice.created", "invoice.paid"] });
                  }}
                >
                  Salvar Webhook
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}
