import PDFDocument from "pdfkit";

export interface InvoiceTemplate {
  id: string;
  name: string;
  organizationId: string;
  headerColor: string;
  logoUrl?: string;
  footerText?: string;
  includePaymentInstructions: boolean;
  includeTerms: boolean;
  customFields?: Record<string, string>;
}

export interface InvoiceData {
  invoiceNumber: string;
  issueDate: Date;
  dueDate: Date;
  customerName: string;
  customerEmail: string;
  customerDocument?: string;
  customerAddress?: string;
  items: Array<{
    description: string;
    quantity: number;
    unitPrice: number;
    total: number;
  }>;
  subtotal: number;
  tax?: number;
  discount?: number;
  total: number;
  notes?: string;
  paymentInstructions?: string;
  organizationName: string;
  organizationDocument?: string;
  organizationAddress?: string;
  organizationEmail?: string;
  organizationPhone?: string;
}

export class InvoiceTemplateService {
  async generateCustomInvoicePDF(
    data: InvoiceData,
    template: InvoiceTemplate
  ): Promise<Buffer> {
    const doc = new PDFDocument({ size: "A4", margin: 50 });
    const chunks: Buffer[] = [];

    doc.on("data", (chunk: Buffer) => chunks.push(chunk));

    return new Promise((resolve) => {
      doc.on("end", () => resolve(Buffer.concat(chunks)));

      const headerColor = template.headerColor || "#667eea";

      doc.rect(0, 0, 600, 150).fill(headerColor);

      doc.fillColor("#ffffff").fontSize(28).text(template.name || "FATURA", 50, 50);
      doc.fontSize(14).text(data.organizationName, 50, 90);

      doc.fillColor("#000000").fontSize(12);
      doc.text(`Fatura: ${data.invoiceNumber}`, 50, 180);
      doc.text(`Emissão: ${data.issueDate.toLocaleDateString("pt-BR")}`, 50, 200);
      doc.text(`Vencimento: ${data.dueDate.toLocaleDateString("pt-BR")}`, 50, 220);

      doc.text("Cliente:", 350, 180, { underline: true });
      doc.text(data.customerName, 350, 200);
      if (data.customerEmail) doc.text(data.customerEmail, 350, 220);
      if (data.customerDocument) doc.text(data.customerDocument, 350, 240);

      doc.moveDown(2);
      const tableTop = 280;
      
      doc.font("Helvetica-Bold");
      doc.text("Descrição", 50, tableTop);
      doc.text("Qtd", 300, tableTop, { width: 50, align: "right" });
      doc.text("Preço Unit.", 370, tableTop, { width: 80, align: "right" });
      doc.text("Total", 470, tableTop, { width: 80, align: "right" });

      doc.font("Helvetica");
      let yPosition = tableTop + 25;

      for (const item of data.items) {
        doc.text(item.description, 50, yPosition);
        doc.text(item.quantity.toString(), 300, yPosition, { width: 50, align: "right" });
        doc.text(`R$ ${item.unitPrice.toFixed(2)}`, 370, yPosition, { width: 80, align: "right" });
        doc.text(`R$ ${item.total.toFixed(2)}`, 470, yPosition, { width: 80, align: "right" });
        yPosition += 25;
      }

      doc.moveTo(50, yPosition).lineTo(550, yPosition).stroke();
      yPosition += 15;

      doc.text("Subtotal:", 370, yPosition);
      doc.text(`R$ ${data.subtotal.toFixed(2)}`, 470, yPosition, { width: 80, align: "right" });
      yPosition += 20;

      if (data.tax) {
        doc.text("Impostos:", 370, yPosition);
        doc.text(`R$ ${data.tax.toFixed(2)}`, 470, yPosition, { width: 80, align: "right" });
        yPosition += 20;
      }

      if (data.discount) {
        doc.text("Desconto:", 370, yPosition);
        doc.text(`-R$ ${data.discount.toFixed(2)}`, 470, yPosition, { width: 80, align: "right" });
        yPosition += 20;
      }

      doc.font("Helvetica-Bold").fontSize(14);
      doc.text("TOTAL:", 370, yPosition);
      doc.text(`R$ ${data.total.toFixed(2)}`, 470, yPosition, { width: 80, align: "right" });

      yPosition += 40;
      doc.font("Helvetica").fontSize(10);

      if (template.includePaymentInstructions && data.paymentInstructions) {
        doc.text("INSTRUÇÕES DE PAGAMENTO:", 50, yPosition, { underline: true });
        yPosition += 15;
        doc.text(data.paymentInstructions, 50, yPosition, { width: 500 });
        yPosition += 40;
      }

      if (data.notes) {
        doc.text("OBSERVAÇÕES:", 50, yPosition, { underline: true });
        yPosition += 15;
        doc.text(data.notes, 50, yPosition, { width: 500 });
        yPosition += 40;
      }

      if (template.footerText) {
        doc.fontSize(8).fillColor("#666666");
        doc.text(template.footerText, 50, 750, { align: "center", width: 500 });
      }

      doc.end();
    });
  }

  async saveTemplate(template: InvoiceTemplate): Promise<InvoiceTemplate> {
    return template;
  }

  async getTemplatesByOrganization(organizationId: string): Promise<InvoiceTemplate[]> {
    return [];
  }
}

export const invoiceTemplateService = new InvoiceTemplateService();
