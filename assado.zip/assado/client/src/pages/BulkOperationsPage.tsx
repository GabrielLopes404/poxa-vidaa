import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { FileUp, Download, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function BulkOperationsPage() {
  const [csvData, setCsvData] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const importMutation = useMutation({
    mutationFn: async (data: string) => {
      const res = await fetch("/api/bulk/import", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ csvData: data }),
      });
      if (!res.ok) throw new Error("Import failed");
      return res.json();
    },
    onSuccess: (data) => {
      toast({ title: `${data.imported} transações importadas!` });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      setCsvData("");
    },
  });

  const exportTransactions = async () => {
    const res = await fetch("/api/bulk/export", { credentials: "include" });
    const blob = await res.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "transactions.csv";
    a.click();
    toast({ title: "Transações exportadas!" });
  };

  return (
    <AppLayout>
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Operações em Massa</h1>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileUp className="h-5 w-5" />
                Importar Transações (CSV)
              </CardTitle>
              <CardDescription>
                Cole dados CSV no formato: data,descrição,valor,tipo
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                value={csvData}
                onChange={(e) => setCsvData(e.target.value)}
                placeholder="2024-01-15,Venda produto,1500.00,income&#10;2024-01-16,Compra material,-350.00,expense"
                rows={10}
                className="font-mono text-sm"
              />
              <Button
                onClick={() => importMutation.mutate(csvData)}
                disabled={!csvData}
                className="w-full"
              >
                <CheckCircle className="mr-2 h-4 w-4" />
                Importar
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Download className="h-5 w-5" />
                Exportar Transações
              </CardTitle>
              <CardDescription>
                Baixe todas as transações em formato CSV
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={exportTransactions} className="w-full">
                <Download className="mr-2 h-4 w-4" />
                Exportar CSV
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}
