import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { PageContainer } from "@/components/PageContainer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from "@/components/ui/form";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Key, Plus, Copy, Trash2, Eye, EyeOff, Shield, Info } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";

const apiKeySchema = z.object({
  name: z.string().min(1, "Nome é obrigatório"),
  permissions: z.array(z.string()).min(1, "Selecione pelo menos uma permissão"),
});

type APIKeyFormData = z.infer<typeof apiKeySchema>;

interface APIKey {
  id: string;
  name: string;
  key: string;
  permissions: string[];
  lastUsed: string | null;
  createdAt: string;
  expiresAt: string | null;
}

const availablePermissions = [
  { id: "transactions:read", label: "Ler transações" },
  { id: "transactions:write", label: "Criar/editar transações" },
  { id: "customers:read", label: "Ler clientes" },
  { id: "customers:write", label: "Criar/editar clientes" },
  { id: "invoices:read", label: "Ler faturas" },
  { id: "invoices:write", label: "Criar/editar faturas" },
  { id: "reports:read", label: "Ler relatórios" },
];

export default function APIKeysPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [newApiKey, setNewApiKey] = useState<string | null>(null);
  const [showKeys, setShowKeys] = useState<Record<string, boolean>>({});

  const { data: apiKeys, isLoading } = useQuery<APIKey[]>({
    queryKey: ["/api/api-keys"],
  });

  const form = useForm<APIKeyFormData>({
    resolver: zodResolver(apiKeySchema),
    defaultValues: {
      name: "",
      permissions: [],
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: APIKeyFormData) => {
      const response = await fetch("/api/api-keys", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("Failed to create API key");
      return response.json();
    },
    onSuccess: (data) => {
      setNewApiKey(data.key);
      toast({
        title: "API Key criada!",
        description: "Copie sua chave agora. Ela não será exibida novamente.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/api-keys"] });
      form.reset();
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await fetch(`/api/api-keys/${id}`, {
        method: "DELETE",
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to delete API key");
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "API Key excluída",
        description: "A chave de API foi removida com sucesso.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/api-keys"] });
    },
  });

  const onSubmit = (data: APIKeyFormData) => {
    createMutation.mutate(data);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copiado!",
      description: "A chave foi copiada para a área de transferência.",
    });
  };

  const maskKey = (key: string) => {
    return `${key.substring(0, 8)}...${key.substring(key.length - 8)}`;
  };

  return (
    <PageContainer>
      <div className="space-y-6 max-w-6xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Key className="h-8 w-8 text-primary" />
            <div>
              <h1 className="text-3xl font-bold tracking-tight">API Keys</h1>
              <p className="text-muted-foreground">
                Gerencie chaves de API para integração com sistemas externos
              </p>
            </div>
          </div>
          <Dialog open={isCreateOpen || !!newApiKey} onOpenChange={(open) => {
            if (!open) {
              setIsCreateOpen(false);
              setNewApiKey(null);
            } else {
              setIsCreateOpen(true);
            }
          }}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Nova API Key
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              {newApiKey ? (
                <>
                  <DialogHeader>
                    <DialogTitle>API Key Criada com Sucesso!</DialogTitle>
                    <DialogDescription>
                      Copie sua chave agora. Por segurança, ela não será exibida novamente.
                    </DialogDescription>
                  </DialogHeader>
                  <Alert>
                    <Shield className="h-4 w-4" />
                    <AlertDescription className="flex items-center justify-between gap-2">
                      <code className="relative rounded bg-muted px-[0.3rem] py-[0.2rem] font-mono text-sm">
                        {newApiKey}
                      </code>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => copyToClipboard(newApiKey)}
                      >
                        <Copy className="mr-2 h-3 w-3" />
                        Copiar
                      </Button>
                    </AlertDescription>
                  </Alert>
                  <div className="flex justify-end">
                    <Button onClick={() => {
                      setNewApiKey(null);
                      setIsCreateOpen(false);
                    }}>
                      Fechar
                    </Button>
                  </div>
                </>
              ) : (
                <>
                  <DialogHeader>
                    <DialogTitle>Nova API Key</DialogTitle>
                    <DialogDescription>
                      Crie uma nova chave de API para integração com sistemas externos
                    </DialogDescription>
                  </DialogHeader>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Nome</FormLabel>
                            <FormControl>
                              <Input placeholder="Ex: Sistema de Integração" {...field} />
                            </FormControl>
                            <FormDescription>
                              Um nome descritivo para identificar onde esta chave está sendo usada
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="permissions"
                        render={() => (
                          <FormItem>
                            <div className="mb-4">
                              <FormLabel className="text-base">Permissões</FormLabel>
                              <FormDescription>
                                Selecione as permissões que esta API key terá
                              </FormDescription>
                            </div>
                            {availablePermissions.map((permission) => (
                              <FormField
                                key={permission.id}
                                control={form.control}
                                name="permissions"
                                render={({ field }) => {
                                  return (
                                    <FormItem
                                      key={permission.id}
                                      className="flex flex-row items-start space-x-3 space-y-0"
                                    >
                                      <FormControl>
                                        <Checkbox
                                          checked={field.value?.includes(permission.id)}
                                          onCheckedChange={(checked) => {
                                            return checked
                                              ? field.onChange([...field.value, permission.id])
                                              : field.onChange(
                                                  field.value?.filter(
                                                    (value) => value !== permission.id
                                                  )
                                                );
                                          }}
                                        />
                                      </FormControl>
                                      <FormLabel className="font-normal">
                                        {permission.label}
                                      </FormLabel>
                                    </FormItem>
                                  );
                                }}
                              />
                            ))}
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="flex justify-end gap-2">
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => setIsCreateOpen(false)}
                        >
                          Cancelar
                        </Button>
                        <Button type="submit" disabled={createMutation.isPending}>
                          Criar API Key
                        </Button>
                      </div>
                    </form>
                  </Form>
                </>
              )}
            </DialogContent>
          </Dialog>
        </div>

        <Alert>
          <Info className="h-4 w-4" />
          <AlertDescription>
            <strong>Importante:</strong> Mantenha suas API keys seguras. Nunca compartilhe ou
            exponha suas chaves publicamente. Se uma chave for comprometida, revogue-a imediatamente.
          </AlertDescription>
        </Alert>

        <Card>
          <CardHeader>
            <CardTitle>Suas API Keys ({apiKeys?.length || 0})</CardTitle>
            <CardDescription>
              Gerencie as chaves de API ativas da sua organização
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <p className="text-center py-8 text-muted-foreground">Carregando...</p>
            ) : apiKeys && apiKeys.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Chave</TableHead>
                    <TableHead>Permissões</TableHead>
                    <TableHead>Último Uso</TableHead>
                    <TableHead>Criada em</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {apiKeys.map((apiKey) => (
                    <TableRow key={apiKey.id}>
                      <TableCell className="font-medium">{apiKey.name}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <code className="relative rounded bg-muted px-[0.3rem] py-[0.2rem] font-mono text-sm">
                            {showKeys[apiKey.id] ? apiKey.key : maskKey(apiKey.key)}
                          </code>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6"
                            onClick={() =>
                              setShowKeys({ ...showKeys, [apiKey.id]: !showKeys[apiKey.id] })
                            }
                          >
                            {showKeys[apiKey.id] ? (
                              <EyeOff className="h-3 w-3" />
                            ) : (
                              <Eye className="h-3 w-3" />
                            )}
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6"
                            onClick={() => copyToClipboard(apiKey.key)}
                          >
                            <Copy className="h-3 w-3" />
                          </Button>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {apiKey.permissions.slice(0, 2).map((perm) => (
                            <Badge key={perm} variant="outline" className="text-xs">
                              {perm.split(":")[0]}
                            </Badge>
                          ))}
                          {apiKey.permissions.length > 2 && (
                            <Badge variant="outline" className="text-xs">
                              +{apiKey.permissions.length - 2}
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {apiKey.lastUsed
                          ? format(new Date(apiKey.lastUsed), "dd/MM/yyyy")
                          : "Nunca"}
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {format(new Date(apiKey.createdAt), "dd/MM/yyyy")}
                      </TableCell>
                      <TableCell className="text-right">
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
                              <AlertDialogDescription>
                                Tem certeza que deseja revogar esta API key? Sistemas que a utilizam
                                perderão o acesso imediatamente.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancelar</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => deleteMutation.mutate(apiKey.id)}
                                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                              >
                                Revogar
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="flex flex-col items-center justify-center py-12">
                <Key className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">Nenhuma API Key criada</h3>
                <p className="text-sm text-muted-foreground text-center max-w-md mb-4">
                  Crie uma API key para integrar seu sistema com APIs externas.
                </p>
                <Button onClick={() => setIsCreateOpen(true)}>
                  <Plus className="mr-2 h-4 w-4" />
                  Criar Primeira API Key
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Documentação da API</CardTitle>
            <CardDescription>
              Consulte a documentação completa para integrar com nossa API
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              A documentação da API está disponível em formato interativo. Você pode testar
              endpoints, ver exemplos de código e entender todos os recursos disponíveis.
            </p>
            <Button variant="outline" asChild>
              <a href="/api-docs" target="_blank">
                Ver Documentação da API
              </a>
            </Button>
          </CardContent>
        </Card>
      </div>
    </PageContainer>
  );
}
