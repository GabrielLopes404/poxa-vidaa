import { db } from "./db";
import { sql } from "drizzle-orm";

export class SessionManagementService {
  async logoutAllSessions(userId: string): Promise<number> {
    try {
      const result = await db.execute(
        sql`DELETE FROM session WHERE sess::text LIKE ${`%"userId":"${userId}"%`}`
      );

      const deletedCount = result.rowCount || 0;
      console.log(`Logged out ${deletedCount} sessions for user ${userId}`);
      
      return deletedCount;
    } catch (error) {
      console.error("Error logging out all sessions:", error);
      throw error;
    }
  }

  async getActiveSessions(userId: string): Promise<number> {
    try {
      const result = await db.execute(
        sql`SELECT COUNT(*) FROM session WHERE sess::text LIKE ${`%"userId":"${userId}"%`}`
      );

      return parseInt(result.rows[0]?.count as string || "0");
    } catch (error) {
      console.error("Error getting active sessions:", error);
      return 0;
    }
  }

  async logoutOtherSessions(userId: string, currentSessionId: string): Promise<number> {
    try {
      const result = await db.execute(
        sql`DELETE FROM session 
            WHERE sess::text LIKE ${`%"userId":"${userId}"%`} 
            AND sid != ${currentSessionId}`
      );

      const deletedCount = result.rowCount || 0;
      console.log(`Logged out ${deletedCount} other sessions for user ${userId}`);
      
      return deletedCount;
    } catch (error) {
      console.error("Error logging out other sessions:", error);
      throw error;
    }
  }

  async cleanExpiredSessions(): Promise<number> {
    try {
      const result = await db.execute(
        sql`DELETE FROM session WHERE expire < NOW()`
      );

      const deletedCount = result.rowCount || 0;
      console.log(`Cleaned ${deletedCount} expired sessions`);
      
      return deletedCount;
    } catch (error) {
      console.error("Error cleaning expired sessions:", error);
      throw error;
    }
  }
}

export const sessionManagementService = new SessionManagementService();
