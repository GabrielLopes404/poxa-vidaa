import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import AppLayout from "@/components/AppLayout";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  Legend,
} from "recharts";
import { Calendar } from "@/components/ui/calendar";
import {  Popover,  PopoverContent,  PopoverTrigger} from "@/components/ui/popover";
import { CalendarIcon, Download, TrendingUp, TrendingDown } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

const COLORS = ["#10b981", "#f59e0b", "#ef4444", "#8b5cf6", "#06b6d4"];

export default function EnhancedDashboardPage() {
  const [dateRange, setDateRange] = useState<{ from?: Date; to?: Date }>({
    from: new Date(new Date().setDate(1)),
    to: new Date(),
  });

  const { data: dashboardData } = useQuery({
    queryKey: ["/api/dashboard/enhanced", dateRange],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (dateRange.from) params.set("startDate", dateRange.from.toISOString());
      if (dateRange.to) params.set("endDate", dateRange.to.toISOString());
      const res = await fetch(`/api/dashboard/enhanced?${params}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch data");
      return res.json();
    },
  });

  const { data: comparison } = useQuery({
    queryKey: ["/api/dashboard/comparison", dateRange],
    queryFn: async () => {
      const res = await fetch("/api/dashboard/comparison", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch comparison");
      return res.json();
    },
  });

  const exportDashboard = async () => {
    const res = await fetch("/api/dashboard/export", { credentials: "include" });
    const blob = await res.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `dashboard-${format(new Date(), "yyyy-MM-dd")}.pdf`;
    a.click();
  };

  return (
    <AppLayout>
      <motion.div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold">Dashboard Avançado</h1>
          <div className="flex gap-2">
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline">
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {dateRange.from ? format(dateRange.from, "dd/MM/yy", { locale: ptBR }) : "Início"} -{" "}
                  {dateRange.to ? format(dateRange.to, "dd/MM/yy", { locale: ptBR }) : "Fim"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="end">
                <Calendar
                  mode="range"
                  selected={{ from: dateRange.from, to: dateRange.to }}
                  onSelect={(range) => setDateRange({ from: range?.from, to: range?.to })}
                  locale={ptBR}
                />
              </PopoverContent>
            </Popover>
            <Button onClick={exportDashboard}>
              <Download className="mr-2 h-4 w-4" />
              Exportar
            </Button>
          </div>
        </div>

        {comparison && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Receitas vs Período Anterior</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  R$ {dashboardData?.totalRevenue || "0,00"}
                </div>
                <div className={`flex items-center text-sm ${comparison.revenueGrowth >= 0 ? "text-green-600" : "text-red-600"}`}>
                  {comparison.revenueGrowth >= 0 ? <TrendingUp className="h-4 w-4 mr-1" /> : <TrendingDown className="h-4 w-4 mr-1" />}
                  {Math.abs(comparison.revenueGrowth).toFixed(1)}% vs período anterior
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Despesas vs Período Anterior</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  R$ {dashboardData?.totalExpenses || "0,00"}
                </div>
                <div className={`flex items-center text-sm ${comparison.expenseGrowth <= 0 ? "text-green-600" : "text-red-600"}`}>
                  {comparison.expenseGrowth <= 0 ? <TrendingDown className="h-4 w-4 mr-1" /> : <TrendingUp className="h-4 w-4 mr-1" />}
                  {Math.abs(comparison.expenseGrowth).toFixed(1)}% vs período anterior
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Lucro vs Período Anterior</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  R$ {dashboardData?.profit || "0,00"}
                </div>
                <div className={`flex items-center text-sm ${comparison.profitGrowth >= 0 ? "text-green-600" : "text-red-600"}`}>
                  {comparison.profitGrowth >= 0 ? <TrendingUp className="h-4 w-4 mr-1" /> : <TrendingDown className="h-4 w-4 mr-1" />}
                  {Math.abs(comparison.profitGrowth).toFixed(1)}% vs período anterior
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Receitas e Despesas</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={dashboardData?.monthlyData || []}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="receitas" fill="#10b981" name="Receitas" />
                  <Bar dataKey="despesas" fill="#ef4444" name="Despesas" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Despesas por Categoria</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={dashboardData?.categoryData || []}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={(entry) => entry.name}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {(dashboardData?.categoryData || []).map((_: any, index: number) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      </motion.div>
    </AppLayout>
  );
}
